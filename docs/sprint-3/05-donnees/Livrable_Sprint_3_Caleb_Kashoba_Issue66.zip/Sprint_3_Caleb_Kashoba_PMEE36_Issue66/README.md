# Mon Miam Miam — Sprint 3 / Caleb Kashoba

**Issue GitHub #66 — Jira PMEE-36** · 3 novembre 2026

## Périmètre
Conformément à la répartition du Sprint 3 : **extensions de données**, **modèles Eloquent**, **migrations PostgreSQL complémentaires**, **intégrité**, **données et tests de démonstration**. La mention « MySQL » du document de répartition a été remplacée par PostgreSQL sur instruction de l'équipe.

## Arborescence livrée

- `supabase/migrations/` — trois migrations complémentaires (panier, audit/validation réclamations, index).
- `supabase/preflight/` — inventaire read-only du schéma existant.
- `supabase/tests/` — assertions read-only et données jetables sous `BEGIN…ROLLBACK`.
- `supabase/seed/` — mini-catalogue fictif de **3 restaurants**, opt-in, pour le développement local uniquement (ne remplace pas le jeu officiel).
- `supabase/seed/` — mini-catalogue fictif de **3 restaurants**, opt-in, pour le développement local uniquement (ne remplace pas le jeu officiel).
- `backend/app/Models/` — modèles Eloquent PHP pour les tables S2 + S3.
- `docs/sprint-3/base-de-donnees/` — contrat d'interface, guide de déploiement, checklist, rapport.

## Ce qui est prêt et ce qui ne l'est pas

**Prêt pour revue :** code SQL, modèles Laravel, documentation, tests SQL et scénarios démonstratifs. La syntaxe PHP et la cohérence statique des fichiers ont été vérifiées.

**Non exécuté :** migrations sur le projet Supabase principal, reconstruction PostgreSQL en conditions réelles, tests PHPUnit complets, déploiement ou PR GitHub. L'état en ligne du dépôt GitHub n'était pas accessible publiquement (404) ; aucun fichier n'a été modifié dans le dépôt.

**Important :** la coéquipière réalise le jeu de données officiel avec trois restaurants. Les tests/fixtures livrés ici n'écrasent pas son travail et ne sont pas un seeder de production : ils utilisent `ROLLBACK`.

## Ordre recommandé

1. Lire `docs/sprint-3/base-de-donnees/DEPLOIEMENT_SECURISE.md`.
2. Lire `supabase/preflight/00_verifier_sprint2.sql` sur le projet existant (lecture seule).
3. Confirmer avec Wivine/Aksa la persistance du panier et la règle gérant seul.
4. Tester les migrations 01 → 02 → 03 en local, puis exécuter les tests SQL.
5. Copier/adapter les modèles dans la vraie application Laravel.
6. Faire valider le contrat d'interface et tester l'intégration avec les API.
7. Créer la PR dans le dépôt commun et joindre les preuves de tests.

**Ne jamais exécuter sur le projet principal avant la revue et la sauvegarde.**
