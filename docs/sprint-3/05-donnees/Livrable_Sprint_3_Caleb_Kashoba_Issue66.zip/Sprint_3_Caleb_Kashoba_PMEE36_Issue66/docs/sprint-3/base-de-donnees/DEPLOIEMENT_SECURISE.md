# Procédure de mise en service — à suivre avant toute écriture distante

## 1. État des sources
Le schéma initial de Sprint 2 fourni précédemment se trouve dans `supabase/migrations/20261029...` du livrable Sprint 2. Il a été conçu pour une base vierge ; les 21 tables du projet principal ont été créées **avant** son versionnement. Les migrations de ce dossier Sprint 3 sont des **extensions**, pas une re-création de 21 tables.

## 2. Reconcilier la baseline réelle

Dans un clone du dépôt, conserver les migrations déjà présentes. Lire d'abord leur historique :

```bash
supabase login
supabase link --project-ref <IDENTIFIANT_PROJET>  # secret non partagé
supabase migration list --remote
supabase db pull --remote
supabase migration list --remote
```

Ne pas copier aveuglément les quatre migrations Sprint 2 dans la suite du répertoire du dépôt s'il possède déjà un historique différent. Les identifiants de version et l'état distant doivent correspondre. `db pull` crée la baseline/diff de schéma local; examiner son contenu et vérifier avec les responsables avant commit. L'outil peut demander Docker.

## 3. Tester hors du projet principal

```bash
supabase start
supabase db reset   # local uniquement : détruit les données locales
```

Exécuter ensuite les tests SQL fournis. Vérifier manuellement les migrations avant toute publication.

## 4. Déployer seulement après revue

```bash
supabase migration list --remote
supabase db push --remote
```

**Ne pas lancer ces commandes de déploiement tant que l'état de la base distante et le jeu de données officiel ne sont pas vérifiés.** Une approbation explicite dans la PR est recommandée.

## 5. Rollback

Il n'existe **pas de rollback automatique garanti** pour ces migrations SQL Supabase. Préparer des migrations compensatoires après revue de la dépendance aux nouvelles tables et des sauvegardes. En cas de problème, restaurer en dehors du projet principal.

## 6. Intégration Laravel

Copier les classes depuis `backend/app/Models` dans la vraie application Laravel, **sans écraser** des fichiers de même nom déjà modifiés par l'équipe API. Comparer les noms de tables, casts, relations et modèles existants. Aucun `artisan migrate` Laravel n'est nécessaire pour créer les tables gérées par les migrations SQL Supabase.
