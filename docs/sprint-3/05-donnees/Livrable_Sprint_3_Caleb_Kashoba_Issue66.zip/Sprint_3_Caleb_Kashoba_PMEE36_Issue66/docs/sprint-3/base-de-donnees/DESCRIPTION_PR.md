# Modèle de description de PR - Sprint 3 (PMEE-36 / #66)

**Titre :** `[Sprint 3][PMEE-36/#66] Modèles Laravel et extensions PostgreSQL`

**Livraison :** 23 classes Eloquent, 3 migrations SQL complémentaires (panier, audit/réclamations, index), tests de base et guide d'intégration.

**Dépendances :** 21 tables Sprint 2 existantes, intégration Laravel, Supabase Auth, contrat API Wivine/Aksa/Yveline.

**Vérifications effectuées :** revue de structure et vérifications statiques PHP déjà réalisées lors de la préparation du paquet. **Pas de migrations S3 exécutées en base dans les éléments fournis.**

**À valider :** panier persistant, RLS / RBAC, changement d'acteur, protection réclamations, migrations sur copie, tests d'intégration et de régression, approbations équipe.

**Prudence :** aucune réinitialisation de la base Supabase principale.
