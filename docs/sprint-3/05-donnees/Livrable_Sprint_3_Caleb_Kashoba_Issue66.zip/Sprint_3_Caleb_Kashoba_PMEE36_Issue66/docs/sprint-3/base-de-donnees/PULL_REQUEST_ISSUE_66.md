# Proposition de titre de PR

`feat(database): modèles Eloquent et extensions PostgreSQL du Sprint 3 (PMEE-36, #66)`

## Résumé

- Ajout de modèles Eloquent correspondant au schéma Supabase existant.
- Ajout des migrations complémentaires pour un panier multi-restaurants, l’audit des commandes et l’intégrité des décisions sur les réclamations.
- Ajout d’index de lecture adaptés aux nouvelles API.
- Ajout de tests read-only, fixtures temporaires et mini-jeu de données local (trois restaurants).
- Documentation du contrat technique pour Aksa, Wivine et Yveline.

## Prérequis avant fusion

- [ ] Baseline du Sprint 2 reconciliée avec le projet Supabase.
- [ ] Validation du panier persistant par Wivine.
- [ ] Approbation du rôle gérant par Aksa.
- [ ] Migrations exécutées et vérifiées sur une instance Supabase de test.
- [ ] Tests Laravel réalisés dans le vrai backend.
- [ ] Données officielles validées par la coéquipière responsable du seeding.

## Preuves à joindre

- Captures des sorties des tests en base (sans identifiants ni données personnelles).
- Résultat `php artisan test` / tests d’intégration.
- Vidéo ou captures de démonstration du panier et des statuts.

Closes #66 (uniquement après validation de tous les critères).
