# Checklist d'intégration — Caleb / Sprint 3

## Préalables obligatoires (bloquants pour déploiement)

- [ ] Obtenir `supabase migration list --remote` et faire concorder les migrations locales et la baseline réelle.
- [ ] Inspecter les 21 tables et triggers du projet principal avec `preflight/00_verifier_sprint2.sql`.
- [ ] Sauvegarder le projet de développement et utiliser une instance locale Supabase pour les essais.
- [ ] Évaluer avec Wivine la persistance du panier avant création des deux tables.
- [ ] Vérifier avec Aksa que le décideur d'une réclamation doit être `staff_role='manager'` pour son restaurant.
- [ ] Faire valider les changements d'API par Wivine et Yveline.

## Tests de code (effectuables sans Supabase)

- [x] Syntaxe des modèles PHP vérifiée avec `php -l` (voir rapport).
- [x] Contrôles statiques des références tables/modèles et structure de l'archive effectués.
- [ ] Exécution sur un vrai Laravel 12 avec dépendances installées et tests PHPUnit.

## Tests PostgreSQL (restent à exécuter)

- [ ] Réinitialiser **uniquement la base locale** et appliquer S2 puis S3 dans l'ordre.
- [ ] Exécuter `supabase/tests/01_schema_contract_readonly.sql`.
- [ ] Exécuter `supabase/tests/02_quality_report_readonly.sql` et examiner les compteurs non nuls.
- [ ] Exécuter `supabase/tests/03_cart_constraints_rollback.sql` et `/04_trois_restaurants_rollback.sql`.
- [ ] Avec un compte Supabase Auth de test, vérifier le panier pour 2 restaurants, la FK composite et le filtrage par client.
- [ ] Tester une réponse `approved` par gérant du bon restaurant (acceptée), `employee` ou autre restaurant (refusée).
- [ ] Tester `orders.status`: un seul événement généré par transition et `changed_by` attribué via contexte serveur.
- [ ] Exécuter deux fois le catalogue local `supabase/seed/sprint3_catalogue_dev_only.sql` sans doublon, puis contrôler les compteurs.
- [ ] Refaire les seeders officiels de la coéquipière deux fois sans doublon ni écrasement.
- [ ] Ouvrir une PR avec traces de tests et démonstration.

**Interdiction :** `supabase db reset --remote` ou `migrate:fresh` sur le projet Supabase principal. Ne jamais publier de clé service_role/connexion PostgreSQL dans GitHub.
