# RAPPORT TECHNIQUE — SPRINT 3

**Projet :** Mon Miam Miam  
**Responsable :** Caleb Kashoba  
**Ticket :** Jira PMEE-36 · GitHub #66  
**Date :** 3 novembre 2026  
**Environnement cible :** Laravel/PHP · Supabase PostgreSQL · Supabase Auth  
**Nature du livrable :** code prêt pour revue ; pas encore déployé sur le projet distant

## 1. Cadre de la mission

Le document de répartition du Sprint 3 confie à Caleb les « extensions MySQL et Laravel : modèles, migrations complémentaires, intégrité et données de test ». Conformément à la décision de l'équipe, l'implémentation utilise **PostgreSQL**, et non MySQL. Le Sprint 3 doit réutiliser le socle du Sprint 2, sans recréer les 21 tables ni remplacer Supabase Auth.

## 2. Travaux réalisés dans cette livraison

| Axe | Réalisation | Artefacts |
|---|---|---|
| Modèles Laravel | 23 modèles Eloquent, dont 21 mappings Sprint 2 et 2 nouveaux modèles de panier | `backend/app/Models/` |
| Migration complémentaire 01 | Panier persistant multi-restaurants (`carts`, `cart_items`), FKs composites et RLS | `20261103000100_...sql` |
| Migration complémentaire 02 | Audit `changed_by` via JWT/contexte transactionnel ; validation des décisions par un gérant actif du bon restaurant ; RLS des réponses approuvées | `20261103000200_...sql` |
| Migration complémentaire 03 | Index complémentaires pour commandes, personnel, paiements, réclamations et campagnes | `20261103000300_...sql` |
| Données de test | Catalogue fictif local, 3 restaurants, catégories, produits, menus, paramètres et affiches ; fixtures jetables en transaction | `supabase/seed/`, `supabase/tests/` |
| Contrôles | Préflight read-only, assertions du schéma, diagnostic d'intégrité | `supabase/preflight/`, `supabase/tests/` |
| Documentation | Contrat API, checklist et déploiement prudent | `docs/sprint-3/base-de-donnees/` |

Le complément de données de test est **volontairement limité** aux entités sans utilisateur Supabase Auth. Il ne remplace pas le jeu de données complet dont la coéquipière reste responsable et qui doit créer les vrais comptes de test avec Supabase Auth.

## 3. Architecture et mesures d'intégrité

- **Panier :** un panier courant par utilisateur et restaurant, clés composites empêchant les produits d'un autre restaurant. Aucun prix de panier figé ; `products.price` est relu au checkout.
- **Commandes :** le déclencheur `trg_log_order_status_change` du Sprint 2 conserve seul l'historique. Laravel n'insère pas manuellement les événements ; `app.actor_id` peut enregistrer l'acteur vérifié côté serveur dans la même transaction.
- **Réclamations :** le nouveau déclencheur vérifie que les réponses acceptées/rejetées sont décidées par un gérant actif du restaurant de la commande ; une policy RLS n'autorise le client à lire que les réponses approuvées.
- **RBAC :** les règles d'autorisation de la couche API sont à implémenter par Aksa ; elles ne sont pas remplacées par les triggers ni les relations Eloquent.
- **Fidélité/paiements :** les contraintes existantes du Sprint 2 sont conservées. Les transactions d'acquisition, restitution et retrait de points sont du ressort de Yveline et des services Laravel ; une difficulté de solde insuffisant reste à arbitrer.
- **Suppression :** `products.is_active = false` ; le trigger de Sprint 2 refuse la suppression physique.

## 4. Contrôles effectivement effectués

**Contrôles exécutés hors base :**

- Validation syntaxique des **24 fichiers PHP** (23 modèles + 1 test PHPUnit) par `php -l` : **24 réussis, 0 erreur**.
- Contrôle statique de la présence de **3 migrations complémentaires**, des FKs composites sur les paniers, de deux policies SELECT, de la fonction d'audit, de la règle de gérant actif et de la présence de transactions annulées pour les fixtures : **réussi**.
- Vérification de l'organisation des fichiers et de la cohérence de leurs chemins : **réussie**.

**Non exécutés et donc non déclarés validés :**

- Exécution sur un serveur Supabase/PostgreSQL réel, et notamment sur le projet principal ; aucune connexion au serveur n'a été établie.
- Tests d'intégration PHPUnit dans le dépôt Laravel (non accessible publiquement).
- Insertion de comptes de test via Supabase Auth et tests métiers exhaustifs des API.
- Déploiement GitHub, Pull Request, démonstration et approbation Jira.

## 5. Dépendances et arbitrages

1. **Schéma exact de Supabase :** vérifier l'état des tables, des triggers et de l'historique des migrations. Les migrations initiales du Sprint 2 ont été produites pour base vierge et ne doivent pas être rejouées sur la base actuelle.
2. **Wivine :** confirmer que le panier doit être persistant ; contrôler le fonctionnement de `carts`/`cart_items`, de la validation des prix et des transitions d'état.
3. **Aksa :** valider le rôle `manager` requis pour l'approbation des réclamations et intégrer le contrôle d'accès multi-restaurants au backend.
4. **Yveline :** implémenter les transactions de points/parrainage, avec verrouillage et idempotence ; confirmer le scénario du solde insuffisant si une ancienne récompense doit être annulée.
5. **Données officielles :** attendre la version corrigée à trois restaurants de la coéquipière avant le chargement partagé. Les données de démonstration fournies sont locales et indépendantes.

## 6. Statut des exigences

| Exigence du ticket #66 | Statut |
|---|---|
| Modèles Eloquent | **Codés — syntaxe vérifiée ; intégration à confirmer** |
| Migrations complémentaires PostgreSQL | **Rédigées — exécution non testée** |
| Contraintes/traçabilité/intégrité | **Compléments codés — tests en base à effectuer** |
| Données de test | **Démonstration locale préparée ; jeu complet commun en attente** |
| Tests, PR et démonstration | **À réaliser dans l'environnement de l'équipe** |

## 7. Conclusion

Le livrable technique de Caleb pour le Sprint 3 est **préparé pour une revue d'intégration** : 23 modèles, 3 migrations complémentaires, un jeu de données fictif local, des tests SQL et un dossier de documentation. La mission n'est pas encore **déployée ni validée de bout en bout** : il faut faire correspondre ces fichiers à la baseline réelle, exécuter les tests sur une instance isolée, obtenir l'accord des équipes API, puis créer la PR de l'issue #66.
