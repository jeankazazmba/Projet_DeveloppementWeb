# Validation Sprint 3 - À renseigner après exécution réelle

| Critère d'acceptation proposé | État au 04/11/2026 | Preuve attendue |
|---|---|---|
| Base Sprint 2 disponible | Observée (21 tables déclarées ; seed 3 restaurants) | Inventaire SELECT + schéma distant |
| Migration panier `carts/cart_items` en environnement isolé | Non attestée | Journal CLI/SQL et requêtes structure |
| Migration audit/réclamations | Non attestée | Résultats de cas approuvé/rejeté et audit acteur |
| Migration index | Non attestée | Liste `pg_indexes` et plan de requête facultatif |
| 23 modèles Eloquent intégrés dans Laravel | Code fourni, intégration non attestée | PR, chargement des modèles, tests PHPUnit |
| Tests RBAC avec Aksa | Non attestés | Cas autorisé et refusé (403) |
| Tests panier/commande avec Wivine | Non attestés | Parcours complet + cohérence produit/restau |
| Tests fidélité/parrainage avec Yveline | Non attestés | Réconciliation des mouvements et idempotence |
| Pull Request + revue équipe | Non attestées | URL de PR, commentaires, approbation |

**Important :** ne pas cocher « validé » sur la seule base de `php -l` ou de la présence des fichiers. Le code est livré prêt pour intégration et tests réels.
