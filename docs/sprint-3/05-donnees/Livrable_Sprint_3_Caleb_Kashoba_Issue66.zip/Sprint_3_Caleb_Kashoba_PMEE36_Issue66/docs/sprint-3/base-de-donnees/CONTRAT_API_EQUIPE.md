# Contrat technique commun — Sprint 3 / PMEE-36 / issue #66

**Propriétaire données : Caleb Kashoba.** Répartition de sprint : Caleb réalise modèles, migrations complémentaires, intégrité et tests ; Aksa gère RBAC ; Wivine développe panier/commandes/livraisons/réclamations ; Yveline développe fidélité/parrainage/classement/campagnes.

## Décisions conservées

- PostgreSQL Supabase, **pas MySQL**. Supabase Auth est la source d'identité ; pas de mots de passe ni de second magasin utilisateur en Eloquent.
- Un client possède un UUID (`profiles.id`) global, un compte de fidélité distinct par restaurant.
- Restaurant pilote et données de prix en CDF, paiement réussi en une fois et intégral.
- `products.is_active=false` signifie suppression logique.
- `order_status_events` est alimentée par trigger : aucun insert manuel depuis l'API ou les seeders.
- Les réponses des employés restent invisibles au client tant que `review_status <> 'approved'`.
- Les compensations de points (annulation/remboursement) sont des transactions métier côté Laravel/Yveline. **Cas exceptionnel de solde insuffisant** : non automatisé / à arbitrer ; le CHECK `balance_points>=0` demeure.
- Les prix des données de test `order_items.unit_price` doivent être alignés avec le `products.price` du même produit. En production, un prix de commande est un instantané historique et peut diverger après changement du catalogue.

## Interfaces attendues

### Wivine — Panier, commandes et livraison

- `carts`: `(restaurant_id, customer_id)` unique ; `cart_items`: `(cart_id, product_id)` unique, `quantity > 0`.
- Chaque produit ajouté appartient au restaurant du panier via clés étrangères composites.
- Le panier n'enregistre **pas** un prix : vérifier prix/activité/disponibilité au checkout et enregistrer le prix dans `order_items.unit_price`.
- La conversion du panier en commande + lignes + calcul sous-total est **atomique** (transaction PostgreSQL unique).
- `orders.total_amount` est calculé dans la base, non modifiable à la main.
- Lors d'un changement de statut : valider les transitions dans Laravel, puis mettre à jour `orders.status` uniquement. La table d'historique est alimentée automatiquement.
- Pour renseigner `changed_by`, après vérification du JWT Supabase, dans la **même transaction** SQL que l'UPDATE :

```php
DB::transaction(function () use ($verifiedSupabaseUserId, $orderId) {
    DB::select('select set_config(?, ?, true)', ['app.actor_id', $verifiedSupabaseUserId]);
    // Verrouiller la commande et contrôler sa transition et le restaurant autorisé.
    // $order->status = 'preparing'; $order->save();
});
```

- Le compte PostgreSQL Laravel doit être réservé au serveur. `app.actor_id` est un **contexte d'audit**, non une autorisation ; il serait falsifiable si des clients accédaient directement au SQL.

### Aksa — RBAC / admin

- Les rôles sont **par restaurant**, dans `staff_assignments` (`employee`, `manager`, `admin`). Les modèles ne donnent aucune permission automatiquement.
- Les nouveaux paniers ont des policies SELECT propriétaire via Supabase/PostgREST, **aucune** policy publique d'écriture.
- Laravel connecté directement via PostgreSQL doit contrôler lui-même identité, appartenance du restaurant, rôle et statut actif. Ne pas supposer qu'une connexion privilégiée applique les RLS.
- Vérifier signature, audience, expiration et émetteur des JWT Supabase selon la configuration de clés du projet ; ne pas réutiliser Sanctum pour remplacer Supabase Auth.
- Les données d'un restaurant ne doivent jamais fuiter dans les résultats d'un autre restaurant ; une relation Eloquent simple ne remplace pas le filtrage `restaurant_id`.

### Yveline — Fidélité, parrainage, promotions

- Comptes/transactions de points liés au même restaurant. Les écritures d'une commande doivent être exécutées une seule fois avec clés d'idempotence (`loyalty_transactions.idempotency_key`).
- Ne créditer qu'après paiement confirmé + livraison/service ; retirer les gains lors d'un remboursement, restituer les points consommés lors d'une annulation.
- Sérialiser les mutations de solde avec verrouillage de ligne et transaction ; pas de solde négatif. Si un remboursement doit retirer plus que le solde disponible, demander une règle métier explicite ; ne pas contourner le CHECK.
- Un bonus de parrainage au plus par filleul et restaurant selon la première commande admissible.

## Points non résolus par cette livraison

1. État réel du schéma sur le **projet Supabase principal** et historique des migrations (non accessibles ici).
2. Validation du caractère persistant du panier : ajouté ici pour l'API Sprint 3 ; à confirmer avec Wivine avant déploiement.
3. Matrice RBAC détaillée et transitions de commandes (Aksa + Wivine).
4. Gouvernance des compensations de points en cas de solde déjà consommé.
5. Statut du jeu de données officiel à **trois restaurants** : la version corrigée n'a pas été transmise à cette livraison.
