# MON MIAM MIAM - LIVRABLE SPRINT 3

**Responsable :** Caleb Kashoba - **Jira PMEE-36 / GitHub issue #66**.
**Stack retenue :** Laravel, Supabase PostgreSQL, Supabase Auth (la mention MySQL du document initial ne s'applique pas).
**Date du dossier :** 04/11/2026.

## Périmètre effectivement préparé

- **23 modèles Eloquent** (`backend/app/Models/`) pour les 21 tables métier du Sprint 2 et 2 nouvelles tables de panier.
- **3 migrations complémentaires** (`supabase/migrations/`) : panier persistant multi-restaurants ; audit des commandes et contrôle d'approbation des réclamations ; index complémentaires.
- **Scripts de précontrôle et de tests** (`supabase/preflight/`, `supabase/tests/`). Certains cas utilisent `BEGIN`/`ROLLBACK` et n'engagent aucun changement persistant s'ils sont exécutés intégralement.
- **Un mini-catalogue de test** dans `supabase/seed/`, complémentaire uniquement ; **ne remplace pas** le jeu de données officiel du Sprint 2 déjà intégré.
- **Contrat de coordination** avec Aksa (RBAC), Wivine (commandes/panier) et Yveline (fidélité).

## État technique au 04/11/2026

Le jeu de données du Sprint 2 avec 3 restaurants est observé dans la base Supabase d'après les captures fournies. **Cela ne signifie pas que les 3 migrations du Sprint 3 ont été exécutées.** Les nouvelles tables `carts` et `cart_items` ne sont donc pas présumées présentes dans l'environnement principal.

Le paquet Sprint 3 a été contrôlé statiquement lors de sa préparation. Le déploiement PostgreSQL réel, les tests Laravel d'intégration, la Pull Request GitHub et la validation d'équipe restent **à exécuter**. Le Sprint 3 est un **livrable de code prêt pour revue**, pas une livraison de production validée.

## Ordre d'intégration

1. Lire `docs/sprint-3/base-de-donnees/DEPLOIEMENT_SECURISE.md` et exécuter `supabase/preflight/00_verifier_sprint2.sql` sur le projet existant (lecture seule).
2. Comparer le schéma réel au SQL Sprint 2, et vérifier la baseline du projet Supabase ; ne pas rejouer les 4 migrations initiales du Sprint 2.
3. Avec Wivine, confirmer que le panier doit être persistant en base avant d'ajouter `carts` et `cart_items` ; vérifier l'absence de tables homonymes.
4. Sur une base isolée clonée, appliquer les migrations **01 → 02 → 03** (fichiers datés 20261103...). Tester les contraintes et le modèle d'audit.
5. Relire les modèles Laravel avec le backend API ; ne pas écraser des classes Eloquent existantes sans résolution des différences.
6. Exécuter les tests et compléter le compte rendu `docs/sprint-3/base-de-donnees/VALIDATION_A_REALISER.md` avec des résultats réels.
7. Ouvrir une Pull Request vers le dépôt de l'équipe, obtenir les validations et joindre les preuves.

## Alertes de sécurité / produit

- `auth.users` appartient à Supabase Auth ; aucune réécriture des comptes de connexion dans Laravel.
- Les contrôles RLS et les triggers ne remplacent **pas** la vérification des JWT, des rôles et du restaurant dans l'API Laravel.
- Le contexte `app.actor_id` ne doit être défini que côté serveur, dans la transaction SQL, après validation du jeton Supabase Auth.
- Les opérations de points restent transactionnelles et idempotentes côté backend ; ne pas inventer le traitement des points déjà dépensés lors d'un remboursement.
- Les migrations du Sprint 3 ne doivent pas être appliquées sur le projet Supabase principal sans revue, sauvegarde et validation d'un test sur copie.
