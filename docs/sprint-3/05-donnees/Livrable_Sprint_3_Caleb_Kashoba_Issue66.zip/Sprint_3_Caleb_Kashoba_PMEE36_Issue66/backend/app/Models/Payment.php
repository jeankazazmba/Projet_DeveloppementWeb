<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Mapping du schema Supabase/PostgreSQL (Sprint 2 + Sprint 3).
 * ATTENTION : toute requete multi-restaurants doit etre filtree par restaurant_id
 * et l autorisation doit etre verifiee cote Laravel.
 */
class Payment extends Model
{
    use HasUuids;

    protected $table = 'payments';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    public $timestamps = false;

    protected $fillable = [
        'order_id',
        'provider',
        'method',
        'amount',
        'currency_code',
        'provider_transaction_id',
        'status',
        'idempotency_key',
        'paid_at',
    ];

    protected function casts(): array
    {
        return [
            'amount' => 'decimal:2',
            'paid_at' => 'immutable_datetime',
        ];
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class, 'order_id');
    }

}
