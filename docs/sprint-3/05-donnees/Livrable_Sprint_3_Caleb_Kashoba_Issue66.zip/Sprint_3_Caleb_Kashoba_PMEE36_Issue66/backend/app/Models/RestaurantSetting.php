<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Mapping du schema Supabase/PostgreSQL (Sprint 2 + Sprint 3).
 * ATTENTION : toute requete multi-restaurants doit etre filtree par restaurant_id
 * et l autorisation doit etre verifiee cote Laravel.
 */
class RestaurantSetting extends Model
{
    protected $table = 'restaurant_settings';
    protected $primaryKey = 'restaurant_id';
    public $incrementing = false;
    protected $keyType = 'string';
    public $timestamps = false;

    // Cle primaire partagee avec restaurants.id : pas de UUID genere ici.

    protected $fillable = [
        'opening_hours',
        'loyalty_earn_amount',
        'loyalty_earn_points',
        'loyalty_redeem_points',
        'loyalty_redeem_value',
        'referral_reward_points',
        'loyalty_expiration_months',
    ];

    protected function casts(): array
    {
        return [
            'opening_hours' => 'array',
            'loyalty_earn_amount' => 'decimal:2',
            'loyalty_redeem_value' => 'decimal:2',
            'updated_at' => 'immutable_datetime',
        ];
    }

    public function restaurant(): BelongsTo
    {
        return $this->belongsTo(Restaurant::class, 'restaurant_id');
    }

}
