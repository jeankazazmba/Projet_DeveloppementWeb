<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

/**
 * Mapping du schema Supabase/PostgreSQL (Sprint 2 + Sprint 3).
 * ATTENTION : toute requete multi-restaurants doit etre filtree par restaurant_id
 * et l autorisation doit etre verifiee cote Laravel.
 */
class Restaurant extends Model
{
    use HasUuids;

    protected $table = 'restaurants';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    public $timestamps = false;

    protected $fillable = [
        'slug',
        'name',
        'address',
        'phone',
        'email',
        'currency_code',
        'status',
    ];

    protected function casts(): array
    {
        return [
            'created_at' => 'immutable_datetime',
        ];
    }

    public function profiles(): HasMany
    {
        return $this->hasMany(StaffAssignment::class, 'restaurant_id');
    }

    public function settings(): HasOne
    {
        return $this->hasOne(RestaurantSetting::class, 'restaurant_id');
    }

    public function categories(): HasMany
    {
        return $this->hasMany(Category::class, 'restaurant_id');
    }

    public function products(): HasMany
    {
        return $this->hasMany(Product::class, 'restaurant_id');
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class, 'restaurant_id');
    }

    public function carts(): HasMany
    {
        return $this->hasMany(Cart::class, 'restaurant_id');
    }

}
