<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Mapping du schema Supabase/PostgreSQL (Sprint 2 + Sprint 3).
 * ATTENTION : toute requete multi-restaurants doit etre filtree par restaurant_id
 * et l autorisation doit etre verifiee cote Laravel.
 */
class OrderStatusEvent extends Model
{
    use HasUuids;

    protected $table = 'order_status_events';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    public $timestamps = false;

    // Table d audit/journal : ecritures exclusivement via services securises.

    protected $fillable = [
        'order_id',
        'previous_status',
        'new_status',
        'changed_by',
    ];

    protected function casts(): array
    {
        return [
            'changed_at' => 'immutable_datetime',
        ];
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class, 'order_id');
    }

    public function actor(): BelongsTo
    {
        return $this->belongsTo(Profile::class, 'changed_by');
    }

}
