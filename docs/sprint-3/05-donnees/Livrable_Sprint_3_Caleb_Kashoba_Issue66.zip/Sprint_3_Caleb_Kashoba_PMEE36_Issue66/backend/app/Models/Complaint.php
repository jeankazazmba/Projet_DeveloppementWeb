<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Mapping du schema Supabase/PostgreSQL (Sprint 2 + Sprint 3).
 * ATTENTION : toute requete multi-restaurants doit etre filtree par restaurant_id
 * et l autorisation doit etre verifiee cote Laravel.
 */
class Complaint extends Model
{
    use HasUuids;

    protected $table = 'complaints';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    public $timestamps = false;

    protected $fillable = [
        'order_id',
        'created_by',
        'title',
        'description',
        'status',
        'closed_at',
    ];

    protected function casts(): array
    {
        return [
            'closed_at' => 'immutable_datetime',
        ];
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class, 'order_id');
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(Profile::class, 'created_by');
    }

    public function responses(): HasMany
    {
        return $this->hasMany(ComplaintResponse::class, 'complaint_id');
    }

}
