<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Mapping du schema Supabase/PostgreSQL (Sprint 2 + Sprint 3).
 * ATTENTION : toute requete multi-restaurants doit etre filtree par restaurant_id
 * et l autorisation doit etre verifiee cote Laravel.
 */
class LoyaltyTransaction extends Model
{
    use HasUuids;

    protected $table = 'loyalty_transactions';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    public $timestamps = false;

    // Table d audit/journal : ecritures exclusivement via services securises.

    protected $fillable = [
        'loyalty_account_id',
        'restaurant_id',
        'order_id',
        'referral_id',
        'transaction_type',
        'points_delta',
        'idempotency_key',
        'expires_at',
    ];

    protected function casts(): array
    {
        return [
            'points_delta' => 'integer',
            'expires_at' => 'immutable_datetime',
        ];
    }

    public function account(): BelongsTo
    {
        return $this->belongsTo(LoyaltyAccount::class, 'loyalty_account_id');
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class, 'order_id');
    }

    public function referral(): BelongsTo
    {
        return $this->belongsTo(Referral::class, 'referral_id');
    }

}
