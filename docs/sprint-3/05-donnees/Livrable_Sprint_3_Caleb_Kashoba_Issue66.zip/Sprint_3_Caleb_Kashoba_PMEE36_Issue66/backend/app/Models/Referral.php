<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Mapping du schema Supabase/PostgreSQL (Sprint 2 + Sprint 3).
 * ATTENTION : toute requete multi-restaurants doit etre filtree par restaurant_id
 * et l autorisation doit etre verifiee cote Laravel.
 */
class Referral extends Model
{
    use HasUuids;

    protected $table = 'referrals';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';
    public $timestamps = false;

    protected $fillable = [
        'restaurant_id',
        'referrer_id',
        'referred_id',
        'code_used',
        'status',
        'qualifying_order_id',
        'rewarded_points',
        'rewarded_at',
    ];

    protected function casts(): array
    {
        return [
            'rewarded_points' => 'integer',
            'rewarded_at' => 'immutable_datetime',
        ];
    }

    public function restaurant(): BelongsTo
    {
        return $this->belongsTo(Restaurant::class, 'restaurant_id');
    }

    public function referrer(): BelongsTo
    {
        return $this->belongsTo(Profile::class, 'referrer_id');
    }

    public function referred(): BelongsTo
    {
        return $this->belongsTo(Profile::class, 'referred_id');
    }

    public function qualifyingOrder(): BelongsTo
    {
        return $this->belongsTo(Order::class, 'qualifying_order_id');
    }

}
