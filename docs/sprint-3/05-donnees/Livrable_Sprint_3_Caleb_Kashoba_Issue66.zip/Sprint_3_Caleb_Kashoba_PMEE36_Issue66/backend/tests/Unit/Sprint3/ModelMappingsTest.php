<?php

declare(strict_types=1);

namespace Tests\Unit\Sprint3;

use App\Models\Cart;
use App\Models\CartItem;
use App\Models\LoyaltyAccount;
use App\Models\Order;
use App\Models\Product;
use App\Models\Profile;
use PHPUnit\Framework\TestCase;

class ModelMappingsTest extends TestCase
{
    public function test_mappings_ciblent_les_tables_postgresql_attendues(): void
    {
        self::assertSame('carts', (new Cart())->getTable());
        self::assertSame('cart_items', (new CartItem())->getTable());
        self::assertSame('orders', (new Order())->getTable());
        self::assertSame('products', (new Product())->getTable());
        self::assertSame('profiles', (new Profile())->getTable());
        self::assertSame('loyalty_accounts', (new LoyaltyAccount())->getTable());
    }

    public function test_auth_id_n_est_pas_genere_par_le_modele_profile(): void
    {
        $profile = new Profile();
        self::assertSame('id', $profile->getKeyName());
        self::assertFalse($profile->getIncrementing());
    }

    public function test_paniers_ont_identifiants_uuid(): void
    {
        self::assertFalse((new Cart())->getIncrementing());
        self::assertFalse((new CartItem())->getIncrementing());
        self::assertSame('string', (new Cart())->getKeyType());
    }
}
