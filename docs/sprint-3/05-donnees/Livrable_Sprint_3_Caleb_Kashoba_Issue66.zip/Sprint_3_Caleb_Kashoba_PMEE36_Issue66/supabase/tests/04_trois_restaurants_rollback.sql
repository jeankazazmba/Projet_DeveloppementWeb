-- Fixture jetable 3 restaurants, sans modification persistante (ROLLBACK).
-- Sert à démontrer la séparation des catalogues avant intégration du seeder
-- définitif de la coéquipière. N'est PAS le jeu de données officiel S2.
begin;
do $$
declare
  v_r uuid;
  v_i integer;
  v_slug text;
  v_n integer;
begin
  for v_i in 1..3 loop
    v_r := gen_random_uuid();
    v_slug := 's3-demo-' || v_i::text || '-' || substr(replace(v_r::text,'-',''),1,8);
    insert into public.restaurants(id,slug,name,currency_code)
      values(v_r,v_slug,'Restaurant fictif '||v_i::text,'CDF');
    insert into public.restaurant_settings(restaurant_id,loyalty_earn_amount,
      loyalty_earn_points,loyalty_redeem_points,loyalty_redeem_value,referral_reward_points)
      values(v_r,1000 * v_i,1,15,1000,15);
    insert into public.categories(restaurant_id,name) values(v_r,'Menu fictif');
    insert into public.products(restaurant_id,category_id,name,price)
      select v_r,c.id,'Plat de démonstration '||v_i::text,(5000*v_i)::numeric
      from public.categories c where c.restaurant_id=v_r and c.name='Menu fictif';
  end loop;
  select count(*) into v_n from public.restaurants where slug like 's3-demo-%';
  if v_n<3 then raise exception 'Trois restaurants non créés'; end if;
  raise notice 'OK: 3 restaurants de démonstration / paramètres et catalogues indépendants';
end $$;
rollback;
