-- Démonstration transactionnelle SANS création d'utilisateur Auth.
-- A exécuter sur un environnement de développement et lire les NOTICE.
-- Les restaurants/produits temporaires sont annulés à la fin.
begin;
DO $$
declare
  r1 uuid := gen_random_uuid();
  r2 uuid := gen_random_uuid();
  p1 uuid := gen_random_uuid();
  cat1 uuid := gen_random_uuid();
  v_count integer;
begin
  insert into public.restaurants(id,slug,name,currency_code)
    values(r1,'s3-demo-a-' || substr(replace(r1::text,'-',''),1,9),'S3 Test A','CDF'),
          (r2,'s3-demo-b-' || substr(replace(r2::text,'-',''),1,9),'S3 Test B','CDF');
  insert into public.categories(id,restaurant_id,name)
    values(cat1,r1,'Fictif');
  insert into public.products(id,restaurant_id,category_id,name,price)
    values(p1,r1,cat1,'Produit S3 fictif',7000);
  select count(*) into v_count from public.products where id=p1 and restaurant_id=r1;
  if v_count<>1 then raise exception 'Produit non créé'; end if;
  -- Un test complet du panier nécessite un vrai client de test dans auth.users.
  raise notice 'OK: deux restaurants indépendants et produit lié au bon restaurant';
end $$;
rollback; -- GARANTI : aucune donnée de démonstration persistante.
