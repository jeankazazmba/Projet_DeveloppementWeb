-- Contrôle contractuel S3, lecture seulement, à exécuter sur toute instance.
-- Les assertions remontent une erreur si un objet vital manque.
do $$
declare n integer;
begin
  select count(*) into n from information_schema.tables
  where table_schema='public'
    and table_name in ('restaurants','profiles','staff_assignments','products',
      'orders','order_items','payments','order_status_events','complaints',
      'complaint_responses','loyalty_accounts','loyalty_transactions',
      'referrals','carts','cart_items');
  if n <> 15 then raise exception 'Tables absentes : %/15',n; end if;
  if not exists (select 1 from pg_trigger
                 where tgname='trg_sprint3_guard_complaint_review'
                   and not tgisinternal) then
    raise exception 'Trigger de validation des réclamations absent';
  end if;
  if not exists (select 1 from pg_trigger
                 where tgname='trg_log_order_status_change' and not tgisinternal) then
    raise exception 'Historisation automatique des commandes absente';
  end if;
  if not exists (select 1 from pg_policies
                 where schemaname='public'
                   and tablename='cart_items' and policyname='s3_cart_items_owner_read') then
    raise exception 'Lecture privée des paniers non configurée';
  end if;
  if not exists (select 1 from pg_policies
                 where schemaname='public'
                   and tablename='complaint_responses'
                   and policyname='complaint_responses_approved_own_read') then
    raise exception 'Lecture des réponses approuvées non configurée';
  end if;
  raise notice 'OK: socle, paniers, audit, approbation, RLS vérifiés';
end $$;
