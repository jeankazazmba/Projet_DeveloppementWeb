-- Diagnostic avant mise en service; lecture uniquement, chiffres agrégés.
select 'devises_restaurant_non_cdf' as controle, count(*) as total
from public.restaurants where currency_code<>'CDF'
union all select 'devises_commande_non_cdf', count(*)
from public.orders where currency_code<>'CDF'
union all select 'paiements_reussis_montant_incorrect', count(*)
from public.payments p join public.orders o on o.id=p.order_id
where p.status in ('succeeded','refunded')
  and (p.amount<>o.total_amount or p.currency_code<>o.currency_code)
union all select 'commandes_sous_total_different_lignes',count(*)
from public.orders o where exists (select 1 from public.order_items i where i.order_id=o.id)
  and o.subtotal <> (select coalesce(sum(i.line_total),0) from public.order_items i where i.order_id=o.id)
union all select 'reponses_approuvees_gerant_inactif', count(*)
from public.complaint_responses cr
join public.complaints c on c.id=cr.complaint_id
join public.orders o on o.id=c.order_id
where cr.review_status in ('approved','rejected')
  and not exists (select 1 from public.staff_assignments s
                  where s.restaurant_id=o.restaurant_id
                    and s.user_id=cr.reviewed_by
                    and s.staff_role='manager' and s.is_active=true);
-- Un résultat >0 est un signal à examiner, PAS une commande de suppression.
