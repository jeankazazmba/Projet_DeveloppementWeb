-- DONNEES DE DEMONSTRATION SPRINT 3 - CATALOGUES UNIQUEMENT.
-- A EXECUTER UNIQUEMENT SUR BASE SUPABASE LOCALE DE DEV, APRES MIGRATIONS.
-- PAS LE SEEDER OFFICIEL COLLEGUE (comptes, commandes, fidelite).
-- AUCUN UTILISATEUR Auth ni commande n'est cree.
-- Reexecuable sans doublons, sans ecraser le catalogue existant.
begin;
insert into public.restaurants(slug,name,currency_code,status)
values
  ('s3-demo-nord','Restaurant Demo Nord','CDF','active'),
  ('s3-demo-centre','Restaurant Demo Centre','CDF','active'),
  ('s3-demo-sud','Restaurant Demo Sud','CDF','active')
on conflict (slug) do nothing;

insert into public.restaurant_settings(restaurant_id,loyalty_earn_amount,
  loyalty_earn_points,loyalty_redeem_points,loyalty_redeem_value,referral_reward_points)
select r.id, case r.slug
  when 's3-demo-nord' then 1000
  when 's3-demo-centre' then 1500
  else 2000 end,
  1, 15, 1000, 15
from public.restaurants r where r.slug in
  ('s3-demo-nord','s3-demo-centre','s3-demo-sud')
on conflict (restaurant_id) do nothing;

insert into public.categories(restaurant_id,name,display_order)
select r.id, c.nom, c.ordre
from public.restaurants r
cross join (values ('Plats',1), ('Boissons',2)) c(nom,ordre)
where r.slug in ('s3-demo-nord','s3-demo-centre','s3-demo-sud')
on conflict (restaurant_id,name) do nothing;

with catalog as (
  select r.id as restaurant_id,c.id as category_id,v.produit,v.prix
  from public.restaurants r
  join public.categories c on c.restaurant_id=r.id
  join (values
      ('Plats','Poulet braise',12000::numeric),
      ('Plats','Riz aux legumes',9000::numeric),
      ('Boissons','Jus naturel',4000::numeric),
      ('Boissons','Eau minerale',2000::numeric)
  ) as v(categorie,produit,prix) on v.categorie=c.name
  where r.slug in ('s3-demo-nord','s3-demo-centre','s3-demo-sud')
)
insert into public.products(restaurant_id,category_id,name,price,is_active,is_available)
select restaurant_id,category_id,produit,prix,true,true from catalog a
where not exists(
 select 1 from public.products b
 where b.restaurant_id=a.restaurant_id and b.name=a.produit
);

insert into public.daily_menu_items(restaurant_id,product_id,menu_date)
select p.restaurant_id,p.id,current_date from public.products p
join public.restaurants r on r.id=p.restaurant_id
where r.slug in ('s3-demo-nord','s3-demo-centre','s3-demo-sud')
on conflict (restaurant_id,product_id,menu_date) do nothing;

insert into public.campaigns(id,restaurant_id,campaign_type,title,description,is_active)
select md5('s3-campaign-'||r.slug)::uuid,r.id,'event',
       'Evenement fictif : '||r.name,'Donnee de demonstration',true
from public.restaurants r
where r.slug in ('s3-demo-nord','s3-demo-centre','s3-demo-sud')
on conflict (id) do nothing;
commit;
-- Verify: select r.slug,count(p.id) from public.restaurants r
-- left join public.products p on p.restaurant_id=r.id
-- where r.slug like 's3-demo-%' group by r.slug;
