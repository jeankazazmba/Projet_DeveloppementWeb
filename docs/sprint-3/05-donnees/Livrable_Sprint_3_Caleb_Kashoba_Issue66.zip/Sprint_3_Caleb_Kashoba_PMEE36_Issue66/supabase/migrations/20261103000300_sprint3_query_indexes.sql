-- SPRINT 3 / PMEE-36 #66 - index complémentaires pour les API métier.
-- Les index ci-dessous sont conçus pour les filtres multi-restaurants.
-- Vérifier EXPLAIN ANALYZE et cardinalités avant de multiplier les index.
begin;
create index if not exists idx_s3_orders_restaurant_status_date
  on public.orders(restaurant_id,status,ordered_at desc);
create index if not exists idx_s3_complaints_order_status
  on public.complaints(order_id,status);
create index if not exists idx_s3_staff_restaurant_role_active
  on public.staff_assignments(restaurant_id,staff_role,is_active);
create index if not exists idx_s3_campaign_restaurant_type_active
  on public.campaigns(restaurant_id,campaign_type,starts_at desc)
  where is_active = true;
create index if not exists idx_s3_payments_order_status
  on public.payments(order_id,status);
commit;
