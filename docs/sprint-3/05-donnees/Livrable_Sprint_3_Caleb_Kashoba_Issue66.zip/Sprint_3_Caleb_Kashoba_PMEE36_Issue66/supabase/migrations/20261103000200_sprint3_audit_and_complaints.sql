-- SPRINT 3 / PMEE-36 #66 - audit des commandes et intégrité des validations.
-- IMPORTANT: L'attribution d'acteur est un audit, PAS un mécanisme d'autorisation.
-- Laravel doit authentifier Supabase Auth avant de définir app.actor_id.
begin;
do $$
begin
  if to_regprocedure('public.log_order_status_change()') is null then
    raise exception 'Trigger historique Sprint 2 absent : synchroniser le schéma V2/les migrations S2 avant S3.';
  end if;
  if to_regclass('public.complaint_responses') is null
     or to_regclass('public.staff_assignments') is null
     or to_regclass('public.orders') is null then
    raise exception 'Tables de réclamation/personnel/commandes manquantes.';
  end if;
end $$;

-- La requête Laravel peut faire, DANS LA MÊME TRANSACTION :
-- SELECT set_config('app.actor_id', '<uuid_validé>', true);
-- La connexion SQL du serveur doit être confidentielle. Le client ne fournit
-- jamais directement actor_id ; l'API le déduit du JWT Supabase vérifié.
create or replace function public.log_order_status_change()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  v_actor uuid;
begin
  v_actor := coalesce(auth.uid(),
                      nullif(current_setting('app.actor_id', true), '')::uuid);
  if tg_op = 'INSERT' then
    insert into public.order_status_events(order_id,previous_status,new_status,changed_by)
    values (new.id, null, new.status, v_actor);
  elsif new.status is distinct from old.status then
    insert into public.order_status_events(order_id,previous_status,new_status,changed_by)
    values (new.id, old.status, new.status, v_actor);
  end if;
  return new;
end; $$;

-- Le gérant actif du RESTAURANT associé à la commande doit approuver/rejeter.
-- Une réponse « proposed » peut être enregistrée par un employé; l'API contrôle
-- son identité et les permissions (responsabilité Aksa).
create function public.sprint3_guard_complaint_review()
returns trigger language plpgsql set search_path = '' as $$
declare v_restaurant uuid;
begin
  if new.review_status in ('approved','rejected') then
    if new.reviewed_by is null or new.reviewed_at is null then
      raise exception 'Décision de réclamation sans auteur ni date';
    end if;
    select o.restaurant_id into v_restaurant
    from public.complaints c join public.orders o on o.id = c.order_id
    where c.id = new.complaint_id;
    if not exists (
      select 1 from public.staff_assignments sa
      where sa.restaurant_id = v_restaurant
        and sa.user_id = new.reviewed_by
        and sa.staff_role = 'manager'
        and sa.is_active = true
    ) then
      raise exception 'Le décideur doit être un gérant actif du restaurant concerné';
    end if;
  end if;
  return new;
end; $$;
create trigger trg_sprint3_guard_complaint_review
before insert or update of complaint_id,review_status,reviewed_by,reviewed_at
on public.complaint_responses
for each row execute function public.sprint3_guard_complaint_review();

-- Évite de conserver par accident une ancienne politique RLS de lecture
-- qui exposerait des réponses non approuvées côté Supabase/PostgREST.
-- Pas de politique de lecture du personnel ici : elle relève d'Aksa/Laravel.
alter table public.complaint_responses enable row level security;
drop policy if exists complaint_responses_own_read on public.complaint_responses;
drop policy if exists complaint_responses_approved_own_read on public.complaint_responses;
create policy complaint_responses_approved_own_read
on public.complaint_responses for select to authenticated
using (
  review_status = 'approved' and exists (
    select 1 from public.complaints c
    where c.id=complaint_id and c.created_by=(select auth.uid())
  )
);
commit;
