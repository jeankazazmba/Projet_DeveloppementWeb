-- SPRINT 3 / PMEE-36 #66 - panier persistant multi-restaurants.
-- Ajouter uniquement; ne pas rejouer les migrations initiales sur le projet existant.
-- PRECONDITION: public.restaurants, public.profiles, public.products(id,restaurant_id)
-- déjà créées et versionnées. Exécuter d'abord les vérifications et tester localement.
begin;
do $$
begin
  if to_regclass('public.restaurants') is null
     or to_regclass('public.profiles') is null
     or to_regclass('public.products') is null then
    raise exception 'Sprint 2 incomplet : restaurants/profiles/products absents.';
  end if;
  if to_regclass('public.carts') is not null or to_regclass('public.cart_items') is not null then
    raise exception 'Panier déjà présent : inspecter le schéma et éviter une migration conflictuelle.';
  end if;
end $$;

-- Un seul panier courant par client et par restaurant. Un client peut avoir
-- plusieurs paniers dans des restaurants distincts; leurs lignes ne se mélangent pas.
create table public.carts (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id),
  customer_id uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (restaurant_id, customer_id),
  unique (id, restaurant_id)
);

create table public.cart_items (
  id uuid primary key default gen_random_uuid(),
  cart_id uuid not null,
  restaurant_id uuid not null,
  product_id uuid not null,
  quantity integer not null check (quantity > 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (cart_id, product_id),
  foreign key (cart_id, restaurant_id)
    references public.carts(id, restaurant_id) on delete cascade,
  foreign key (product_id, restaurant_id)
    references public.products(id, restaurant_id)
);

-- Pas de prix recopié dans le panier. Le prix courant vient de products.price
-- et doit être revalidé à la confirmation de commande par Wivine/Laravel.
-- Au checkout: conserver order_items.unit_price en snapshot transactionnel.
create index idx_carts_customer on public.carts(customer_id);
create index idx_cart_items_product on public.cart_items(product_id,restaurant_id);

create function public.sprint3_set_updated_at()
returns trigger language plpgsql set search_path = '' as $$
begin
  new.updated_at := now();
  return new;
end; $$;

create trigger trg_sprint3_cart_updated
before update on public.carts
for each row execute function public.sprint3_set_updated_at();
create trigger trg_sprint3_cart_item_updated
before update on public.cart_items
for each row execute function public.sprint3_set_updated_at();

-- Sécurité minimale: seul le propriétaire peut consulter ses paniers
-- avec un JWT Supabase. Aucune écriture directe aux clients autorisée.
alter table public.carts enable row level security;
alter table public.cart_items enable row level security;
-- Supabase peut utiliser des privilèges par défaut différents selon le projet.
-- Grant SELECT explicite ; la RLS contrôle la visibilité réelle par JWT.
grant select on public.carts, public.cart_items to authenticated;
create policy s3_cart_owner_read on public.carts for select to authenticated
  using (customer_id = (select auth.uid()));
create policy s3_cart_items_owner_read on public.cart_items for select to authenticated
  using (exists (
    select 1 from public.carts c
    where c.id = cart_id and c.restaurant_id = public.cart_items.restaurant_id
      and c.customer_id = (select auth.uid())
  ));
commit;
