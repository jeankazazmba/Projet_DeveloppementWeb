-- Lecture uniquement : vérifier que le socle du Sprint 2 est réellement présent.
-- A exécuter AVANT toute migration S3. Aucun changement n'est fait.
select n.nspname as schema, c.relname as table_name
from pg_class c join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public' and c.relkind='r'
order by c.relname;

select c.relname as table_name, t.tgname as trigger_name,
       pg_get_triggerdef(t.oid) as definition
from pg_trigger t join pg_class c on c.oid=t.tgrelid
join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public' and not t.tgisinternal
  and c.relname in ('orders','payments','products','loyalty_transactions','complaint_responses')
order by c.relname,t.tgname;

select schemaname,tablename,policyname,roles,cmd,qual
from pg_policies where schemaname='public'
order by tablename,policyname;

select t.tablename, c.relrowsecurity as row_security_enabled,
       c.relforcerowsecurity as force_row_security
from pg_tables t
join pg_class c on c.relname=t.tablename
join pg_namespace n on c.relnamespace=n.oid and n.nspname=t.schemaname
where t.schemaname='public'
order by tablename;
