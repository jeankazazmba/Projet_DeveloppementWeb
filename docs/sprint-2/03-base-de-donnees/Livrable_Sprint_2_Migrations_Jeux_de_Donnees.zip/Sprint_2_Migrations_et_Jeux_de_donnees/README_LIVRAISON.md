# MON MIAM MIAM - LIVRABLE SPRINT 2

**Périmètre :** migrations initiales PostgreSQL/Supabase et jeu de données de test multi-restaurants.
**Responsable base de données :** Caleb Kashoba. **Jeu de données :** travail collaboratif de l'équipe API/données, corrigé et intégré à la documentation.
**Date du dossier :** 04/11/2026.

## Contenu à livrer dans le dépôt GitHub

- `supabase/migrations/` : 4 migrations **initiales** (21 tables), destinées à reconstruire le schéma dans un **environnement vierge Supabase**.
- `supabase/seed/` : jeu SQL corrigé de **3 restaurants**, son `README_EXECUTION.md` et deux scripts de vérification.
- `supabase/tests/` : contrôle de structure SQL et contrôle statique.
- `docs/sprint-2/` : compte rendu, plan de vérification, preuves visuelles (captures Supabase) et description des limites.
- `RAPPORT_SPRINT2_LIVRAISON.pdf` : rapport de livraison partageable avec l'équipe.

## État réellement observé sur le Supabase existant

Sur les captures d'écran transmises après insertion : 3 restaurants, 6 catégories, 9 produits, 4 commandes, 8 lignes, 4 paiements, 4 comptes fidélité, 2 mouvements de points, 1 parrainage, 2 réclamations, 2 réponses et 11 événements de statut. Les 21 tables avaient été confirmées comme présentes avant l'insertion. Ces captures **ne démontrent pas**, à elles seules, les contrôles de montants ni l'idempotence. Les quantités peuvent évoluer après la capture.

## Attention : ne pas rejouer les migrations initiales sur le projet principal

Le projet Supabase principal possède déjà les 21 tables et les trois restaurants de test. Les quatre scripts `initial_*.sql` **ne sont pas à exécuter sur cet environnement**, car ils recréent des objets existants. Ils constituent une référence reproductible à tester sur une instance neuve ; leur suivi en tant que migrations appliquées à la base principale exige une **baseline vérifiée** du schéma distant (par exemple via un `supabase db pull` soigneusement examiné).

Ne jamais lancer de réinitialisation destructive (`migrate:fresh`, `TRUNCATE ... CASCADE`, `supabase db reset --linked`) sur ce projet principal. Les données et comptes `auth.users` ne doivent jamais être traités comme des fixtures ordinaires.

## Exécution de référence sur une copie isolée

1. Recréer le schéma depuis les 4 migrations initiales dans l'ordre, sur une instance Supabase **vierge de test**.
2. Créer les six comptes fictifs requis **via Supabase Auth** et vérifier le trigger `trg_create_profile`.
3. Vérifier `trg_log_order_status_change` ; `order_status_events` n'est jamais alimentée manuellement par le seed.
4. Dans le SQL Editor du **projet de test** : exécuter `verification_avant_seed.sql`, puis `jeu_de_donnees_test_3_restaurants_CORRIGE.sql`, puis `verification_apres_seed.sql`.
5. Exécuter `docs/sprint-2/CONTROLES_INTEGRITE_LECTURE.sql` ; corriger toute incohérence avant validation.
6. Réexécuter le seed sur la copie puis recontrôler les compteurs et l'historique pour démontrer l'idempotence. **Ce test de deuxième exécution n'est pas encore documenté comme réussi.**

## Points métiers utilisés

- Devise CDF ; barèmes de fidélité propres à chaque restaurant (le seed utilise 1 500 CDF/point pour ZeDuc@Space).
- Un compte utilisateur Supabase Auth global ; comptes de fidélité distincts par restaurant.
- Prix de ligne égal au prix du catalogue dans les fixtures ; paiement intégral.
- Suppression logique du produit ; historisation automatique des statuts par trigger.
- Réponse à une réclamation visible côté client seulement après approbation.

## État de clôture

**Jeu de données principal : inséré et comptages observés sur captures.**
**Migrations initiales : livrées en code, tests sur base vierge non attestés.**
**Tests complets de contraintes, idempotence, intégration API : à exécuter/documenter.**
**Pull Request GitHub, revue et acceptation : non attestées.**
