# Modèle de description de PR - Sprint 2 (base de données)

**Titre :** `[Sprint 2][DB] Migrations PostgreSQL initiales et jeu de test multi-restaurants`

**Périmètre :** 4 migrations SQL initiales (21 tables), jeu de données SQL corrigé à 3 restaurants et scripts de vérification.

**État constaté :** 3 restaurants, 6 catégories, 9 produits, 4 commandes, 8 lignes, 4 paiements, 11 événements de statut, 4 comptes fidélité, 2 mouvements de points, 2 réclamations (captures jointes).

**Points non démontrés :** reconstruction du schéma sur une base vierge, second passage du seed/idempotence, intégrité chiffrée des montants et tests d'API. Ne pas présenter ces points comme acquis.

**Sécurité :** ne pas exécuter les migrations initiales contre le projet Supabase principal déjà structuré. La baseline du projet principal doit être revue indépendamment.

**À reviewer :** schéma, UUID, RLS, barèmes, prix et paiements, conformité des tests SQL, gouvernance des migrations.
