# État observé - captures Supabase (3-4 novembre 2026)

Captures communiquées dans la conversation, à considérer comme **preuves visuelles de comptage et non comme procès-verbal de tests d'intégrité**.

| Donnée | Nombre observé | Appui |
|---|---:|---|
| Restaurants | 3 | capture `01_...png`, `02_...png` |
| Catégories | 6 (2 / restaurant) | capture `01_...png` |
| Produits | 9 (3 / restaurant) | capture `01_...png`, `02_...png` |
| Commandes | 4 (2 + 1 + 1) | capture `01_...png`, `02_...png` |
| Lignes de commande | 8 | capture `02_...png` |
| Paiements | 4 | capture `02_...png` |
| Comptes fidélité | 4 | capture `02_...png` |
| Mouvements de points | 2 | capture `02_...png` |
| Parrainages | 1 | capture `02_...png` |
| Réclamations et réponses | 2 chacune | capture `02_...png` |
| Événements de statut | 11 | capture `02_...png` |

**À prouver avant clôture :** requêtes de cohérence des montants et des relations, tests de second passage idempotent, reconstruction initiale sur base vierge, revue de la Pull Request par l'équipe API. Le contrôle des règles RLS et le comportement des points au remboursement sont des vérifications d'intégration distinctes.
