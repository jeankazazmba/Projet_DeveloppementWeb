-- Sprint 2 - Contrôles d'intégrité en lecture seule (04/11/2026)
-- Objectif : produire des PREUVES DE TEST ; aucune écriture, aucune suppression.
-- Exécuter chaque SELECT dans Supabase SQL Editor ou le script entier.
-- Les requêtes sur les montants sont diagnostiques, elles ne créent pas de contraintes.

-- 1. Répartition multi-restaurants
SELECT r.slug, r.currency_code,
       COUNT(DISTINCT c.id) AS categories,
       COUNT(DISTINCT p.id) AS products,
       COUNT(DISTINCT o.id) AS orders
FROM public.restaurants r
LEFT JOIN public.categories c ON c.restaurant_id = r.id
LEFT JOIN public.products p ON p.restaurant_id = r.id
LEFT JOIN public.orders o ON o.restaurant_id = r.id
GROUP BY r.id, r.slug, r.currency_code ORDER BY r.slug;

-- 2. Incohérence des prix dans le jeu de démonstration : 0 ligne attendue
SELECT oi.id AS order_item_id, oi.order_id, oi.unit_price, p.price AS catalogue_price
FROM public.order_items oi JOIN public.products p ON p.id = oi.product_id
WHERE oi.unit_price <> p.price;

-- 3. Incohérences sous-total / somme des lignes : 0 ligne attendue
SELECT o.id AS order_id, o.subtotal,
       COALESCE(SUM(oi.line_total), 0) AS total_lignes
FROM public.orders o LEFT JOIN public.order_items oi ON oi.order_id=o.id
GROUP BY o.id, o.subtotal
HAVING o.subtotal <> COALESCE(SUM(oi.line_total),0);

-- 4. Paiements réussis incohérents : 0 ligne attendue
SELECT p.id, p.order_id, p.amount, o.total_amount,
       p.currency_code AS devise_paiement, o.currency_code AS devise_commande
FROM public.payments p JOIN public.orders o ON o.id=p.order_id
WHERE p.status='succeeded'
  AND (p.amount<>o.total_amount OR p.currency_code<>o.currency_code);

-- 5. Panachage inter-restaurants dans les lignes : 0 ligne attendue
SELECT oi.id, oi.restaurant_id, o.restaurant_id AS restaurant_commande,
       p.restaurant_id AS restaurant_produit
FROM public.order_items oi
JOIN public.orders o ON o.id=oi.order_id
JOIN public.products p ON p.id=oi.product_id
WHERE oi.restaurant_id <> o.restaurant_id OR oi.restaurant_id <> p.restaurant_id;

-- 6. Historique : nombre d'événements par commande ; absence = point d'alerte
SELECT o.id, o.status, COUNT(e.id) AS nombre_evenements,
       MIN(e.changed_at) AS premier_evenement, MAX(e.changed_at) AS dernier_evenement
FROM public.orders o LEFT JOIN public.order_status_events e ON e.order_id=o.id
GROUP BY o.id,o.status ORDER BY o.id;

-- 7. Comptes fidélité sans cohérence solde / journal : 0 ligne attendue POUR LE JEU TEST INITIAL
-- Un historique antérieur migré pourrait expliquer un écart sur d'autres environnements.
SELECT a.id, a.restaurant_id, a.user_id, a.balance_points,
       COALESCE(SUM(t.points_delta),0) AS somme_mouvements
FROM public.loyalty_accounts a
LEFT JOIN public.loyalty_transactions t ON t.loyalty_account_id=a.id
GROUP BY a.id,a.restaurant_id,a.user_id,a.balance_points
HAVING a.balance_points<>COALESCE(SUM(t.points_delta),0);

-- 8. Déclencheur d'audit et activation (O = actif en mode normal)
SELECT tgname, tgenabled FROM pg_trigger
WHERE tgrelid='public.orders'::regclass
  AND tgname='trg_log_order_status_change' AND NOT tgisinternal;

-- 9. Idempotence : noter les compteurs, relancer le SEED UNIQUEMENT EN TEST ISOLE puis comparer.
SELECT (SELECT count(*) FROM public.orders) AS nb_commandes,
       (SELECT count(*) FROM public.order_status_events) AS nb_evenements,
       (SELECT count(*) FROM public.loyalty_transactions) AS nb_mouvements,
       (SELECT count(*) FROM public.payments) AS nb_paiements;
