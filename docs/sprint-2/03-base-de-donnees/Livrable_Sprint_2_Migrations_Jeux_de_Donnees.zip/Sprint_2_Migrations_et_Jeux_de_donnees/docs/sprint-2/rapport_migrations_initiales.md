# Rapport technique — Migrations initiales PostgreSQL

**Projet :** Mon Miam Miam  
**Sprint :** 2 — Migrations et jeux de données  
**Environnement cible :** Supabase PostgreSQL + Supabase Auth ; Laravel utilisé pour les API et les seeders.  
**Date de préparation :** 29 octobre 2026  
**Périmètre :** migrations *initiales* pour base vierge — aucun accès ni modification du projet Supabase principal.

## 1. Résultats

Quatre migrations SQL ordonnées ont été rédigées. Elles couvrent :

| Mesure | Résultat vérifié sur les fichiers |
|---|---:|
| Tables du schéma `public` | 21 |
| Colonnes métier | 161 |
| Déclarations `REFERENCES` | 39 |
| Fonctions PostgreSQL personnalisées | 6 |
| Triggers personnalisés | 6 |
| Politiques RLS de lecture | 21 |
| Tables soumises à RLS | 21 |

Ces chiffres proviennent d'une **analyse statique des fichiers générés** ; la création effective dans PostgreSQL devra être testée par l'équipe.

## 2. Choix de conception

### Cohérence avec l'issue #25

Le socle préserve : comptes Supabase Auth, rôle du personnel par restaurant, commandes et lignes d'un seul restaurant, codes de parrainage par restaurant, soldes de fidélité non transférables, règles de traçabilité et politiques de lecture.

### Décisions intégrées depuis le schéma V2

1. Devise `CDF`, avec valeurs par défaut et contraintes sur restaurants, commandes et paiements.
2. Paiement intégral : une réussite par commande et contrôle de concordance montant/devise.
3. Suppression de produit uniquement logique (`is_active`), blocage de `DELETE` physique.
4. Réponses aux réclamations accessibles au client seulement après approbation, avec identité et date du réviseur.
5. Historique des changements de statut produit par trigger.
6. Unicité des mouvements de fidélité importants (gains commande, débit de points par commande, bonus de parrainage).

## 3. Frontière entre base et backend

**Les migrations seules ne créditent, ne débitent et ne restituent pas automatiquement des points.** Le backend Laravel doit réaliser ces opérations au sein de transactions atomiques, après vérification du paiement, du service ou de la livraison. Le cas exceptionnel de remboursement de points déjà dépensés est exclu du périmètre par décision explicite, et le schéma protège malgré tout la colonne `balance_points` contre un solde négatif.

Le backend doit aussi vérifier les droits du personnel, les transitions de statut, les calculs des montants et l'absence de doublons entre journal de statuts automatique et mises à jour applicatives.

## 4. Intégration avec le dépôt et l'équipe API

- Chemin prévu : `supabase/migrations/` à la racine du dépôt GitHub.
- Le développeur API doit mapper les noms JSON français vers les noms SQL anglais et accepter les UUID.
- Les seeders Laravel devront utiliser des comptes authentifiés existant dans `auth.users` et des données fictives en CDF.
- Le service Laravel utilisera Supabase Auth pour vérifier les utilisateurs, et non un second système d'authentification non coordonné.

## 5. Validation et risque restant

**Aucun déploiement Supabase ni test d'exécution n'a été effectué.** Les quatre migrations ne doivent pas être rejouées sur le projet principal déjà initialisé. Pour ce dernier, capturer la baseline réelle avec `supabase db pull`, vérifier le résultat, puis prévoir les migrations correctives séparées après comparaison avec la cible.

**Tests à effectuer avant clôture :** reconstruction sur base locale vierge, exécution des requêtes de contrôle, insertion de données fictives, tests des contraintes (multi-restaurants, paiement, rôles, points), revue de l'équipe API et Pull Request.
