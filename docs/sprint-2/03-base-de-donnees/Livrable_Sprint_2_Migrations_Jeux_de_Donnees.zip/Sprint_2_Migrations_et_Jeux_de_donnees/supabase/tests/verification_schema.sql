-- VERIFICATIONS EN LECTURE SEULE - aucune table ni donnee modifiee.
-- A executer sur une base neuve APRES les quatre migrations.

-- 1. Inventaire des tables : attendu = 21.
select count(*) as nombre_tables_metier
from information_schema.tables
where table_schema = 'public' and table_type = 'BASE TABLE'
  and table_name = any (array[
    'restaurants', 'profiles', 'staff_assignments', 'restaurant_settings',
    'categories', 'products', 'daily_menu_items', 'orders', 'order_items',
    'order_status_events', 'deliveries', 'payments', 'referral_codes',
    'referrals', 'loyalty_accounts', 'loyalty_transactions', 'complaints',
    'complaint_responses', 'campaigns', 'campaign_participations',
    'cookie_consents'
]);

-- 2. Inventaire des colonnes : attendu = 161 sur ces 21 tables.
select count(*) as nombre_colonnes_metier
from information_schema.columns
where table_schema = 'public'
  and table_name = any (array[
    'restaurants', 'profiles', 'staff_assignments', 'restaurant_settings',
    'categories', 'products', 'daily_menu_items', 'orders', 'order_items',
    'order_status_events', 'deliveries', 'payments', 'referral_codes',
    'referrals', 'loyalty_accounts', 'loyalty_transactions', 'complaints',
    'complaint_responses', 'campaigns', 'campaign_participations',
    'cookie_consents'
]);

-- 3. Politique RLS active : attendu 21 sur 21.
select c.relname as table_name, c.relrowsecurity as rls_active
from pg_class c join pg_namespace n on n.oid = c.relnamespace
where n.nspname = 'public' and c.relkind = 'r'
  and c.relname = any (array[
    'restaurants', 'profiles', 'staff_assignments', 'restaurant_settings',
    'categories', 'products', 'daily_menu_items', 'orders', 'order_items',
    'order_status_events', 'deliveries', 'payments', 'referral_codes',
    'referrals', 'loyalty_accounts', 'loyalty_transactions', 'complaints',
    'complaint_responses', 'campaigns', 'campaign_participations',
    'cookie_consents'
])
order by c.relname;

-- 4. Contraintes de paiement et de points (les 4 index doivent exister).
select indexname, indexdef
from pg_indexes
where schemaname = 'public' and indexname in (
    'uq_payments_one_completed_per_order',
    'uq_loyalty_order_earn', 'uq_loyalty_order_redeem', 'uq_referral_bonus_once'
)
order by indexname;

-- 5. Les quatre fonctions d'integrite + fonction Supabase Auth.
select p.proname as function_name
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public'
  and p.proname in (
    'handle_new_auth_user', 'validate_loyalty_transaction_owner',
    'validate_full_payment', 'prevent_paid_order_amount_change',
    'log_order_status_change'
)
order by p.proname;

-- 6. Verifier que les devises par defaut sont CDF.
select table_name, column_default
from information_schema.columns
where table_schema = 'public' and column_name = 'currency_code'
  and table_name in ('restaurants','orders','payments')
order by table_name;

-- 7. Verifier l'existence de la lecture privee des reponses approuvees.
select schemaname, tablename, policyname, cmd, roles, qual
from pg_policies
where schemaname = 'public' and tablename = 'complaint_responses';
