"""Controle statique du contenu des quatre migrations initiales.
Ne remplace PAS un test d'execution sur PostgreSQL.
Lancer : python supabase/tests/verification_statique.py
"""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1] / 'migrations'
files = sorted(root.glob('*.sql'))
assert len(files) == 4, f'4 migrations attendues, {len(files)} trouvees'
sql = '\n'.join(p.read_text(encoding='utf-8') for p in files)
parts = re.findall(r'create table public\.([a-z_]+)\s*\(\n([\s\S]*?)\n\);', sql, re.I)
assert len(parts) == 21, f'21 tables attendues, {len(parts)} trouvees'
assert len({n for n, _ in parts}) == len(parts), 'Noms de tables repetes'
col_count = 0
ref_count = 0
for name, block in parts:
    cols = [line for line in block.splitlines()
            if re.match(r'^    [a-z][a-z_0-9]* ', line)
            and line.strip().split()[0].lower() not in ('check', 'foreign', 'unique', 'primary')]
    col_count += len(cols)
    ref_count += len(re.findall(r'\breferences\b', block, re.I))
assert col_count == 161, f'161 colonnes attendues, {col_count} trouvees'
assert ref_count == 39, f'39 REFERENCES attendus, {ref_count} trouves'
funcs = re.findall(r'create function public\.([a-z_]+)', sql, re.I)
triggers = re.findall(r'create trigger ([a-z_]+)', sql, re.I)
policies = re.findall(r'create policy ([a-z_]+)', sql, re.I)
assert len(funcs) == 6, f'6 fonctions attendues, {len(funcs)} trouvees'
assert len(triggers) == 6, f'6 triggers attendus, {len(triggers)} trouves'
assert len(policies) == 21, f'21 politiques attendues, {len(policies)} trouvees'
assert sql.count("default 'CDF'") == 3, 'CDF attendu dans les trois tables monetaires'
assert 'uq_payments_one_completed_per_order' in sql
assert 'complaint_responses_approved_own_read' in sql
assert 'trg_prevent_product_physical_delete' in sql
print('VERIFICATION STATIQUE OK')
print(f'{len(files)} migrations, {len(parts)} tables, {col_count} colonnes, '
      f'{ref_count} references, {len(funcs)} fonctions, {len(triggers)} triggers, '
      f'{len(policies)} policies RLS.')
