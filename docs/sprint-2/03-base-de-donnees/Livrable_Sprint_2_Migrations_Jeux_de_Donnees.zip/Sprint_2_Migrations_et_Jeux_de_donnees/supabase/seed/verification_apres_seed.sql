-- CONTROLE APRES INSERTION, SANS MODIFICATION DES DONNEES
SELECT (SELECT count(*) FROM public.restaurants WHERE id::text LIKE '10000000-%') AS restaurants_seed,
       (SELECT count(*) FROM public.products WHERE id::text LIKE '30000000-%') AS produits_seed,
       (SELECT count(*) FROM public.orders WHERE id::text LIKE '50000000-%') AS commandes_seed,
       (SELECT count(*) FROM public.order_items WHERE id::text LIKE '60000000-%') AS lignes_seed,
       (SELECT count(*) FROM public.payments WHERE id::text LIKE '80000000-%') AS paiements_seed,
       (SELECT count(*) FROM public.loyalty_accounts WHERE id::text LIKE '91000000-%') AS comptes_fidelite_seed,
       (SELECT count(*) FROM public.loyalty_transactions WHERE id::text LIKE '94000000-%') AS mouvements_points_seed;

-- 0 ligne attendue : écart de prix par rapport au catalogue
SELECT oi.id,oi.unit_price,p.price AS prix_catalogue
FROM public.order_items oi JOIN public.products p ON p.id=oi.product_id
WHERE oi.id::text LIKE '60000000-%' AND oi.unit_price<>p.price;

-- 0 ligne attendue : incohérences des sous-totaux
SELECT o.id,o.subtotal,sum(oi.line_total) AS lignes_total
FROM public.orders o JOIN public.order_items oi ON oi.order_id=o.id
WHERE o.id::text LIKE '50000000-%'
GROUP BY o.id,o.subtotal HAVING o.subtotal<>sum(oi.line_total);

-- 0 ligne attendue : paiement réussi d'un montant différent du total
SELECT p.id,p.order_id,p.amount,o.total_amount
FROM public.payments p JOIN public.orders o ON o.id=p.order_id
WHERE p.id::text LIKE '80000000-%' AND p.status='succeeded'
AND (p.amount<>o.total_amount OR p.currency_code<>o.currency_code);

-- Historique automatique : au moins un événement par commande, sans duplication
SELECT o.id,o.status,count(e.id) AS evenements
FROM public.orders o LEFT JOIN public.order_status_events e ON e.order_id=o.id
WHERE o.id::text LIKE '50000000-%'
GROUP BY o.id,o.status ORDER BY o.id;

-- Une ligne par paire restaurant/client
SELECT restaurant_id,user_id,count(*) FROM public.loyalty_accounts
WHERE id::text LIKE '91000000-%' GROUP BY 1,2 HAVING count(*)>1;

-- Vérifie les solde de démonstration par rapport à leur journal, 0 ligne attendue
SELECT a.id,a.balance_points,coalesce(sum(t.points_delta),0) AS mouvement_total
FROM public.loyalty_accounts a LEFT JOIN public.loyalty_transactions t
ON t.loyalty_account_id=a.id
WHERE a.id::text LIKE '91000000-%'
GROUP BY a.id,a.balance_points HAVING a.balance_points<>coalesce(sum(t.points_delta),0);
