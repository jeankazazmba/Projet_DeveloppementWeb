-- CONTROLE PREALABLE NON DESTRUCTIF — exécuter avant le seed
SELECT table_name FROM information_schema.tables
WHERE table_schema='public' AND table_name IN (
 'restaurants','profiles','staff_assignments','restaurant_settings','categories',
 'products','daily_menu_items','orders','order_items','order_status_events',
 'deliveries','payments','referral_codes','referrals','loyalty_accounts',
 'loyalty_transactions','complaints','complaint_responses','campaigns',
 'campaign_participations','cookie_consents') ORDER BY table_name;

SELECT tgname, tgenabled FROM pg_trigger
WHERE tgname IN ('trg_log_order_status_change','trg_create_profile')
AND NOT tgisinternal;

SELECT slug,id,name FROM public.restaurants
WHERE slug IN ('zeduc-space','chez-mado','saveurs-du-fleuve');

SELECT lower(email) AS email,id FROM auth.users
WHERE lower(email) IN ('client1@monmiam.test','client2@monmiam.test',
'client3@monmiam.test','employe@monmiam.test','gerant@monmiam.test',
'admin@monmiam.test');
