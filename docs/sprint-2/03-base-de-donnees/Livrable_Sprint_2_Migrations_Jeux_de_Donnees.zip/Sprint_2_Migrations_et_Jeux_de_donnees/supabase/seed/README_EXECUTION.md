# Mon Miam Miam — Jeu de données corrigé (Sprint 2)

## Contenu

Ce dossier corrige le SQL transmis le 30/10/2026 sans modifier les migrations ni supprimer les tables. Le seed cible les **21 tables métier** du schéma PostgreSQL initial Supabase, et contient **3 restaurants, 9 produits, 4 commandes, 8 lignes de commande, 4 paiements, 4 comptes de fidélité, 2 mouvements de points, 1 parrainage, 2 réclamations, 2 réponses, 3 campagnes, 1 participation et 1 consentement**.

## Modifications apportées

- Prix du Liboke de poisson corrigé à **16 000 CDF**, commande correspondante à **17 500 CDF**, paiement en attente à **17 500 CDF**.
- Pour les exemples, `order_items.unit_price` correspond systématiquement à `products.price`.
- Une commande supplémentaire `completed` et payée a été ajoutée pour illustrer la fidélité : **15 000 CDF / 1 500 CDF = 10 points** (barème pilote retenu). Le parrain fictif obtient **15 points**.
- Le modèle reste multi-restaurants : un seul compte utilisateur Supabase Auth, des comptes de fidélité distincts selon le restaurant.
- Aucun `INSERT` manuel dans `order_status_events` ; l'historisation doit être assurée par `trg_log_order_status_change`, dont la présence est contrôlée avant toute insertion.
- Clés de test fixes, date de menu fixée au **03/11/2026**, `ON CONFLICT ... DO NOTHING` plutôt que des mises à jour destructrices ; transitions de statut conditionnelles. Une seconde exécution ne doit pas ajouter de données ni d'événements de statut.
- Réclamations approuvée et en attente ; campagnes, participation et consentement ajoutés.

## Prérequis impératifs

1. **Ne pas exécuter sur la base principale contenant des données non sauvegardées.** Ce jeu de données est destiné à une copie isolée de développement, après sauvegarde.
2. Vérifier que la structure des 21 tables correspond aux migrations de Sprint 2 et que les migrations complémentaires Sprint 3 pertinentes sont connues. Les anciens schémas V2 sans déclencheur d'historisation font échouer le contrôle préalable (volontairement).
3. Créer **dans Supabase Auth** six comptes fictifs avec ces emails : `client1@monmiam.test`, `client2@monmiam.test`, `client3@monmiam.test`, `employe@monmiam.test`, `gerant@monmiam.test`, `admin@monmiam.test`. Leurs profils doivent exister dans `public.profiles`.
4. **Ne pas inventer d'identifiant dans `auth.users`** ; les UUID réels de ces comptes sont récupérés par email dans le script.
5. Les trois slugs `zeduc-space`, `chez-mado`, `saveurs-du-fleuve` doivent être libres ou porter exactement les UUID de démonstration. Sinon le script s'arrête pour demander un nettoyage contrôlé.
6. Les fichiers `.sql` ne sont **pas des migrations**, ni des opérations de remboursement/points produites par l'API métier. Les états de fidélité sont des snapshots de test cohérents avec les mouvements, et ne prouvent pas l'automatisation du calcul.

## Exécution recommandée

- Sur une **copie de base de test**, exécuter d'abord `verification_avant_seed.sql`.
- Puis exécuter `jeu_de_donnees_test_3_restaurants_CORRIGE.sql` dans le SQL Editor Supabase avec un rôle disposant des droits nécessaires. Aucune clé secrète n'est demandée dans les fichiers.
- Exécuter `verification_apres_seed.sql` et contrôler les résultats ; relancer le seed une deuxième fois puis le contrôle, et comparer les compteurs.
- Conserver les preuves d'exécution (captations des résultats et erreurs éventuelles) pour Jira/GitHub.

## Ce qui reste à tester avec le backend

- Transitions métier autorisées, paiement intégral, crédit/débit/remboursement de points, autorisations RLS/RBAC, et lecture uniquement des réponses de réclamation approuvées.
- L'authentification via Supabase Auth des comptes `@monmiam.test` dépend de la configuration de votre projet : ces adresses fictives ne reçoivent pas d'emails réels.
- La règle de solde insuffisant lors d'un remboursement de points **n'a pas été arbitrée** ; elle n'est pas simulée.

## Avertissement important

Une première exécution vide puis une deuxième exécution ne vérifient pas toutes les sources de conflits possibles. Le script est conçu pour être idempotent sur son propre jeu, **pas** pour fusionner arbitrairement des données préexistantes. Ne pas utiliser `migrate:fresh`, `TRUNCATE ... CASCADE` ou un nettoyage global sans audit préalable.
