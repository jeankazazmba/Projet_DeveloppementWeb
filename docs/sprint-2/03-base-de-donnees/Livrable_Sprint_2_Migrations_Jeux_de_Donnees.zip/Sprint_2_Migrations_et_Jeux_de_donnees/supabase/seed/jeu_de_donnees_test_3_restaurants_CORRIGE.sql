-- VERSION CORRIGÉE — 03/11/2026 — Sprint 2 / vérification Sprint 3
-- ============================================================
-- MON MIAM MIAM - JEU DE DONNEES DE TEST (3 RESTAURANTS)
-- Référence : dictionnaire-donnees.md / MLD fourni par Caleb
-- Cible : PostgreSQL / Supabase, schéma public
--
-- IMPORTANT :
-- 1) Créer au préalable ces 6 comptes dans Supabase Auth :
--    client1@monmiam.test, client2@monmiam.test, client3@monmiam.test
--    employe@monmiam.test, gerant@monmiam.test, admin@monmiam.test
-- 2) Le trigger trg_create_profile doit créer leurs lignes dans public.profiles.
-- 3) Ce script n'insère AUCUNE ligne dans order_status_events :
--    l'historisation est laissée au trigger automatique demandé par Caleb.
-- 4) Vérifier avec Caleb que ce trigger existe réellement avant les tests.
-- 5) Les données sont fictives et destinées uniquement aux tests.
-- ============================================================

BEGIN;

DO $$
DECLARE
    required_email text;
BEGIN
    FOREACH required_email IN ARRAY ARRAY[
        'client1@monmiam.test', 'client2@monmiam.test',
        'client3@monmiam.test', 'employe@monmiam.test',
        'gerant@monmiam.test', 'admin@monmiam.test'
    ]
    LOOP
        IF NOT EXISTS (SELECT 1 FROM auth.users WHERE lower(email) = required_email) THEN
            RAISE EXCEPTION 'Compte Supabase Auth manquant : %. Créez les 6 comptes indiqués dans le README puis relancez le script.', required_email;
        END IF;
    END LOOP;
END $$;

-- CONTROLES PREALABLES : aucun changement avant cette étape.
-- Exécution UNIQUEMENT sur une base de TEST isolée avec sauvegarde.
DO $$
DECLARE v_rest record; v_auth_count integer;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger
      WHERE tgrelid='public.orders'::regclass AND tgname='trg_log_order_status_change' AND NOT tgisinternal AND tgenabled <> 'D') THEN
    RAISE EXCEPTION 'Déclencheur trg_log_order_status_change absent ou désactivé. Installer la migration d''historisation avant le seed.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_trigger
      WHERE tgrelid='auth.users'::regclass AND tgname='trg_create_profile' AND NOT tgisinternal AND tgenabled <> 'D') THEN
    RAISE EXCEPTION 'Déclencheur Supabase Auth -> profiles absent.';
  END IF;
  FOR v_rest IN SELECT * FROM (VALUES
    ('zeduc-space','10000000-0000-4000-8000-000000000001'::uuid),
    ('chez-mado','10000000-0000-4000-8000-000000000002'::uuid),
    ('saveurs-du-fleuve','10000000-0000-4000-8000-000000000003'::uuid)
  ) AS x(slug,id) LOOP
    IF EXISTS (SELECT 1 FROM public.restaurants WHERE slug=v_rest.slug AND id<>v_rest.id) THEN
      RAISE EXCEPTION 'Restaurant % existe avec un autre UUID : nettoyage contrôlé requis, aucune suppression automatique',v_rest.slug;
    END IF;
  END LOOP;
  IF EXISTS (SELECT 1 FROM public.restaurants WHERE id IN
    ('10000000-0000-4000-8000-000000000001'::uuid,'10000000-0000-4000-8000-000000000002'::uuid,'10000000-0000-4000-8000-000000000003'::uuid)
    AND slug NOT IN ('zeduc-space','chez-mado','saveurs-du-fleuve')) THEN
    RAISE EXCEPTION 'UUID de démonstration déjà attribué à un autre restaurant';
  END IF;
END $$;

-- Les six profils doivent déjà exister via Supabase Auth. Ne pas modifier leurs profils.
DO $$
BEGIN
 IF (SELECT count(*) FROM public.profiles p JOIN auth.users u ON u.id=p.id
     WHERE lower(u.email) IN ('client1@monmiam.test','client2@monmiam.test','client3@monmiam.test',
       'employe@monmiam.test','gerant@monmiam.test','admin@monmiam.test')) <> 6 THEN
   RAISE EXCEPTION 'Un ou plusieurs profils manquent : vérifier trg_create_profile';
 END IF;
END $$;

-- Protection : ce seed est prévu pour un environnement neuf/nettoyé.
-- Toute présence d'enregistrements portant les UUID réservés du seed exige une validation
-- manuelle de leur provenance ; les ON CONFLICT ne doivent jamais servir à les écraser.
-- Aucune suppression, aucun TRUNCATE et aucun DROP n'est effectué ici.

-- 1. Trois restaurants : le pilote et deux restaurants fictifs de test.
INSERT INTO public.restaurants
(id, slug, name, address, phone, email, currency_code, status)
VALUES
('10000000-0000-4000-8000-000000000001', 'zeduc-space', 'ZeDuc@Space', 'Kinshasa - adresse de démonstration', '+243810100001', 'contact@zeduc.test', 'CDF', 'active'),
('10000000-0000-4000-8000-000000000002', 'chez-mado', 'Chez Mado', 'Kinshasa - adresse de démonstration', '+243810100002', 'contact@mado.test', 'CDF', 'active'),
('10000000-0000-4000-8000-000000000003', 'saveurs-du-fleuve', 'Saveurs du Fleuve', 'Kinshasa - adresse de démonstration', '+243810100003', 'contact@fleuve.test', 'CDF', 'active')
ON CONFLICT (id) DO NOTHING;

-- 2. Paramètres de fidélité : barèmes distincts par restaurant, montants en CDF.
INSERT INTO public.restaurant_settings
(restaurant_id, opening_hours, loyalty_earn_amount, loyalty_earn_points,
 loyalty_redeem_points, loyalty_redeem_value, referral_reward_points,
 loyalty_expiration_months)
VALUES
('10000000-0000-4000-8000-000000000001', '{"lun-dim":"08:00-22:00"}', 1500, 1, 15, 1000, 15, 12),
('10000000-0000-4000-8000-000000000002', '{"lun-dim":"09:00-21:00"}', 2000, 1, 20, 1000, 15, 12),
('10000000-0000-4000-8000-000000000003', '{"lun-dim":"08:00-23:00"}', 1000, 1, 15, 1000, 15, 12)
ON CONFLICT (restaurant_id) DO NOTHING;

-- 3. Affectations du personnel (rôles autorisés par le dictionnaire).
INSERT INTO public.staff_assignments
(id, restaurant_id, user_id, staff_role, is_active)
SELECT v.id::uuid, v.restaurant_id::uuid, u.id, v.staff_role, true
FROM (VALUES
 ('11000000-0000-4000-8000-000000000001','10000000-0000-4000-8000-000000000001','employe@monmiam.test','employee'),
 ('11000000-0000-4000-8000-000000000002','10000000-0000-4000-8000-000000000001','gerant@monmiam.test','manager'),
 ('11000000-0000-4000-8000-000000000003','10000000-0000-4000-8000-000000000002','employe@monmiam.test','employee'),
 ('11000000-0000-4000-8000-000000000004','10000000-0000-4000-8000-000000000003','admin@monmiam.test','admin')
) AS v(id, restaurant_id, email, staff_role)
JOIN auth.users u ON lower(u.email) = v.email
ON CONFLICT (restaurant_id, user_id) DO NOTHING;

-- 4. Catégories.
INSERT INTO public.categories (id, restaurant_id, name, display_order) VALUES
('20000000-0000-4000-8000-000000000001','10000000-0000-4000-8000-000000000001','Plats',1),
('20000000-0000-4000-8000-000000000002','10000000-0000-4000-8000-000000000001','Boissons',2),
('20000000-0000-4000-8000-000000000003','10000000-0000-4000-8000-000000000002','Plats',1),
('20000000-0000-4000-8000-000000000004','10000000-0000-4000-8000-000000000002','Desserts',2),
('20000000-0000-4000-8000-000000000005','10000000-0000-4000-8000-000000000003','Plats',1),
('20000000-0000-4000-8000-000000000006','10000000-0000-4000-8000-000000000003','Boissons',2)
ON CONFLICT (id) DO NOTHING;

-- 5. Produits : trois produits par restaurant.
INSERT INTO public.products
(id, restaurant_id, category_id, name, description, price, is_available, is_active)
VALUES
('30000000-0000-4000-8000-000000000001','10000000-0000-4000-8000-000000000001','20000000-0000-4000-8000-000000000001','Poulet braisé','Portion de poulet braisé',12000,true,true),
('30000000-0000-4000-8000-000000000002','10000000-0000-4000-8000-000000000001','20000000-0000-4000-8000-000000000001','Poisson braisé','Poisson accompagné',15000,true,true),
('30000000-0000-4000-8000-000000000003','10000000-0000-4000-8000-000000000001','20000000-0000-4000-8000-000000000002','Jus naturel','Jus de fruit',3000,true,true),
('30000000-0000-4000-8000-000000000004','10000000-0000-4000-8000-000000000002','20000000-0000-4000-8000-000000000003','Riz au poulet','Riz accompagné de poulet',10000,true,true),
('30000000-0000-4000-8000-000000000005','10000000-0000-4000-8000-000000000002','20000000-0000-4000-8000-000000000004','Salade de fruits','Dessert frais',5000,true,true),
('30000000-0000-4000-8000-000000000006','10000000-0000-4000-8000-000000000002','20000000-0000-4000-8000-000000000003','Frites maison','Portion de frites',4000,true,true),
('30000000-0000-4000-8000-000000000007','10000000-0000-4000-8000-000000000003','20000000-0000-4000-8000-000000000005','Poulet mayo','Poulet et accompagnement',13000,true,true),
('30000000-0000-4000-8000-000000000008','10000000-0000-4000-8000-000000000003','20000000-0000-4000-8000-000000000005','Liboke de poisson','Poisson en papillote',16000,true,true),
('30000000-0000-4000-8000-000000000009','10000000-0000-4000-8000-000000000003','20000000-0000-4000-8000-000000000006','Eau minérale','Bouteille',1500,true,true)
ON CONFLICT (id) DO NOTHING;

-- 6. Menus de démonstration, date FIXE pour garantir la réexécution sans dérive.
INSERT INTO public.daily_menu_items (id, restaurant_id, product_id, menu_date)
VALUES
('40000000-0000-4000-8000-000000000001','10000000-0000-4000-8000-000000000001','30000000-0000-4000-8000-000000000001',DATE '2026-11-03'),
('40000000-0000-4000-8000-000000000002','10000000-0000-4000-8000-000000000002','30000000-0000-4000-8000-000000000004',DATE '2026-11-03'),
('40000000-0000-4000-8000-000000000003','10000000-0000-4000-8000-000000000003','30000000-0000-4000-8000-000000000007',DATE '2026-11-03')
ON CONFLICT (id) DO NOTHING;

-- 7. Quatre commandes de démonstration (trois restaurants, dont une terminée).
-- Les totaux sont calculés par la colonne GENERATED ALWAYS de la table orders.
INSERT INTO public.orders
(id, restaurant_id, customer_id, status, service_mode, customer_note,
 currency_code, subtotal, delivery_fee, loyalty_discount, ordered_at)
SELECT v.order_id::uuid, v.restaurant_id::uuid, u.id, v.status, v.service_mode, v.note,
       'CDF', v.subtotal, v.delivery_fee, 0, now() - v.age
FROM (VALUES
 ('50000000-0000-4000-8000-000000000001','10000000-0000-4000-8000-000000000001','client1@monmiam.test','pending','on_site','Sans piment',15000,0,interval '2 hours'),
 ('50000000-0000-4000-8000-000000000002','10000000-0000-4000-8000-000000000002','client2@monmiam.test','pending','delivery','Appeler à l''arrivée',14000,2000,interval '1 hour'),
 ('50000000-0000-4000-8000-000000000003','10000000-0000-4000-8000-000000000003','client3@monmiam.test','pending','on_site','Commande de test',17500,0,interval '15 minutes'),
 ('50000000-0000-4000-8000-000000000004','10000000-0000-4000-8000-000000000001','client1@monmiam.test','pending','on_site','Commande terminée pour fidélité',15000,0,interval '1 day')
) AS v(order_id, restaurant_id, email, status, service_mode, note, subtotal, delivery_fee, age)
JOIN auth.users u ON lower(u.email) = v.email
ON CONFLICT (id) DO NOTHING;

-- 8. Lignes de commandes : prix unitaires égaux aux prix du catalogue.
INSERT INTO public.order_items
(id, order_id, restaurant_id, product_id, product_name_snapshot, quantity, unit_price)
VALUES
('60000000-0000-4000-8000-000000000001','50000000-0000-4000-8000-000000000001','10000000-0000-4000-8000-000000000001','30000000-0000-4000-8000-000000000001','Poulet braisé',1,12000),
('60000000-0000-4000-8000-000000000002','50000000-0000-4000-8000-000000000001','10000000-0000-4000-8000-000000000001','30000000-0000-4000-8000-000000000003','Jus naturel',1,3000),
('60000000-0000-4000-8000-000000000003','50000000-0000-4000-8000-000000000002','10000000-0000-4000-8000-000000000002','30000000-0000-4000-8000-000000000004','Riz au poulet',1,10000),
('60000000-0000-4000-8000-000000000004','50000000-0000-4000-8000-000000000002','10000000-0000-4000-8000-000000000002','30000000-0000-4000-8000-000000000006','Frites maison',1,4000),
('60000000-0000-4000-8000-000000000005','50000000-0000-4000-8000-000000000003','10000000-0000-4000-8000-000000000003','30000000-0000-4000-8000-000000000008','Liboke de poisson',1,16000),
('60000000-0000-4000-8000-000000000006','50000000-0000-4000-8000-000000000003','10000000-0000-4000-8000-000000000003','30000000-0000-4000-8000-000000000009','Eau minérale',1,1500),
('60000000-0000-4000-8000-000000000007','50000000-0000-4000-8000-000000000004','10000000-0000-4000-8000-000000000001','30000000-0000-4000-8000-000000000001','Poulet braisé',1,12000),
('60000000-0000-4000-8000-000000000008','50000000-0000-4000-8000-000000000004','10000000-0000-4000-8000-000000000001','30000000-0000-4000-8000-000000000003','Jus naturel',1,3000)
ON CONFLICT (id) DO NOTHING;

-- 9. Livraison uniquement pour la commande en mode delivery.
INSERT INTO public.deliveries
(id, order_id, delivery_address, contact_phone, status)
VALUES
('70000000-0000-4000-8000-000000000001','50000000-0000-4000-8000-000000000002',
 'Adresse fictive de test, Kinshasa','+243810000002','assigned')
ON CONFLICT (order_id) DO NOTHING;

-- 10. Paiements : trois réussis et un en attente (commande pending).
INSERT INTO public.payments
(id, order_id, provider, method, amount, currency_code,
 provider_transaction_id, status, idempotency_key, paid_at)
VALUES
('80000000-0000-4000-8000-000000000001','50000000-0000-4000-8000-000000000001','test','cash',15000,'CDF','TEST-PAY-001','succeeded','seed-payment-001',now()-interval '2 hours'),
('80000000-0000-4000-8000-000000000002','50000000-0000-4000-8000-000000000002','test','mobile_money',16000,'CDF','TEST-PAY-002','succeeded','seed-payment-002',now()-interval '1 hour'),
('80000000-0000-4000-8000-000000000003','50000000-0000-4000-8000-000000000003','test','bank_card',17500,'CDF','TEST-PAY-003','pending','seed-payment-003',NULL),
('80000000-0000-4000-8000-000000000004','50000000-0000-4000-8000-000000000004','test','mobile_money',15000,'CDF','TEST-PAY-004','succeeded','seed-payment-004',now()-interval '1 day')
ON CONFLICT (id) DO NOTHING;

-- 11. Transitions enregistrées uniquement par le déclencheur PostgreSQL.
-- UPDATE ne produit un événement que lors du premier passage d'un état à l'autre.
UPDATE public.orders SET status='confirmed'
WHERE id='50000000-0000-4000-8000-000000000001' AND status='pending';
UPDATE public.orders SET status='confirmed'
WHERE id='50000000-0000-4000-8000-000000000002' AND status='pending';
UPDATE public.orders SET status='preparing'
WHERE id='50000000-0000-4000-8000-000000000002' AND status='confirmed';
UPDATE public.orders SET status='confirmed'
WHERE id='50000000-0000-4000-8000-000000000004' AND status='pending';
UPDATE public.orders SET status='preparing'
WHERE id='50000000-0000-4000-8000-000000000004' AND status='confirmed';
UPDATE public.orders SET status='ready'
WHERE id='50000000-0000-4000-8000-000000000004' AND status='preparing';
UPDATE public.orders SET status='completed'
WHERE id='50000000-0000-4000-8000-000000000004' AND status='ready';

-- 12. Comptes de fidélité : UUID distinct par couple (restaurant, client).
INSERT INTO public.loyalty_accounts(id,restaurant_id,user_id,balance_points)
SELECT v.id::uuid,v.restaurant_id::uuid,u.id,v.balance
FROM (VALUES
 ('91000000-0000-4000-8000-000000000001','10000000-0000-4000-8000-000000000001','client1@monmiam.test',10),
 ('91000000-0000-4000-8000-000000000002','10000000-0000-4000-8000-000000000001','client2@monmiam.test',15),
 ('91000000-0000-4000-8000-000000000003','10000000-0000-4000-8000-000000000002','client1@monmiam.test',0),
 ('91000000-0000-4000-8000-000000000004','10000000-0000-4000-8000-000000000003','client3@monmiam.test',0)
) v(id,restaurant_id,email,balance)
JOIN auth.users u ON lower(u.email)=v.email
ON CONFLICT (restaurant_id,user_id) DO NOTHING;

-- 13. Codes de parrainage et relation : client2 parraine client1 sur ZeDuc@Space.
INSERT INTO public.referral_codes(id,restaurant_id,user_id,code)
SELECT '92000000-0000-4000-8000-000000000001',
 '10000000-0000-4000-8000-000000000001',u.id,'MIAMTEST15'
FROM auth.users u WHERE lower(u.email)='client2@monmiam.test'
ON CONFLICT (restaurant_id,user_id) DO NOTHING;

INSERT INTO public.referrals(id,restaurant_id,referrer_id,referred_id,code_used,
 status,qualifying_order_id,rewarded_points,rewarded_at)
SELECT '93000000-0000-4000-8000-000000000001',
 '10000000-0000-4000-8000-000000000001',p.id,f.id,'MIAMTEST15',
 'rewarded','50000000-0000-4000-8000-000000000004',15,now()
FROM auth.users p CROSS JOIN auth.users f
WHERE lower(p.email)='client2@monmiam.test' AND lower(f.email)='client1@monmiam.test'
ON CONFLICT (restaurant_id,referred_id) DO NOTHING;

-- 14. Journal : points commandés = FLOOR(15000 / 1500) = 10 ; parrainage = 15.
-- Les soldes des comptes de test ci-dessus sont des snapshots de démonstration.
-- Ces insertions ne remplacent pas les transactions métier de l'API.
INSERT INTO public.loyalty_transactions(id,loyalty_account_id,restaurant_id,order_id,
 referral_id,transaction_type,points_delta,idempotency_key)
VALUES
('94000000-0000-4000-8000-000000000001','91000000-0000-4000-8000-000000000001',
 '10000000-0000-4000-8000-000000000001','50000000-0000-4000-8000-000000000004',
 NULL,'earn',10,'seed-earn-order-4'),
('94000000-0000-4000-8000-000000000002','91000000-0000-4000-8000-000000000002',
 '10000000-0000-4000-8000-000000000001',NULL,
 '93000000-0000-4000-8000-000000000001','referral_bonus',15,'seed-referral-1')
ON CONFLICT (idempotency_key) DO NOTHING;

-- 15. Réclamations : client1 et client2 pour leurs commandes respectives.
INSERT INTO public.complaints(id,order_id,created_by,title,description,status)
SELECT v.id::uuid,v.order_id::uuid,u.id,v.title,v.description,v.status
FROM (VALUES
 ('95000000-0000-4000-8000-000000000001','50000000-0000-4000-8000-000000000004',
 'client1@monmiam.test','Retard fictif','Cas de test avec réponse approuvée','resolved'),
 ('95000000-0000-4000-8000-000000000002','50000000-0000-4000-8000-000000000002',
 'client2@monmiam.test','Produit manquant fictif','Réponse en attente d’approbation','in_review')
) v(id,order_id,email,title,description,status)
JOIN auth.users u ON lower(u.email)=v.email
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.complaint_responses(id,complaint_id,written_by,response_text,
 review_status,reviewed_by,reviewed_at)
SELECT '96000000-0000-4000-8000-000000000001',
 '95000000-0000-4000-8000-000000000001',e.id,'Réclamation traitée (test)',
 'approved',g.id,now()
FROM auth.users e CROSS JOIN auth.users g
WHERE lower(e.email)='employe@monmiam.test' AND lower(g.email)='gerant@monmiam.test'
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.complaint_responses(id,complaint_id,written_by,response_text,review_status)
SELECT '96000000-0000-4000-8000-000000000002',
 '95000000-0000-4000-8000-000000000002',u.id,
 'Réponse provisoire non visible du client (test)','proposed'
FROM auth.users u WHERE lower(u.email)='employe@monmiam.test'
ON CONFLICT (id) DO NOTHING;

-- 16. Campagnes et participation sans récompense de fidélité.
INSERT INTO public.campaigns(id,restaurant_id,campaign_type,title,description,is_active)
VALUES
('97000000-0000-4000-8000-000000000001','10000000-0000-4000-8000-000000000001','promotion','Offre découverte','Affiche fictive',true),
('97000000-0000-4000-8000-000000000002','10000000-0000-4000-8000-000000000002','event','Soirée de test','Événement fictif',true),
('97000000-0000-4000-8000-000000000003','10000000-0000-4000-8000-000000000003','mini_game','Jeu fictif','Animation test',true)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.campaign_participations(id,campaign_id,user_id,points_awarded)
SELECT '98000000-0000-4000-8000-000000000001',
 '97000000-0000-4000-8000-000000000003',u.id,0
FROM auth.users u WHERE lower(u.email)='client3@monmiam.test'
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.cookie_consents(id,user_id,session_id,analytics_allowed,
 marketing_allowed,policy_version)
SELECT '99000000-0000-4000-8000-000000000001',u.id,NULL,true,false,'test-v1'
FROM auth.users u WHERE lower(u.email)='client1@monmiam.test'
ON CONFLICT (id) DO NOTHING;


COMMIT;

-- Contrôle rapide après exécution :
-- SELECT name, slug FROM public.restaurants ORDER BY name;
-- SELECT r.name, count(p.id) AS nombre_produits
-- FROM public.restaurants r LEFT JOIN public.products p ON p.restaurant_id=r.id
-- GROUP BY r.name ORDER BY r.name;
-- SELECT r.name, count(o.id) AS nombre_commandes
-- FROM public.restaurants r LEFT JOIN public.orders o ON o.restaurant_id=r.id
-- GROUP BY r.name ORDER BY r.name;
-- Ne pas insérer manuellement dans order_status_events.
