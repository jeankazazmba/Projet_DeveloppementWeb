-- MON MIAM MIAM | Migration initiale 04/04 : RLS en lecture
-- AUCUNE politique d'ecriture cliente : operations via backend Laravel securise.
-- ATTENTION : politique de lecture du personnel a definir avant production.

begin;

alter table public.restaurants enable row level security;
alter table public.profiles enable row level security;
alter table public.staff_assignments enable row level security;
alter table public.restaurant_settings enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.daily_menu_items enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.order_status_events enable row level security;
alter table public.deliveries enable row level security;
alter table public.payments enable row level security;
alter table public.referral_codes enable row level security;
alter table public.referrals enable row level security;
alter table public.loyalty_accounts enable row level security;
alter table public.loyalty_transactions enable row level security;
alter table public.complaints enable row level security;
alter table public.complaint_responses enable row level security;
alter table public.campaigns enable row level security;
alter table public.campaign_participations enable row level security;
alter table public.cookie_consents enable row level security;

-- Lecture du catalogue public
create policy restaurants_public_read on public.restaurants
    for select to anon, authenticated
    using (status = 'active');

create policy settings_public_read on public.restaurant_settings
    for select to anon, authenticated
    using (exists (
        select 1 from public.restaurants r
        where r.id = restaurant_id and r.status = 'active'
    ));

create policy categories_public_read on public.categories
    for select to anon, authenticated
    using (exists (
        select 1 from public.restaurants r
        where r.id = restaurant_id and r.status = 'active'
    ));

create policy products_public_read on public.products
    for select to anon, authenticated
    using (is_active and exists (
        select 1 from public.restaurants r
        where r.id = restaurant_id and r.status = 'active'
    ));

create policy menu_public_read on public.daily_menu_items
    for select to anon, authenticated
    using (exists (
        select 1 from public.products p
        join public.restaurants r on r.id = p.restaurant_id
        where p.id = product_id
          and p.restaurant_id = public.daily_menu_items.restaurant_id
          and p.is_active
          and r.status = 'active'
    ));

create policy campaigns_public_read on public.campaigns
    for select to anon, authenticated
    using (is_active and exists (
        select 1 from public.restaurants r
        where r.id = restaurant_id and r.status = 'active'
    ));

-- Lectures privees limitees aux proprietaires
create policy profiles_own_read on public.profiles
    for select to authenticated
    using (id = (select auth.uid()));

create policy staff_own_read on public.staff_assignments
    for select to authenticated
    using (user_id = (select auth.uid()));

create policy orders_own_read on public.orders
    for select to authenticated
    using (customer_id = (select auth.uid()));

create policy order_items_own_read on public.order_items
    for select to authenticated
    using (exists (
        select 1 from public.orders o
        where o.id = order_id and o.customer_id = (select auth.uid())
    ));

create policy order_status_own_read on public.order_status_events
    for select to authenticated
    using (exists (
        select 1 from public.orders o
        where o.id = order_id and o.customer_id = (select auth.uid())
    ));

create policy deliveries_own_read on public.deliveries
    for select to authenticated
    using (exists (
        select 1 from public.orders o
        where o.id = order_id and o.customer_id = (select auth.uid())
    ));

create policy payments_own_read on public.payments
    for select to authenticated
    using (exists (
        select 1 from public.orders o
        where o.id = order_id and o.customer_id = (select auth.uid())
    ));

create policy referral_codes_own_read on public.referral_codes
    for select to authenticated
    using (user_id = (select auth.uid()));

create policy referrals_involved_read on public.referrals
    for select to authenticated
    using (referrer_id = (select auth.uid()) or referred_id = (select auth.uid()));

create policy loyalty_accounts_own_read on public.loyalty_accounts
    for select to authenticated
    using (user_id = (select auth.uid()));

create policy loyalty_transactions_own_read on public.loyalty_transactions
    for select to authenticated
    using (exists (
        select 1 from public.loyalty_accounts a
        where a.id = loyalty_account_id and a.user_id = (select auth.uid())
    ));

create policy complaints_own_read on public.complaints
    for select to authenticated
    using (created_by = (select auth.uid()));

-- SEULES les reponses approuvees sont visibles par le client.
-- Les reponses en attente/rejetees restent accessibles au personnel uniquement
-- via les futurs endpoints backend avec controle d'autorisation.
create policy complaint_responses_approved_own_read on public.complaint_responses
    for select to authenticated
    using (review_status = 'approved' and exists (
        select 1 from public.complaints c
        where c.id = complaint_id and c.created_by = (select auth.uid())
    ));

create policy participations_own_read on public.campaign_participations
    for select to authenticated
    using (user_id = (select auth.uid()));

create policy consents_own_read on public.cookie_consents
    for select to authenticated
    using (user_id = (select auth.uid()));

commit;
