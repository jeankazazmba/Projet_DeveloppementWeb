-- MON MIAM MIAM | Migration initiale 03/04 : index, audit et integrite
-- Sur une base VIERGE uniquement, apres 01 et 02.
-- Les transactions de fidelite/parrainage restent dans le backend securise.

begin;

-- Integrite du journal de fidelite : attribution au bon beneficiaire
create function public.validate_loyalty_transaction_owner()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
    v_owner uuid;
    v_expected_owner uuid;
begin
    select a.user_id into v_owner
    from public.loyalty_accounts a
    where a.id = new.loyalty_account_id
      and a.restaurant_id = new.restaurant_id;

    if new.transaction_type in ('earn', 'redeem') then
        select o.customer_id into v_expected_owner
        from public.orders o
        where o.id = new.order_id
          and o.restaurant_id = new.restaurant_id;

        if v_owner is null or v_expected_owner is null or v_owner <> v_expected_owner then
            raise exception 'Points de commande : compte/client differents';
        end if;
    elsif new.transaction_type = 'referral_bonus' then
        select r.referrer_id into v_expected_owner
        from public.referrals r
        where r.id = new.referral_id
          and r.restaurant_id = new.restaurant_id;

        if v_owner is null or v_expected_owner is null or v_owner <> v_expected_owner then
            raise exception 'Bonus de parrainage : compte du parrain requis';
        end if;
    end if;
    return new;
end;
$$;

create trigger trg_loyalty_owner
    before insert or update of loyalty_account_id, restaurant_id,
        order_id, referral_id, transaction_type
    on public.loyalty_transactions
    for each row execute function public.validate_loyalty_transaction_owner();

create unique index uq_loyalty_order_earn
    on public.loyalty_transactions(loyalty_account_id, order_id)
    where transaction_type = 'earn';

create unique index uq_loyalty_order_redeem
    on public.loyalty_transactions(loyalty_account_id, order_id)
    where transaction_type = 'redeem';

create unique index uq_referral_bonus_once
    on public.loyalty_transactions(referral_id)
    where transaction_type = 'referral_bonus';

-- Un seul paiement ayant abouti par commande (y compris apres remboursement).
-- Les tentatives non abouties peuvent etre conservees pour audit.
create unique index uq_payments_one_completed_per_order
    on public.payments(order_id)
    where status in ('succeeded', 'refunded');

-- Le paiement effectivement reussi doit couvrir le montant INTEGRAL.
-- Limite : les commandes a total 0 CDF necessitent une regle specifique.
create function public.validate_full_payment()
returns trigger
language plpgsql
set search_path = ''
as $$
declare
    v_amount numeric(12,2);
    v_currency char(3);
begin
    if new.status in ('succeeded', 'refunded') then
        select o.total_amount, o.currency_code
        into v_amount, v_currency
        from public.orders o
        where o.id = new.order_id;

        if v_amount is null then
            raise exception 'Commande inexistante pour paiement';
        end if;
        if new.amount <> v_amount or new.currency_code <> v_currency then
            raise exception 'Paiement non integral ou devise differente pour commande %', new.order_id;
        end if;
    end if;
    return new;
end;
$$;

create trigger trg_validate_full_payment
    before insert or update of order_id, amount, currency_code, status
    on public.payments
    for each row execute function public.validate_full_payment();

-- Les prix/remises ne doivent pas changer apres paiement reussi ou rembourse.
create function public.prevent_paid_order_amount_change()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
    if (new.subtotal, new.delivery_fee, new.loyalty_discount, new.currency_code)
       is distinct from
       (old.subtotal, old.delivery_fee, old.loyalty_discount, old.currency_code)
       and exists (
           select 1 from public.payments p
           where p.order_id = old.id and p.status in ('succeeded', 'refunded')
       ) then
        raise exception 'Montant/devise verrouilles apres paiement de la commande %', old.id;
    end if;
    return new;
end;
$$;

create trigger trg_prevent_paid_order_amount_change
    before update of subtotal, delivery_fee, loyalty_discount, currency_code
    on public.orders
    for each row execute function public.prevent_paid_order_amount_change();

-- Suppression LOGIQUE obligatoire : une action DELETE directe est refusee.
-- L'API devra utiliser UPDATE products SET is_active = false.
create function public.prevent_product_physical_delete()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
    raise exception 'Suppression physique de produit interdite : utiliser is_active = false';
end;
$$;

create trigger trg_prevent_product_physical_delete
    before delete on public.products
    for each row execute function public.prevent_product_physical_delete();

-- Journalise les changements de statut dans la meme transaction que la commande.
-- changed_by = auth.uid() si un contexte Supabase JWT est present ; sinon NULL.
-- Ne pas inserer en plus manuellement le meme evenement dans le backend.
create function public.log_order_status_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
    if tg_op = 'INSERT' then
        insert into public.order_status_events(order_id, previous_status, new_status, changed_by)
        values (new.id, null, new.status, auth.uid());
    elsif new.status is distinct from old.status then
        insert into public.order_status_events(order_id, previous_status, new_status, changed_by)
        values (new.id, old.status, new.status, auth.uid());
    end if;
    return new;
end;
$$;

create trigger trg_log_order_status_change
    after insert or update of status on public.orders
    for each row execute function public.log_order_status_change();

-- Index de navigation / consultation (complements des index PK/UNIQUE implicites)
create index idx_staff_user on public.staff_assignments(user_id);
create index idx_products_restaurant on public.products(restaurant_id);
create index idx_categories_restaurant on public.categories(restaurant_id);
create index idx_menu_restaurant_date on public.daily_menu_items(restaurant_id, menu_date);
create index idx_orders_restaurant_date on public.orders(restaurant_id, ordered_at desc);
create index idx_orders_customer_date on public.orders(customer_id, ordered_at desc);
create index idx_order_items_order on public.order_items(order_id);
create index idx_order_status_order on public.order_status_events(order_id, changed_at);
create index idx_referrals_referrer on public.referrals(restaurant_id, referrer_id);
create index idx_referral_codes_user on public.referral_codes(user_id);
create index idx_loyalty_tx_account_date on public.loyalty_transactions(loyalty_account_id, created_at desc);
create index idx_payments_order on public.payments(order_id);
create index idx_complaints_order on public.complaints(order_id);
create index idx_responses_complaint on public.complaint_responses(complaint_id);
create index idx_campaigns_restaurant on public.campaigns(restaurant_id, starts_at);
create index idx_participations_user on public.campaign_participations(user_id);

commit;
