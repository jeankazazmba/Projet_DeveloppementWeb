-- MON MIAM MIAM | Migration initiale 02/04 : fidelite, parrainage, reclamations
-- CIBLE : projet Supabase VIERGE. Ne pas executer sur projet principal deja rempli.

begin;

-- 13. Codes de parrainage uniques dans chaque restaurant
create table public.referral_codes (
    id uuid primary key default gen_random_uuid(),
    restaurant_id uuid not null references public.restaurants(id),
    user_id uuid not null references public.profiles(id),
    code text not null check (code ~ '^[A-Z0-9]{4,40}$'),
    created_at timestamptz not null default now(),
    unique (restaurant_id, user_id),
    unique (restaurant_id, code),
    unique (restaurant_id, user_id, code)
);

-- 14. Une seule relation parrain/filleul par restaurant
create table public.referrals (
    id uuid primary key default gen_random_uuid(),
    restaurant_id uuid not null references public.restaurants(id),
    referrer_id uuid not null references public.profiles(id),
    referred_id uuid not null references public.profiles(id),
    code_used text not null,
    status text not null default 'pending'
        check (status in ('pending', 'rewarded', 'cancelled')),
    qualifying_order_id uuid,
    rewarded_points integer not null default 0 check (rewarded_points >= 0),
    created_at timestamptz not null default now(),
    rewarded_at timestamptz,
    unique (restaurant_id, referred_id),
    unique (id, restaurant_id),
    unique (qualifying_order_id),
    check (referrer_id <> referred_id),
    check (
        (status = 'rewarded' and qualifying_order_id is not null
         and rewarded_points > 0 and rewarded_at is not null)
        or
        (status <> 'rewarded' and rewarded_points = 0 and rewarded_at is null)
    ),
    foreign key (restaurant_id, referrer_id, code_used)
        references public.referral_codes(restaurant_id, user_id, code),
    foreign key (qualifying_order_id, restaurant_id, referred_id)
        references public.orders(id, restaurant_id, customer_id)
);

-- 15. Solde propre au restaurant, jamais transferable
create table public.loyalty_accounts (
    id uuid primary key default gen_random_uuid(),
    restaurant_id uuid not null references public.restaurants(id),
    user_id uuid not null references public.profiles(id),
    balance_points integer not null default 0 check (balance_points >= 0),
    updated_at timestamptz not null default now(),
    unique (restaurant_id, user_id),
    unique (id, restaurant_id)
);

-- 16. Journal des mouvements, montants ENTIERS
create table public.loyalty_transactions (
    id uuid primary key default gen_random_uuid(),
    loyalty_account_id uuid not null,
    restaurant_id uuid not null,
    order_id uuid,
    referral_id uuid,
    transaction_type text not null
        check (transaction_type in ('earn', 'redeem', 'referral_bonus',
                                   'refund', 'expire', 'adjustment')),
    points_delta integer not null check (points_delta <> 0),
    idempotency_key text not null unique,
    expires_at timestamptz,
    created_at timestamptz not null default now(),
    foreign key (loyalty_account_id, restaurant_id)
        references public.loyalty_accounts(id, restaurant_id),
    foreign key (order_id, restaurant_id)
        references public.orders(id, restaurant_id),
    foreign key (referral_id, restaurant_id)
        references public.referrals(id, restaurant_id),
    check (
        (transaction_type in ('earn', 'referral_bonus') and points_delta > 0)
        or (transaction_type in ('redeem', 'expire') and points_delta < 0)
        or transaction_type in ('refund', 'adjustment')
    ),
    check (transaction_type <> 'referral_bonus' or referral_id is not null),
    check (transaction_type not in ('earn', 'redeem') or order_id is not null)
);

-- 17. Reclamations d'un client concernant sa propre commande
create table public.complaints (
    id uuid primary key default gen_random_uuid(),
    order_id uuid not null references public.orders(id),
    created_by uuid not null references public.profiles(id),
    title text not null,
    description text not null,
    status text not null default 'open'
        check (status in ('open', 'in_review', 'resolved', 'rejected')),
    created_at timestamptz not null default now(),
    closed_at timestamptz,
    foreign key (order_id, created_by)
        references public.orders(id, customer_id)
);

-- 18. Validation manager obligatoire avant lecture cote client (RLS migration 04)
create table public.complaint_responses (
    id uuid primary key default gen_random_uuid(),
    complaint_id uuid not null references public.complaints(id),
    written_by uuid references public.profiles(id),
    response_text text not null,
    review_status text not null default 'proposed'
        check (review_status in ('proposed', 'approved', 'rejected')),
    reviewed_by uuid references public.profiles(id),
    reviewed_at timestamptz,
    created_at timestamptz not null default now(),
    check (review_status = 'proposed' or
           (reviewed_by is not null and reviewed_at is not null))
);

-- 19. Campagnes (affiches promotionnelles/evenements/jeux)
create table public.campaigns (
    id uuid primary key default gen_random_uuid(),
    restaurant_id uuid not null references public.restaurants(id),
    campaign_type text not null check (campaign_type in ('promotion', 'event', 'mini_game')),
    title text not null,
    description text,
    poster_url text,
    starts_at timestamptz,
    ends_at timestamptz,
    is_active boolean not null default true,
    created_at timestamptz not null default now(),
    check (starts_at is null or ends_at is null or ends_at > starts_at)
);

-- 20. Participations aux campagnes
create table public.campaign_participations (
    id uuid primary key default gen_random_uuid(),
    campaign_id uuid not null references public.campaigns(id),
    user_id uuid not null references public.profiles(id),
    points_awarded integer not null default 0 check (points_awarded >= 0),
    participated_at timestamptz not null default now()
);

-- 21. Consentements cookies
create table public.cookie_consents (
    id uuid primary key default gen_random_uuid(),
    user_id uuid references public.profiles(id),
    session_id text,
    analytics_allowed boolean not null default false,
    marketing_allowed boolean not null default false,
    policy_version text not null,
    recorded_at timestamptz not null default now(),
    check (user_id is not null or session_id is not null)
);

commit;
