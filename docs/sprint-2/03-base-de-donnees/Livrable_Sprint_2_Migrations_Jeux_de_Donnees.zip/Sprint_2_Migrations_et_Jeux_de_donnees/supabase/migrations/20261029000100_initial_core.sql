-- MON MIAM MIAM | Migration initiale 01/04 : socle multi-restaurants
-- CIBLE : projet Supabase VIERGE (auth.users existe deja).
-- NE PAS EXECUTER sur le projet principal ou les 21 tables existent.
-- Base documentaire : schema SQL V2 du 26/10/2026 ; devise ajustee a CDF.
-- Les identifiants auth.users sont crees par Supabase Auth, pas par cette migration.

begin;
create extension if not exists pgcrypto;

-- 01. Restaurants
create table public.restaurants (
    id uuid primary key default gen_random_uuid(),
    slug text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
    name text not null,
    address text,
    phone text,
    email text,
    currency_code char(3) not null default 'CDF' check (currency_code = 'CDF'),
    status text not null default 'active'
        check (status in ('active', 'inactive')),
    created_at timestamptz not null default now()
);

-- 02. Profils / compte client unique entre les restaurants
create table public.profiles (
    id uuid primary key references auth.users(id) on delete cascade,
    full_name text not null default '',
    phone text,
    account_status text not null default 'active'
        check (account_status in ('active', 'inactive')),
    leaderboard_opt_in boolean not null default false,
    created_at timestamptz not null default now()
);

create function public.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
    insert into public.profiles (id, full_name, phone)
    values (
        new.id,
        coalesce(new.raw_user_meta_data ->> 'full_name', ''),
        new.raw_user_meta_data ->> 'phone'
    )
    on conflict (id) do nothing;
    return new;
end;
$$;

create trigger trg_create_profile
    after insert on auth.users
    for each row execute function public.handle_new_auth_user();

-- 03. Affectations du personnel, locales au restaurant
create table public.staff_assignments (
    id uuid primary key default gen_random_uuid(),
    restaurant_id uuid not null references public.restaurants(id),
    user_id uuid not null references public.profiles(id),
    staff_role text not null check (staff_role in ('employee', 'manager', 'admin')),
    is_active boolean not null default true,
    assigned_at timestamptz not null default now(),
    unique (restaurant_id, user_id)
);

-- 04. Parametres locaux de fidelite et d'ouverture
create table public.restaurant_settings (
    restaurant_id uuid primary key references public.restaurants(id),
    opening_hours jsonb not null default '{}'::jsonb,
    loyalty_earn_amount numeric(12,2) not null check (loyalty_earn_amount > 0),
    loyalty_earn_points integer not null check (loyalty_earn_points > 0),
    loyalty_redeem_points integer not null check (loyalty_redeem_points > 0),
    loyalty_redeem_value numeric(12,2) not null check (loyalty_redeem_value > 0),
    referral_reward_points integer check (referral_reward_points > 0),
    loyalty_expiration_months integer check (loyalty_expiration_months > 0),
    updated_at timestamptz not null default now()
);

-- 05. Categories
create table public.categories (
    id uuid primary key default gen_random_uuid(),
    restaurant_id uuid not null references public.restaurants(id),
    name text not null,
    display_order integer not null default 0,
    unique (restaurant_id, name),
    unique (id, restaurant_id)
);

-- 06. Produits ; suppression logique via is_active
create table public.products (
    id uuid primary key default gen_random_uuid(),
    restaurant_id uuid not null references public.restaurants(id),
    category_id uuid,
    name text not null,
    description text,
    price numeric(12,2) not null check (price >= 0),
    photo_url text,
    is_available boolean not null default true,
    is_active boolean not null default true,
    created_at timestamptz not null default now(),
    unique (id, restaurant_id),
    foreign key (category_id, restaurant_id)
        references public.categories(id, restaurant_id)
);

-- 07. Menu du jour
create table public.daily_menu_items (
    id uuid primary key default gen_random_uuid(),
    restaurant_id uuid not null references public.restaurants(id),
    product_id uuid not null,
    menu_date date not null,
    unique (restaurant_id, product_id, menu_date),
    foreign key (product_id, restaurant_id)
        references public.products(id, restaurant_id)
);

-- 08. Commandes ; une commande = un seul restaurant
create table public.orders (
    id uuid primary key default gen_random_uuid(),
    restaurant_id uuid not null references public.restaurants(id),
    customer_id uuid not null references public.profiles(id),
    status text not null default 'pending'
        check (status in ('pending', 'confirmed', 'preparing', 'ready',
                         'delivering', 'completed', 'cancelled')),
    service_mode text not null check (service_mode in ('on_site', 'delivery')),
    expected_arrival_at timestamptz,
    customer_note text,
    currency_code char(3) not null default 'CDF' check (currency_code = 'CDF'),
    subtotal numeric(12,2) not null default 0 check (subtotal >= 0),
    delivery_fee numeric(12,2) not null default 0 check (delivery_fee >= 0),
    loyalty_discount numeric(12,2) not null default 0 check (loyalty_discount >= 0),
    total_amount numeric(12,2) generated always as
        (subtotal + delivery_fee - loyalty_discount) stored,
    ordered_at timestamptz not null default now(),
    check (loyalty_discount <= subtotal),
    unique (id, restaurant_id),
    unique (id, restaurant_id, customer_id),
    unique (id, customer_id)
);

-- 09. Lignes de commandes, produits du meme restaurant
create table public.order_items (
    id uuid primary key default gen_random_uuid(),
    order_id uuid not null,
    restaurant_id uuid not null,
    product_id uuid not null,
    product_name_snapshot text not null,
    quantity integer not null check (quantity > 0),
    unit_price numeric(12,2) not null check (unit_price >= 0),
    line_total numeric(12,2) generated always as (quantity * unit_price) stored,
    unique (order_id, product_id),
    foreign key (order_id, restaurant_id)
        references public.orders(id, restaurant_id),
    foreign key (product_id, restaurant_id)
        references public.products(id, restaurant_id)
);

-- 10. Historique des changements de statut
create table public.order_status_events (
    id uuid primary key default gen_random_uuid(),
    order_id uuid not null references public.orders(id),
    previous_status text,
    new_status text not null,
    changed_by uuid references public.profiles(id),
    changed_at timestamptz not null default now()
);

-- 11. Livraisons : au maximum une par commande
create table public.deliveries (
    id uuid primary key default gen_random_uuid(),
    order_id uuid not null unique references public.orders(id),
    delivery_address text not null,
    contact_phone text,
    status text not null default 'pending'
        check (status in ('pending', 'assigned', 'in_transit', 'delivered', 'failed')),
    delivered_at timestamptz,
    created_at timestamptz not null default now()
);

-- 12. Paiements et tentatives : une seule operation REUSSIE par commande
create table public.payments (
    id uuid primary key default gen_random_uuid(),
    order_id uuid not null references public.orders(id),
    provider text,
    method text not null check (method in ('cash', 'mobile_money', 'bank_card')),
    amount numeric(12,2) not null check (amount > 0),
    currency_code char(3) not null default 'CDF' check (currency_code = 'CDF'),
    provider_transaction_id text,
    status text not null default 'pending'
        check (status in ('pending', 'succeeded', 'failed', 'cancelled', 'refunded')),
    idempotency_key text not null unique,
    paid_at timestamptz,
    created_at timestamptz not null default now(),
    unique (provider, provider_transaction_id)
);

commit;
