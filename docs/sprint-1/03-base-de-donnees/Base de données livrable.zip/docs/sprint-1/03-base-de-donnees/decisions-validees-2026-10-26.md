# Décisions métier validées — issue #25 (26 octobre 2026)

**Statut :** décisions métier confirmées lors de l'échange. **Il ne s'agit pas d'une mise à jour SQL exécutée**, ni d'une approbation de l'équipe API.

| Réf. | Sujet | Décision confirmée | Effets attendus |
|---|---|---|---|
| D-01 | Devise | **CDF — franc congolais** | Devises des restaurants, commandes, paiements et pilote ; le schéma SQL V2 et le seed V3 mentionnent encore XAF : corriger à l'implémentation. |
| D-02 | Calcul des points | **1 500 CDF éligibles = 1 point** au taux 1 000 CDF/point ; points entiers | `floor(base_eligible / tranche) * points_par_tranche` ; pas de points fractionnaires ni de report du reliquat. |
| D-03 | Annulation d'une commande | **Restitution intégrale des points utilisés** | Écriture `refund` positive, idempotente, reliée au débit initial, effectuée atomiquement avec le solde. |
| D-04 | Règlement | **Un seul paiement intégral par commande** | Plusieurs tentatives peuvent échouer ; au plus un paiement confirmé réussi pour tout le total, contrôle du montant, de la devise et de la preuve de succès. |
| D-05 | Réponses aux réclamations | **Approbation obligatoire du gérant avant visibilité au client** | `proposed` → `approved` par acteur autorisé ; masquer `proposed`/`rejected` au client côté serveur ET corriger RLS. |
| D-06 | Remboursement d'une commande ayant généré des points | **Retirer automatiquement les points gagnés grâce à la commande remboursée** | Mouvement compensatoire négatif, une seule fois, lié à l'écriture `earn` initiale ; mise à jour transactionnelle du solde. Le traitement si des points ont déjà été dépensés reste à arbitrer. |

## Écarts entre conception cible et SQL de référence

1. **Défauts monétaires :** `restaurants.currency_code`, `orders.currency_code` et `payments.currency_code` portent `DEFAULT 'XAF'` dans la source V2 ; le seed du restaurant pilote contient aussi `XAF`. La **cible validée est `CDF`**. Changer les valeurs par défaut et les seeds, puis vérifier les données existantes individuellement ; **ne jamais requalifier automatiquement une transaction historique XAF en CDF**.
2. **Paiement unique :** la source V2 ne garantit pas « au plus un succès par commande ». Étudier un index partiel unique `ON public.payments(order_id) WHERE status = 'succeeded'`, tout en définissant la gestion des remboursements et tentatives.
3. **Réclamations :** la politique `complaint_responses_own_read` de V2 ne limite pas l'accès du client au seul `review_status = 'approved'` ; **risque de divulgation**. Corriger côté RLS/serveur avant toute mise en production.
4. **Restitution de points :** une écriture compensatoire `refund` est possible en V2, mais aucun déclencheur transactionnel d'annulation n'en assure automatiquement la création. Définir une clé unique métier et les verrous nécessaires.
5. **Gain par tranches :** la formule et la règle entière sont décidées, mais le calcul n'est pas implémenté par le DDL seul.
6. **Retrait après remboursement :** un débit compensatoire doit annuler tout gain `earn` associé à une commande remboursée, avec clé d'idempotence et référence de l'écriture d'origine ; aucune transaction RPC automatique n'est livrée en V2. `balance_points >= 0` interdit de retirer au-delà du solde disponible : la politique d'insuffisance (dette de points à recouvrer, autre mécanisme) reste à décider.

## Questions restant ouvertes

- Moment initial du débit des points pour une remise et gestion des commandes concurrentes (Q-05).
- Conditions et délais d'annulation et modalités du remboursement monétaire ; **le retrait automatique des points gagnés est décidé**, mais la gestion des points déjà dépensés (solde insuffisant) reste à arbitrer (Q-04/Q-19).
- Matrice des transitions et preuve opérationnelle de service/livraison (Q-07) ; méthode d'historisation forcée (Q-10).
- Autres autorisations du personnel, conservation des données, expiration des points, jeux, classement et extensions : voir `questions-ouvertes.md`.

**Livraison :** synchroniser la documentation MCD/MLD/dictionnaire, relire en équipe API, puis enregistrer le lien au compte-rendu et la validation dans l'issue #25 / Jira PMEE. Les migrations, RLS et RPC restent hors du ticket de conception.
