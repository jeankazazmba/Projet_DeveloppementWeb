# Historisation des commandes — spécification de conception

**Issue #25 · Tâche 5** · 26 octobre 2026. Document **prêt pour revue**, non exécuté en base.

## 1. Objectif et état de la V2

**Exigence :** chaque création et chaque changement réel de l'état d'une commande doit laisser une trace fiable, horodatée et attribuable, sans suppression silencieuse des événements.

Le schéma existant expose :

- `orders(id, restaurant_id, customer_id, status, service_mode, ..., ordered_at)` ; `status` appartient à `pending`, `confirmed`, `preparing`, `ready`, `delivering`, `completed`, `cancelled`.
- `order_status_events(id, order_id, previous_status, new_status, changed_by, changed_at)` ; FK sur `orders` et `profiles` pour l'acteur.
- Index `idx_order_status_order(order_id, changed_at)`.

**Constat documenté :** dans `mon_miam_miam_schema_v2.sql`, aucun trigger n'assure automatiquement la création de `order_status_events` lors des mises à jour de `orders.status`. Les valeurs de `previous_status` et `new_status` ne sont pas contraintes par les états autorisés dans la table d'événements ; l'API doit aussi vérifier leur cohérence.

## 2. Définition des événements

| Attribut | Signification | Règle |
|---|---|---|
| `id` | Identifiant de l'événement | UUID unique. |
| `order_id` | Commande concernée | FK non nulle. |
| `previous_status` | État avant action | `NULL` uniquement sur l'événement initial recommandé. |
| `new_status` | État après action | Valeur autorisée, égale au statut final de commande. |
| `changed_by` | Compte ayant réalisé ou approuvé le changement | FK nullable ; `NULL` doit être réservé à un événement système tracé par d'autres moyens (acteur technique absent de V2). |
| `changed_at` | Instant du changement | Date fiable issue du serveur / SGBD. |

**Invariant H-1 :** si le statut change de A vers B, alors une seule transition valide A→B est enregistrée **dans la même transaction** que l'update de `orders.status`. Une tentative rejetée n'ajoute pas d'événement.

**Invariant H-2 :** une transition sans changement (`status = status`) ne produit pas de nouvel événement, sauf si un audit spécifique est conçu ultérieurement.

**Invariant H-3 :** un événement d'audit ne doit pas être modifié ou supprimé par le client et ne doit pas contenir de notes personnelles inutiles ; les procédures légales de purge se traitent séparément.

## 3. Machine à états proposée (non validée métier)

Cette table est une **PROPOSITION d'organisation V1**. Elle ne doit pas être traitée comme un comportement déjà implémenté.

| État courant | Transition(s) proposées | Condition métier et auteur |
|---|---|---|
| `pending` | `confirmed`, `cancelled` | Personnel habilité confirme ou client annule selon politique. |
| `confirmed` | `preparing`, `cancelled` | Préparation démarrée ou annulation autorisée. |
| `preparing` | `ready`, éventuellement `cancelled` | Annulation tardive à arbitrer. |
| `ready` | `completed` (sur place), `delivering` (livraison) | Ne passer à `completed` que lorsque effectivement servi. |
| `delivering` | `completed` | Pour `delivery`, preuve de livraison + `deliveries.status='delivered'`. |
| `completed` | aucune | État final de service ; remboursement financier géré séparément. |
| `cancelled` | aucune | Terminal, historique conservé. |

**Important :** `confirmed` dans `orders` reflète le traitement de la commande, et **ne doit pas être confondu** avec `payments.status='succeeded'`. La notion `completed` concerne la prestation rendue ; le crédit des points exige *en plus* un paiement confirmé.

**Annulation et remboursements :** **décision validée** : les points de réduction déjà débités sur une commande annulée sont **restitués intégralement** via une écriture compensatoire unique (`loyalty_transactions`, type `refund`), sans effacement de l'historique. Les seuils d'annulation, frais, remboursements monétaires et éventuelles reprises de points gagnés restent à déterminer (Q-04).

## 4. Flux transactionnel obligatoire — conception

```text
Requête API authentifiée : changer_statut(order_id, nouvel_etat, acteur, cle_requete)
   ↓
Autoriser acteur pour le restaurant et vérifier commande existante
   ↓
BEGIN ; verrouiller la ligne orders (SELECT ... FOR UPDATE)
   ↓
Lire ancien statut ; valider transition, mode de service et préconditions
   ├─ invalide -> ROLLBACK, réponse explicite
   ├─ déjà au nouvel état -> retour idempotent (pas de second événement)
   ↓
UPDATE orders SET status = nouvel_etat WHERE id = ...
INSERT order_status_events(order_id, previous_status, new_status, changed_by)
   ↓
COMMIT ; publier notification seulement après COMMIT
```

**Création :** la transaction qui crée `orders` et `order_items` insère aussi un événement initial (`previous_status=NULL`, `new_status='pending'`). Elle doit garantir qu'au moins une ligne existe et que le total correspond aux lignes. Si cette transaction échoue, aucune commande partielle ne subsiste.

**Concurrence :** deux employés qui tentent de changer le statut simultanément doivent sérialiser l'accès à la commande. Le second lit l'état effectivement finalisé avant de valider sa transition. Le verrou `FOR UPDATE` ou une version optimiste est à prévoir ; ne jamais générer les événements à partir d'un état client périmé.

**Option d'implémentation conseillée :** log d'état garanti par un trigger PostgreSQL `AFTER INSERT OR UPDATE OF status` *ou* par une RPC transactionnelle unique qui interdit toute mise à jour directe. La solution retenue doit garantir la couverture des autres chemins administratifs. **Aucun de ces mécanismes supplémentaires n'est présent dans V2** : ne pas déclarer la propriété de complétude satisfaite en production.

## 5. Livraison, paiement et fidélité

- `on_site` : `completed` correspond à une commande réellement **servie** ; `expected_arrival_at` seul ne le prouve pas.
- `delivery` : `completed` doit exiger une livraison attestée (`deliveries.status='delivered'`, `delivered_at`), selon le mécanisme validé.
- Le seul état `completed` **ne prouve pas** le paiement : vérifier côté serveur **un paiement réussi unique**, égal au total dû et dans la devise `CDF`. Plusieurs tentatives peuvent exister mais pas de règlement fractionné (décision validée).
- Quand `completed` + paiement confirmé sont tous deux vérifiés, déclencher l'opération idempotente de gain fidélité prévue dans `journal-points.md` ; paiement après la livraison et livraison après paiement doivent conduire au même résultat **exactement une fois**.

## 6. Exemples d'enregistrements illustratifs (données fictives)

| order_id | previous_status | new_status | changed_by | changed_at |
|---|---|---|---|---|
| A (UUID fictif) | `NULL` | `pending` | client X | T0 |
| A | `pending` | `confirmed` | employé Y | T1 |
| A | `confirmed` | `preparing` | employé Y | T2 |
| A | `preparing` | `ready` | employé Y | T3 |
| A | `ready` | `completed` | employé Y | T4 |

Le champ `changed_by` de la V2 stocke un UUID et non un nom ; ce tableau montre les rôles uniquement pour expliquer le scénario.

## 7. Tests d'acceptation à remettre à l'équipe API

| Test | Action | Attendu |
|---|---|---|
| H-01 | Créer une commande avec 2 lignes | Événement initial `NULL → pending` unique. |
| H-02 | Changer `pending → confirmed` | Un événement, `orders.status=confirmed`. |
| H-03 | Demander `pending → delivering` | Refus de la transition si matrice proposée retenue. |
| H-04 | Émettre 2 fois `confirmed → preparing` | Au plus un changement et un événement. |
| H-05 | 2 transitions simultanées incompatibles | Une seule progression cohérente, aucun historique fictif. |
| H-06 | Échec d'insertion de l'événement | Rollback de la modification de commande. |
| H-07 | Livraison non terminée ; tenter `completed` | Refus pour `delivery`. |
| H-08 | Commande `completed` sans paiement | Aucun point de commande. |
| H-09 | Client A lit l'historique de B | Refus RLS / API. |
| H-10 | Employé du restaurant B modifie A | Refus systématique. |
| H-11 | Tentative de suppression d'un événement | Refus pour rôles clients/personnel. |
| H-12 | Statut en dehors de la liste | Refus CHECK sur `orders.status`. |
| H-13 | Échec de création des lignes | Pas d'ordre orphelin finalisé. |

## 8. Conditions de sortie de la revue de conception

- [ ] Transitions autorisées et annulations validées métier.
- [ ] Signification de `completed` documentée par `service_mode`.
- [ ] Politique de trace initiale et auteur système décidée.
- [ ] Choix trigger vs RPC/écriture exclusive validé et affecté à l'implémentation.
- [ ] Équivalence entre commande servie/livrée, paiement vérifié et fidélité validée.
- [ ] Relecture de la matrice de tests par l'équipe API.

Ces cases signalent des **validations externes restant à effectuer**, pas des tâches documentaires non rédigées.
