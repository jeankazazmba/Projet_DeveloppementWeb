# Règles métier — Mon Miam Miam

**Issue GitHub :** #25 · **Livrable / tâche 4** · **Version documentaire :** 1.1 (26/10/2026, décisions métier intégrées)  
**Références :** cahier des charges V1.0.2 ; `mon_miam_miam_schema_v2.sql` (26/10/2026) ; `mon_miam_miam_pilote_v3.sql` ; MCD/MLD et dictionnaire livrés.  
**Statut :** conception documentée, **revue API/Figma non encore attestée**. Ce fichier n'est pas une migration, ni la preuve d'une transaction métier exécutée.

## 1. Conventions de lecture

| Mention | Signification |
|---|---|
| **VALIDÉ** | Règle métier retenue lors des travaux précédents et reprise dans le modèle. |
| **DDL V2** | Contrainte ou structure effectivement déclarée dans le *script source* V2 ; cela ne prouve pas son exécution en base. |
| **À IMPLÉMENTER** | Comportement nécessitant API sécurisée, transaction, triggers, ou tests ; le schéma V2 seul ne suffit pas. |
| **PROPOSITION** | Choix recommandé pour la V1, explicitement à arbitrer, non présenté comme décidé. |

**Portée :** plusieurs restaurants, avec isolation des commandes, des catalogues, des points et des parrainages. Les identités utilisateurs sont transversales à la plateforme, alors que les droits du personnel et les récompenses sont **locaux à un restaurant**.

## 2. Catalogue et gestion des identités

**RM-01 — Restaurants distincts [VALIDÉ / DDL V2].** `restaurants` définit l'établissement. Les produits, catégories et menus du jour portent un `restaurant_id`. Les relations composites `(id, restaurant_id)` empêchent d'ajouter à la commande du restaurant A le produit du restaurant B.

**RM-02 — Identité et rôles [DDL V2].** `auth.users` est la source d'identité ; `profiles.id` correspond à `auth.users.id`. Les mots de passe et jetons ne sont jamais stockés dans `profiles`. Un utilisateur peut être client et personnel dans des établissements différents. `staff_assignments` porte des rôles locaux `employee`, `manager`, `admin`. Aucun `super_admin` général n'existe dans V2. Une seule affectation par couple `(restaurant_id, user_id)` : elle peut être désactivée.

**RM-03 — Catalogue [DDL V2].** Une catégorie appartient à un seul restaurant ; un produit appartient à un seul restaurant et peut être relié à une catégorie du même restaurant. `is_available` signifie disponible/épuisé temporairement ; `is_active` signifie publié/non publié. Le menu du jour référence un produit et une date ; `(restaurant_id, product_id, menu_date)` est unique.

**RM-04 — Affiches, jeux et événements [DDL V2, règles de gain À IMPLÉMENTER].** `campaigns` représente une promotion, un événement ou un mini-jeu, généralement sous forme d'affiche. `campaign_participations` enregistre une participation. Le DDL ne garantit ni unicité de participation ni versement effectif des `points_awarded` dans le journal de fidélité : points à arbitrer avec l'API et le métier.

## 3. Commandes et paiements

**RM-05 — Panier et restaurant unique [VALIDÉ / DDL V2].** Le panier de la V1 est géré avant confirmation dans l'interface, sans table `carts` persistée. Une commande appartient à **un seul restaurant** et à **un client**. Toute ligne contient un produit de ce même restaurant (FK composites). Une commande doit comporter **au moins une ligne métier** : ce minimum n'est pas garanti par la seule FK du DDL.

**RM-06 — Prix figés et calcul des montants [DDL V2 + À IMPLÉMENTER].** À la commande, conserver le nom et le prix de chaque produit dans `order_items` : `product_name_snapshot` et `unit_price`. `line_total = quantity × unit_price` est calculé. `orders.subtotal` doit égaler la somme des `line_total` ; la V2 ne le recalcule pas automatiquement. `orders.total_amount = subtotal + delivery_fee - loyalty_discount` est une colonne générée. Interdire une remise supérieure au sous-total, frais négatifs et quantités non positives (contraintes V2).

**RM-07 — Mode de service [DDL V2 + À IMPLÉMENTER].** `service_mode` vaut `on_site` (sur place, arrivée éventuellement prévue) ou `delivery` (adresse de livraison requise). Une commande `delivery` aura au plus une ligne dans `deliveries` grâce à `UNIQUE(order_id)`. Le SQL V2 ne force pas l'adéquation `delivery`/`deliveries` : validation transactionnelle requise. Aucun stockage d'adresse n'est exigé pour un repas sur place.

**RM-08 — États de commande [DDL V2 + À IMPLÉMENTER].** `orders.status` appartient à `{pending, confirmed, preparing, ready, delivering, completed, cancelled}`. Les transitions précises et l'interprétation de `completed` doivent être validées ; une proposition est détaillée dans `historique-commandes.md`. Un changement de statut doit être audité par `order_status_events` dans la même transaction.

**RM-09 — Paiements [VALIDÉ métier ; DDL V2 incomplet ; À IMPLÉMENTER].** Chaque commande est réglée en **un unique paiement intégral** pour `orders.total_amount`, dans la même devise `CDF` (pas de paiement fractionné). Plusieurs *tentatives* de paiement peuvent être conservées dans `payments` (`cash`, `mobile_money`, `bank_card`) si certaines échouent, mais **une seule tentative peut être acceptée comme règlement effectif** par commande. Prévoir notamment un index unique partiel sur `payments(order_id) WHERE status='succeeded'` dans une future migration, avec vérification serveur du montant exact, de la devise, de la preuve de paiement et de la concurrence ; la V2 ne contient pas cette unicité. Les statuts possibles sont `pending`, `succeeded`, `failed`, `cancelled`, `refunded`. Ne pas considérer un retour du navigateur comme preuve. `idempotency_key` est déjà unique en V2. Les règles de remboursement monétaire restent à définir.

**RM-10 — Réclamations [VALIDÉ métier ; DDL V2 à renforcer ; À IMPLÉMENTER].** Une réclamation doit correspondre à une commande du client plaignant (`FK(order_id, created_by)`). Ses états sont `open`, `in_review`, `resolved`, `rejected`. L'employé peut rédiger une réponse `proposed`. **L'approbation préalable par le gérant du restaurant est obligatoire avant affichage au client** (`complaint_responses.review_status='approved'`). Toute réponse rejetée ou en cours ne doit pas être visible par le client. Le DDL V2 permet toutefois au client propriétaire de lire les réponses sans filtrage d'approbation : **la politique RLS / l'API doit être corrigée avant mise en service** ; ne pas se contenter du filtrage côté interface. Les autorisations d'un administrateur local pour suppléer le gérant restent à préciser.

## 4. Fidélité et parrainage

**RM-11 — Paramètres locaux [VALIDÉ / DDL V2].** Chaque restaurant configure indépendamment `loyalty_earn_amount`, `loyalty_earn_points`, `loyalty_redeem_points`, `loyalty_redeem_value`, `referral_reward_points` et, éventuellement, `loyalty_expiration_months` dans `restaurant_settings`. Aucun taux global. Un compte de fidélité unique existe pour chaque `(restaurant_id, user_id)`.

**RM-12 — Moment d'acquisition des points [VALIDÉ ; À IMPLÉMENTER].** Ne créditer une commande **que lorsque les deux conditions sont simultanément satisfaites** : (i) commande effectivement servie/livrée et (ii) paiement intégral confirmé selon la politique de règlement retenue. Un simple statut `confirmed`, un paiement initié, ou une livraison non payée ne suffit pas. L'écriture et le solde doivent être modifiés atomiquement et de manière idempotente.

**RM-13 — Base éligible [VALIDÉ].** Les points rémunèrent la **valeur effectivement payée des produits après remises** ; les frais de livraison sont exclus. Pour V2, si la seule remise calculée est `loyalty_discount` : `base_eligible = max(0, subtotal - loyalty_discount)`. Si d'autres remises sur produits sont ajoutées dans l'API, il faudra les retrancher aussi et adapter le schéma. La méthode par **tranches complètes et points entiers est VALIDÉE** : `floor(base_eligible / loyalty_earn_amount) × loyalty_earn_points` (voir `journal-points.md`).

**RM-14 — Barèmes du pilote ZeDuc@Space [VALIDÉ].** Devise des prix : **CDF (franc congolais)**. `1 000 CDF de produits éligibles = 1 point` ; ainsi **1 500 CDF donnent 1 point**, sans fraction ni report automatique du reliquat de 500 CDF ; `15 points = 1 000 CDF de remise` ; `15 points au parrain` après la première commande réussie, payée et servie/livrée de son filleul **dans ce restaurant**. **Écart de conformité** : les scripts sources V2/V3 portent encore des valeurs `XAF` ; prévoir l'alignement vers `CDF` dans le travail d'implémentation, sans réécrire arbitrairement les commandes historiques.

**RM-15 — Parrainage local et unique [VALIDÉ / DDL V2].** Un filleul a **au plus un parrain par restaurant** (`UNIQUE(restaurant_id, referred_id)`), sans auto-parrainage (`referrer_id <> referred_id`). Un code de parrainage est unique par restaurant, non nécessairement sur toute la plateforme. Le code utilisé doit appartenir au parrain **dans le restaurant concerné** (FK composite).

**RM-16 — Attribution de la récompense [VALIDÉ ; À IMPLÉMENTER].** Une seule prime par couple restaurant/filleul ; elle doit aller au compte du **parrain**, après la **première commande qualifiante** du filleul dans cet établissement, payée et réellement servie/livrée. `referrals.qualifying_order_id`, statut `rewarded`, et mouvement `loyalty_transactions.transaction_type='referral_bonus'` doivent être validés/écrits dans une même transaction. `uq_referral_bonus_once` prévient le double bonus par parrainage ; vérifier l'antériorité des commandes qualifiantes dans le backend.

**RM-17 — Solde et journal [DDL V2 + À IMPLÉMENTER].** Chaque variation de points est enregistrée dans `loyalty_transactions` (`earn`, `redeem`, `referral_bonus`, `refund`, `expire`, `adjustment`). `loyalty_accounts.balance_points` doit correspondre au cumul du journal et rester non négatif. Les écritures doivent être idempotentes et indissociables de la mise à jour du solde. La table V2 contient des index uniques partiels pour `earn`/`redeem` par commande et `referral_bonus` par parrainage ; voir `journal-points.md`.

**RM-18 — Annulation, restitution et remboursement [VALIDÉ métier ; À IMPLÉMENTER].** Si une commande ayant consommé des points de remise est **annulée**, les points utilisés doivent être **restitués intégralement** au client par compensation positive, **exactement une fois**. Si une commande ayant généré des points est **remboursée**, retirer **automatiquement et intégralement** les points `earn` attribués grâce à cette commande, par une **écriture compensatoire négative**, **exactement une fois**. Ne jamais supprimer les mouvements initiaux ; relier chaque compensation à sa source, et écrire journal et solde atomiquement. Ces effets métier sont validés mais ne sont pas automatisés par la V2. **Point ouvert :** que faire si le client a déjà dépensé les points et que le solde disponible est insuffisant ? V2 impose `balance_points >= 0` : un mécanisme de dette/recouvrement ou une évolution du modèle est à arbitrer. Le moment du débit des remises, les délais d'annulation, le remboursement monétaire et l'expiration restent à définir.

## 5. Confidentialité et restitution

**RM-19 — Minimisation [CONCEPTION].** Ne demander que les coordonnées indispensables ; les adresses de livraison ne concernent que les commandes en livraison. Aucun PAN/CVV de carte dans PostgreSQL. Les données de connexion relèvent de Supabase Auth.

**RM-20 — Cloisonnement [DDL V2 partiel / À IMPLÉMENTER].** Un client accède à ses données ; un employé n'accède qu'aux données nécessaires **du restaurant auquel il est affecté** ; le gérant valide les réponses aux réclamations ; l'administrateur local gère les personnes/paramètres du même restaurant. Les politiques RLS V2 sont principalement des politiques **de lecture** ; elles ne constituent pas une autorisation complète du personnel ou un backend de paiement.

**RM-21 — Classement et cookies [DDL V2 / À IMPLÉMENTER].** `profiles.leaderboard_opt_in` pilote l'exposition des personnes dans un classement public ; `cookie_consents` conserve la version de politique et les préférences déclarées. Les traitements, leur durée de conservation et leur applicabilité juridique sont à confirmer. Ne pas publier de classement nominatif sans option positive.

## 6. Cardinalités principales

| Association | Cardinalité métier | Justification / restriction |
|---|---|---|
| Restaurant → paramètres | 1 → 0..1 dans DDL, **1 attendu en exploitation** | PK/FK `restaurant_settings.restaurant_id` ; création conjointe à organiser. |
| Restaurant → commandes | 1 → 0..N | Commande dans un établissement unique. |
| Client → commandes | 1 → 0..N | Une commande a un seul client. |
| Commande → lignes | 1 → **1..N métier**, DDL autorise temporairement 0 | La transaction de création doit imposer au moins 1. |
| Produit → lignes | 1 → 0..N | Prix et nom figés dans la ligne. |
| Commande → livraisons | 1 → 0..1 | Uniquement si `service_mode=delivery`. |
| Commande → paiements | 1 → 0..N | Plusieurs tentatives possibles. |
| Commande → événements de statut | 1 → 1..N souhaité, DDL 0..N | Un événement initial à créer transactionnellement. |
| Restaurant + client → compte fidélité | 1 couple → 0..1, 1 si activé | UNIQUE `(restaurant_id,user_id)`. |
| Compte fidélité → mouvements | 1 → 0..N | Journal par compte et restaurant. |
| Restaurant + filleul → parrainage | 1 couple → 0..1 | UNIQUE `(restaurant_id,referred_id)`. |
| Parrainage → récompense parrain | 1 → 0..1 | Bonus contrôlé par index et transaction. |
| Commande → réclamations | 1 → 0..N | Plaignant doit être client de la commande. |

## 7. Critères d'acceptation inter-fonctions

| ID | Scénario obligatoire | Résultat attendu |
|---|---|---|
| AT-01 | Tenter d'ajouter à la commande A un produit du restaurant B | Rejet par cohérence composite. |
| AT-02 | Tenter de confirmer une commande vide | Rejet applicatif. |
| AT-03 | Rejouer 2 fois un paiement réussi | Un seul traitement financier par événement fournisseur. |
| AT-04 | Terminer une commande non payée | Aucun crédit de points. |
| AT-05 | Payer sans avoir servi/livré | Aucun crédit de points. |
| AT-06 | Payer et servir/livrer puis rejouer la confirmation | Crédit unique. |
| AT-07 | Parrainer deux fois le même filleul dans le même restaurant | Un seul parrainage admis. |
| AT-08 | Première commande réussie du filleul puis second achat | Une seule prime au parrain. |
| AT-09 | Client A consulte commande de B | Accès refusé. |
| AT-10 | Employé restaurant A consulte comptes du restaurant B | Accès refusé. |
| AT-11 | Annuler ou rembourser une commande avec points | Compensation conforme à la décision de l'équipe, sans solde négatif. |
| AT-12 | Modifier un statut de commande | Événement d'historique enregistré atomiquement. |

## 8. Correspondance des documents et limites

- `historique-commandes.md` détaille RM-08 et les garanties non implémentées du DDL V2.
- `journal-points.md` détaille RM-11 à RM-18, y compris les verrous, les clés d'idempotence et les reprises.
- `confidentialite-donnees.md` détaille RM-19 à RM-21 et les contrôles d'accès.
- `questions-ouvertes.md` centralise les décisions à faire approuver ; éviter les décisions tacites.
- Les scripts `mon_miam_miam_schema_v2.sql` et `mon_miam_miam_pilote_v3.sql` **ne représentent pas** à eux seuls des transactions métier sécurisées. Aucun test en production ni revue API/Figma n'est attesté dans cette livraison.
