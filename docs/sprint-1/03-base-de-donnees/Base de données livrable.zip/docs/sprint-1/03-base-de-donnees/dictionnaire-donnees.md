# Dictionnaire de données — Mon Miam Miam

> **Issue GitHub #25 — Livrable 3/3 (conception)**  
> Référence : `mon_miam_miam_schema_v2.sql` daté du 26 octobre 2026 ; `mon_miam_miam_pilote_v3.sql` pour les seuls paramètres de ZeDuc@Space.  
> Statut : **proposition de conception**, à relire et valider avec l’équipe API ; ne prouve pas que le schéma soit actuellement installé dans Supabase.

## 1. Périmètre et conventions

- **Base cible** : PostgreSQL (via Supabase). `auth.users` est une table externe gérée par Supabase Auth ; les **21 tables métier** ci-dessous appartiennent au schéma `public`.
- **PK** : clé primaire ; **FK** : clé étrangère ; **NN** : champ `NOT NULL` ; **NULL** : champ facultatif ; **UNIQUE** : unicité ; **CHECK** : règle de domaine ; **DEFAULT** : valeur par défaut.
- `uuid` : identifiant universel ; `numeric(12,2)` : montant décimal exact ; `timestamptz` : date/heure avec gestion du fuseau ; `jsonb` : JSON binaire ; `char(3)` : code de devise.
- Les relations portant sur `(identifiant, restaurant_id)` protègent l’isolation des données entre restaurants. Les tables ont aussi leurs index de PK et, lorsque présent, d’unicité.
- **Important** : les cardinalités métier (ex. une commande contient au moins une ligne) peuvent être plus strictes que les contraintes imposées par le seul DDL. Leur validation relève des transactions backend/RPC.

**Inventaire : 21 tables métier ; 161 colonnes ; 39 références à analyser (y compris `auth.users`).**

## 01 - Identité et paramétrage


### `restaurants` — Restaurants

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant unique du restaurant |
| `slug` | `text` | NN, UNIQUE, CHECK format slug | Identifiant lisible dans l’URL |
| `name` | `text` | NN | Nom commercial |
| `address` | `text` | NULL | Adresse du restaurant |
| `phone` | `text` | NULL | Téléphone du restaurant |
| `email` | `text` | NULL | Courriel de contact |
| `currency_code` | `char(3)` | NN, DEFAULT 'CDF' (cible approuvée ; V2 SQL source : 'XAF') | Code de devise par défaut |
| `status` | `text` | NN, DEFAULT 'active', CHECK(active/inactive) | État de publication du restaurant |
| `created_at` | `timestamptz` | NN, DEFAULT now() | Date d’enregistrement |

**Contraintes et cohérence :** UNIQUE(slug) ; CHECK(slug ~ ^[a-z0-9]+(-[a-z0-9]+)*$) ; CHECK status dans {active, inactive}.

**Index :** INDEX UNIQUE auto sur id et slug.

### `profiles` — Profils utilisateurs

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, FK → auth.users(id), ON DELETE CASCADE | Identité issue de Supabase Auth |
| `full_name` | `text` | NN, DEFAULT '' | Nom affiché |
| `phone` | `text` | NULL | Numéro de téléphone |
| `account_status` | `text` | NN, DEFAULT 'active', CHECK | État du compte |
| `leaderboard_opt_in` | `boolean` | NN, DEFAULT false | Consentement à figurer au classement |
| `created_at` | `timestamptz` | NN, DEFAULT now() | Date de création du profil |

**Contraintes et cohérence :** CHECK(account_status IN (active,inactive)). Le trigger trg_create_profile insère le profil après création dans auth.users.

**Index :** PK auto sur id.

### `staff_assignments` — Affectations du personnel

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant de l’affectation |
| `restaurant_id` | `uuid` | NN, FK → restaurants(id) | Restaurant de l’employé |
| `user_id` | `uuid` | NN, FK → profiles(id) | Compte du membre du personnel |
| `staff_role` | `text` | NN, CHECK | employee, manager ou admin local |
| `is_active` | `boolean` | NN, DEFAULT true | Affectation actuellement active |
| `assigned_at` | `timestamptz` | NN, DEFAULT now() | Date d’attribution |

**Contraintes et cohérence :** UNIQUE(restaurant_id,user_id) ; CHECK(staff_role IN (employee,manager,admin)). Aucun rôle super_admin global.

**Index :** INDEX idx_staff_user(user_id) ; UNIQUE auto (restaurant_id,user_id).

### `restaurant_settings` — Paramètres restaurant / fidélité

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `restaurant_id` | `uuid` | PK, NN, FK → restaurants(id) | Paramètres d’un restaurant, relation 1:1 |
| `opening_hours` | `jsonb` | NN, DEFAULT '{}'::jsonb | Horaires d’ouverture |
| `loyalty_earn_amount` | `numeric(12,2)` | NN, CHECK > 0 | Montant d’achat correspondant aux points gagnés |
| `loyalty_earn_points` | `integer` | NN, CHECK > 0 | Nombre de points gagnés par tranche |
| `loyalty_redeem_points` | `integer` | NN, CHECK > 0 | Points nécessaires à une remise |
| `loyalty_redeem_value` | `numeric(12,2)` | NN, CHECK > 0 | Valeur monétaire de la remise |
| `referral_reward_points` | `integer` | NULL, CHECK > 0 si renseigné | Nombre de points accordés au parrain |
| `loyalty_expiration_months` | `integer` | NULL, CHECK > 0 si renseigné | Durée éventuelle de validité des points |
| `updated_at` | `timestamptz` | NN, DEFAULT now() | Dernière modification |

**Contraintes et cohérence :** Les valeurs positives sont obligatoires pour les paramètres renseignés. Chaque restaurant définit ses taux.

**Index :** PK auto restaurant_id.

## 02 - Catalogue et menus


### `categories` — Catégories du catalogue

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant de catégorie |
| `restaurant_id` | `uuid` | NN, FK → restaurants(id) | Restaurant propriétaire |
| `name` | `text` | NN | Libellé de catégorie |
| `display_order` | `integer` | NN, DEFAULT 0 | Ordre de présentation |

**Contraintes et cohérence :** UNIQUE(restaurant_id,name) ; UNIQUE(id,restaurant_id) pour les FK composites.

**Index :** INDEX idx_categories_restaurant(restaurant_id) ; UNIQUE auto.

### `products` — Produits

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant du produit |
| `restaurant_id` | `uuid` | NN, FK → restaurants(id) | Restaurant propriétaire |
| `category_id` | `uuid` | NULL, FK composite → categories(id,restaurant_id) | Catégorie, si affectée |
| `name` | `text` | NN | Nom du produit |
| `description` | `text` | NULL | Description |
| `price` | `numeric(12,2)` | NN, CHECK ≥ 0 | Prix affiché |
| `photo_url` | `text` | NULL | Lien vers illustration |
| `is_available` | `boolean` | NN, DEFAULT true | Disponibilité temporaire |
| `is_active` | `boolean` | NN, DEFAULT true | Publication du produit |
| `created_at` | `timestamptz` | NN, DEFAULT now() | Date de création |

**Contraintes et cohérence :** UNIQUE(id,restaurant_id) ; FK(category_id,restaurant_id) → categories(id,restaurant_id) : empêche d’associer une catégorie d’un autre restaurant.

**Index :** INDEX idx_products_restaurant(restaurant_id) ; UNIQUE auto (id,restaurant_id).

### `daily_menu_items` — Produits proposés au menu du jour

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant de l’inscription au menu |
| `restaurant_id` | `uuid` | NN, FK → restaurants(id) | Restaurant |
| `product_id` | `uuid` | NN, FK composite → products(id,restaurant_id) | Produit proposé |
| `menu_date` | `date` | NN | Date du menu |

**Contraintes et cohérence :** UNIQUE(restaurant_id,product_id,menu_date) ; FK(product_id,restaurant_id) → products(id,restaurant_id).

**Index :** INDEX idx_menu_restaurant_date(restaurant_id,menu_date) ; UNIQUE auto.

## 03 - Commandes et règlements


### `orders` — Commandes

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant de commande |
| `restaurant_id` | `uuid` | NN, FK → restaurants(id) | Restaurant unique de la commande |
| `customer_id` | `uuid` | NN, FK → profiles(id) | Client ayant commandé |
| `status` | `text` | NN, DEFAULT pending, CHECK | État courant de traitement |
| `service_mode` | `text` | NN, CHECK(on_site/delivery) | Sur place ou à livrer |
| `expected_arrival_at` | `timestamptz` | NULL | Heure d’arrivée annoncée |
| `customer_note` | `text` | NULL | Consigne du client |
| `currency_code` | `char(3)` | NN, DEFAULT 'CDF' (cible approuvée ; V2 SQL source : 'XAF') | Devise de la commande |
| `subtotal` | `numeric(12,2)` | NN, DEFAULT 0, CHECK ≥ 0 | Sous-total produits |
| `delivery_fee` | `numeric(12,2)` | NN, DEFAULT 0, CHECK ≥ 0 | Frais de livraison |
| `loyalty_discount` | `numeric(12,2)` | NN, DEFAULT 0, CHECK ≥ 0 | Réduction de fidélité |
| `total_amount` | `numeric(12,2)` | NN, GENERATED ALWAYS | subtotal + delivery_fee - loyalty_discount |
| `ordered_at` | `timestamptz` | NN, DEFAULT now() | Horodatage de commande |

**Contraintes et cohérence :** CHECK(status IN (pending,confirmed,preparing,ready,delivering,completed,cancelled)) ; CHECK(service_mode IN (on_site,delivery)) ; CHECK(loyalty_discount <= subtotal) ; UNIQUE(id,restaurant_id), UNIQUE(id,restaurant_id,customer_id), UNIQUE(id,customer_id).

**Index :** INDEX idx_orders_restaurant_date(restaurant_id,ordered_at DESC) ; idx_orders_customer_date(customer_id,ordered_at DESC) ; index des clés uniques.

### `order_items` — Lignes de commande

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant de ligne |
| `order_id` | `uuid` | NN, FK composite → orders(id,restaurant_id) | Commande parente |
| `restaurant_id` | `uuid` | NN, FK via commandes et produits | Restaurant commun |
| `product_id` | `uuid` | NN, FK composite → products(id,restaurant_id) | Produit choisi |
| `product_name_snapshot` | `text` | NN | Nom conservé à la commande |
| `quantity` | `integer` | NN, CHECK > 0 | Quantité commandée |
| `unit_price` | `numeric(12,2)` | NN, CHECK ≥ 0 | Prix figé à la commande |
| `line_total` | `numeric(12,2)` | NN, GENERATED ALWAYS | quantity × unit_price |

**Contraintes et cohérence :** UNIQUE(order_id,product_id) ; FK(order_id,restaurant_id) → orders(id,restaurant_id) ; FK(product_id,restaurant_id) → products(id,restaurant_id). Le produit et la commande doivent appartenir au même restaurant.

**Index :** INDEX idx_order_items_order(order_id) ; UNIQUE auto (order_id,product_id).

### `order_status_events` — Historique des statuts

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant d’événement |
| `order_id` | `uuid` | NN, FK → orders(id) | Commande suivie |
| `previous_status` | `text` | NULL | Statut précédent |
| `new_status` | `text` | NN | Nouveau statut |
| `changed_by` | `uuid` | NULL, FK → profiles(id) | Auteur du changement |
| `changed_at` | `timestamptz` | NN, DEFAULT now() | Date du changement |

**Contraintes et cohérence :** Historisation prévue ; le script V2 ne crée pas de trigger garantissant une écriture à chaque changement du statut courant.

**Index :** INDEX idx_order_status_order(order_id,changed_at).

### `deliveries` — Livraisons

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant livraison |
| `order_id` | `uuid` | NN, UNIQUE, FK → orders(id) | Commande à livrer |
| `delivery_address` | `text` | NN | Adresse de livraison |
| `contact_phone` | `text` | NULL | Téléphone de contact |
| `status` | `text` | NN, DEFAULT pending, CHECK | État de livraison |
| `delivered_at` | `timestamptz` | NULL | Date de livraison effective |
| `created_at` | `timestamptz` | NN, DEFAULT now() | Date de création |

**Contraintes et cohérence :** UNIQUE(order_id) ; CHECK(status IN (pending,assigned,in_transit,delivered,failed)). Le mode delivery de la commande n’est pas contrôlé par FK/CHECK inter-table.

**Index :** UNIQUE auto (order_id).

### `payments` — Tentatives de paiement

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant de tentative |
| `order_id` | `uuid` | NN, FK → orders(id) | Commande concernée |
| `provider` | `text` | NULL | Agrégateur ou fournisseur |
| `method` | `text` | NN, CHECK | Espèces, mobile money ou carte |
| `amount` | `numeric(12,2)` | NN, CHECK > 0 | Montant de tentative |
| `currency_code` | `char(3)` | NN, DEFAULT 'CDF' (cible approuvée ; V2 SQL source : 'XAF') | Devise du paiement |
| `provider_transaction_id` | `text` | NULL | Référence fournisseur |
| `status` | `text` | NN, DEFAULT pending, CHECK | État de paiement |
| `idempotency_key` | `text` | NN, UNIQUE | Identifiant de traitement anti-doublon |
| `paid_at` | `timestamptz` | NULL | Date de règlement |
| `created_at` | `timestamptz` | NN, DEFAULT now() | Date d’enregistrement |

**Contraintes et cohérence :** CHECK(method IN (cash,mobile_money,bank_card)) ; CHECK(status IN (pending,succeeded,failed,cancelled,refunded)) ; UNIQUE(provider,provider_transaction_id) ; UNIQUE(idempotency_key).

**Index :** INDEX idx_payments_order(order_id) ; UNIQUE auto idempotency_key et (provider,provider_transaction_id).

## 04 - Fidélité et parrainage


### `referral_codes` — Codes de parrainage

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant du code |
| `restaurant_id` | `uuid` | NN, FK → restaurants(id) | Restaurant où le code est valable |
| `user_id` | `uuid` | NN, FK → profiles(id) | Propriétaire du code |
| `code` | `text` | NN, CHECK format | Code alphanumérique de 4 à 40 caractères |
| `created_at` | `timestamptz` | NN, DEFAULT now() | Date de création |

**Contraintes et cohérence :** UNIQUE(restaurant_id,user_id) ; UNIQUE(restaurant_id,code) ; UNIQUE(restaurant_id,user_id,code) ; CHECK(code ~ ^[A-Z0-9]{4,40}$).

**Index :** INDEX idx_referral_codes_user(user_id) ; UNIQUE auto.

### `referrals` — Parrainages

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant de parrainage |
| `restaurant_id` | `uuid` | NN, FK → restaurants(id) | Restaurant associé |
| `referrer_id` | `uuid` | NN, FK → profiles(id) + FK composite code | Parrain |
| `referred_id` | `uuid` | NN, FK → profiles(id) | Filleul |
| `code_used` | `text` | NN, FK composite → referral_codes | Code de parrainage appliqué |
| `status` | `text` | NN, DEFAULT pending, CHECK | État du parrainage |
| `qualifying_order_id` | `uuid` | NULL, UNIQUE, FK composite → orders | Première commande admissible |
| `rewarded_points` | `integer` | NN, DEFAULT 0, CHECK ≥ 0 | Nombre de points accordés |
| `created_at` | `timestamptz` | NN, DEFAULT now() | Date de déclaration |
| `rewarded_at` | `timestamptz` | NULL | Date d’attribution de récompense |

**Contraintes et cohérence :** UNIQUE(restaurant_id,referred_id) ; UNIQUE(id,restaurant_id) ; UNIQUE(qualifying_order_id) ; CHECK(referrer_id <> referred_id) ; CHECK cohérence status rewarded (commande, points >0, date). FK(restaurant_id,referrer_id,code_used) → referral_codes ; FK(qualifying_order_id,restaurant_id,referred_id) → orders(id,restaurant_id,customer_id).

**Index :** INDEX idx_referrals_referrer(restaurant_id,referrer_id) ; UNIQUE auto.

### `loyalty_accounts` — Comptes de fidélité

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant compte |
| `restaurant_id` | `uuid` | NN, FK → restaurants(id) | Restaurant du programme |
| `user_id` | `uuid` | NN, FK → profiles(id) | Titulaire des points |
| `balance_points` | `integer` | NN, DEFAULT 0, CHECK ≥ 0 | Solde actuel des points |
| `updated_at` | `timestamptz` | NN, DEFAULT now() | Date de mise à jour |

**Contraintes et cohérence :** UNIQUE(restaurant_id,user_id) ; UNIQUE(id,restaurant_id) ; CHECK(balance_points >= 0). Solde à synchroniser transactionnellement avec le journal.

**Index :** UNIQUE auto sur (restaurant_id,user_id) et (id,restaurant_id).

### `loyalty_transactions` — Mouvements de points

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant du mouvement |
| `loyalty_account_id` | `uuid` | NN, FK composite → loyalty_accounts | Compte impacté |
| `restaurant_id` | `uuid` | NN, FK composites | Restaurant du mouvement |
| `order_id` | `uuid` | NULL, FK composite → orders | Commande éventuellement associée |
| `referral_id` | `uuid` | NULL, FK composite → referrals | Parrainage éventuellement associé |
| `transaction_type` | `text` | NN, CHECK | earn, redeem, referral_bonus, refund, expire, adjustment |
| `points_delta` | `integer` | NN, CHECK ≠ 0, signe contrôlé | Points crédités (+) ou débités (-) |
| `idempotency_key` | `text` | NN, UNIQUE | Clé anti-rejeu |
| `expires_at` | `timestamptz` | NULL | Date d’expiration éventuelle |
| `created_at` | `timestamptz` | NN, DEFAULT now() | Horodatage de mouvement |

**Contraintes et cohérence :** FK(loyalty_account_id,restaurant_id) → loyalty_accounts(id,restaurant_id) ; FK(order_id,restaurant_id) → orders(id,restaurant_id) ; FK(referral_id,restaurant_id) → referrals(id,restaurant_id). Trigger trg_loyalty_owner vérifie le titulaire. CHECK signaux/type ; index partiels uniques : gain par compte+commande, dépense par compte+commande, bonus parrainage unique par referral_id.

**Index :** INDEX idx_loyalty_tx_account_date(loyalty_account_id,created_at DESC) ; UNIQUE(idempotency_key) ; uq_loyalty_order_earn ; uq_loyalty_order_redeem ; uq_referral_bonus_once.

## 05 - Relation client, campagnes et consentement


### `complaints` — Réclamations

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant réclamation |
| `order_id` | `uuid` | NN, FK → orders(id) | Commande mise en cause |
| `created_by` | `uuid` | NN, FK → profiles(id) + FK composite orders | Client auteur |
| `title` | `text` | NN | Titre du problème |
| `description` | `text` | NN | Description détaillée |
| `status` | `text` | NN, DEFAULT open, CHECK | État de traitement |
| `created_at` | `timestamptz` | NN, DEFAULT now() | Date de dépôt |
| `closed_at` | `timestamptz` | NULL | Date de clôture |

**Contraintes et cohérence :** CHECK(status IN (open,in_review,resolved,rejected)) ; FK(order_id,created_by) → orders(id,customer_id) impose que le plaignant soit le client de la commande.

**Index :** INDEX idx_complaints_order(order_id).

### `complaint_responses` — Réponses aux réclamations

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant réponse |
| `complaint_id` | `uuid` | NN, FK → complaints(id) | Réclamation parente |
| `written_by` | `uuid` | NULL, FK → profiles(id) | Auteur de la réponse |
| `response_text` | `text` | NN | Texte de réponse |
| `review_status` | `text` | NN, DEFAULT proposed, CHECK | État de validation |
| `reviewed_by` | `uuid` | NULL, FK → profiles(id) | Validateur |
| `reviewed_at` | `timestamptz` | NULL | Date de validation |
| `created_at` | `timestamptz` | NN, DEFAULT now() | Date de rédaction |

**Contraintes et cohérence :** CHECK(review_status IN (proposed,approved,rejected)). Vérifier rôle du validateur côté backend.

**Index :** INDEX idx_responses_complaint(complaint_id).

### `campaigns` — Campagnes et affiches

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant campagne |
| `restaurant_id` | `uuid` | NN, FK → restaurants(id) | Restaurant organisateur |
| `campaign_type` | `text` | NN, CHECK | promotion, event ou mini_game |
| `title` | `text` | NN | Titre de l’affiche |
| `description` | `text` | NULL | Détails |
| `poster_url` | `text` | NULL | URL du visuel |
| `starts_at` | `timestamptz` | NULL | Début éventuel |
| `ends_at` | `timestamptz` | NULL | Fin éventuelle |
| `is_active` | `boolean` | NN, DEFAULT true | Campagne active |
| `created_at` | `timestamptz` | NN, DEFAULT now() | Date de création |

**Contraintes et cohérence :** CHECK(campaign_type IN (promotion,event,mini_game)) ; CHECK(starts_at IS NULL OR ends_at IS NULL OR ends_at > starts_at).

**Index :** INDEX idx_campaigns_restaurant(restaurant_id,starts_at).

### `campaign_participations` — Participations aux campagnes

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant participation |
| `campaign_id` | `uuid` | NN, FK → campaigns(id) | Campagne concernée |
| `user_id` | `uuid` | NN, FK → profiles(id) | Participant |
| `points_awarded` | `integer` | NN, DEFAULT 0, CHECK ≥ 0 | Points annoncés comme accordés |
| `participated_at` | `timestamptz` | NN, DEFAULT now() | Horodatage |

**Contraintes et cohérence :** CHECK(points_awarded >= 0). Aucun UNIQUE(campaign_id,user_id) dans le script ; règle de répétition à valider.

**Index :** INDEX idx_participations_user(user_id).

### `cookie_consents` — Consentements cookies

| Attribut | Type SQL | Nullabilité, clés et valeurs | Signification |
|---|---|---|---|
| `id` | `uuid` | PK, NN, DEFAULT gen_random_uuid() | Identifiant de consentement |
| `user_id` | `uuid` | NULL, FK → profiles(id) | Utilisateur connecté éventuel |
| `session_id` | `text` | NULL | Identifiant de session anonyme éventuel |
| `analytics_allowed` | `boolean` | NN, DEFAULT false | Autorisation cookies analytiques |
| `marketing_allowed` | `boolean` | NN, DEFAULT false | Autorisation cookies marketing |
| `policy_version` | `text` | NN | Version de la politique présentée |
| `recorded_at` | `timestamptz` | NN, DEFAULT now() | Date de consentement |

**Contraintes et cohérence :** CHECK(user_id IS NOT NULL OR session_id IS NOT NULL). Revoir minimisation et conservation des identifiants de session.

**Index :** PK auto id.

## 7. Relations et cardinalités à contrôler

> Lecture : « entité parente 1 — entité enfant 0..N » représente un parent pouvant avoir plusieurs enfants. Les cardinalités signalées « métier » demandent une validation transactionnelle.

| Entité enfant | Entité référencée | Lien / rôle | Cardinalité indicative |
|---|---|---|---|
| `profiles` | `auth.users` | `identité Supabase` | 1 — 0..1 |
| `staff_assignments` | `restaurants` | `restaurant_id` | 1 — 0..N |
| `staff_assignments` | `profiles` | `user_id` | 1 — 0..N |
| `restaurant_settings` | `restaurants` | `restaurant_id` | 1 — 0..1 |
| `categories` | `restaurants` | `restaurant_id` | 1 — 0..N |
| `products` | `restaurants` | `restaurant_id` | 1 — 0..N |
| `products` | `categories` | `(category_id, restaurant_id)` | 0..1 — 0..N |
| `daily_menu_items` | `restaurants` | `restaurant_id` | 1 — 0..N |
| `daily_menu_items` | `products` | `(product_id, restaurant_id)` | 1 — 0..N |
| `orders` | `restaurants` | `restaurant_id` | 1 — 0..N |
| `orders` | `profiles` | `customer_id` | 1 — 0..N |
| `order_items` | `orders` | `(order_id, restaurant_id)` | 1 — 1..N métier |
| `order_items` | `products` | `(product_id, restaurant_id)` | 1 — 0..N |
| `order_status_events` | `orders` | `order_id` | 1 — 0..N |
| `order_status_events` | `profiles` | `changed_by` | 0..1 — 0..N |
| `deliveries` | `orders` | `order_id UNIQUE` | 1 — 0..1 |
| `payments` | `orders` | `order_id` | 1 — 0..N |
| `referral_codes` | `restaurants` | `restaurant_id` | 1 — 0..N |
| `referral_codes` | `profiles` | `user_id` | 1 — 0..N |
| `referrals` | `restaurants` | `restaurant_id` | 1 — 0..N |
| `referrals` | `profiles` | `referrer_id` | 1 — 0..N |
| `referrals` | `profiles` | `referred_id` | 1 — 0..N |
| `referrals` | `referral_codes` | `(restaurant_id,referrer_id,code_used)` | 1 — 0..N |
| `referrals` | `orders` | `(qualifying_order_id,restaurant_id,referred_id)` | 0..1 — 0..1 |
| `loyalty_accounts` | `restaurants` | `restaurant_id` | 1 — 0..N |
| `loyalty_accounts` | `profiles` | `user_id` | 1 — 0..N |
| `loyalty_transactions` | `loyalty_accounts` | `(loyalty_account_id,restaurant_id)` | 1 — 0..N |
| `loyalty_transactions` | `orders` | `(order_id,restaurant_id)` | 0..1 — 0..N |
| `loyalty_transactions` | `referrals` | `(referral_id,restaurant_id)` | 0..1 — 0..N |
| `complaints` | `orders` | `order_id` | 1 — 0..N |
| `complaints` | `orders` | `(order_id,created_by)` | 1 — 0..N |
| `complaints` | `profiles` | `created_by` | 1 — 0..N |
| `complaint_responses` | `complaints` | `complaint_id` | 1 — 0..N |
| `complaint_responses` | `profiles` | `written_by` | 0..1 — 0..N |
| `complaint_responses` | `profiles` | `reviewed_by` | 0..1 — 0..N |
| `campaigns` | `restaurants` | `restaurant_id` | 1 — 0..N |
| `campaign_participations` | `campaigns` | `campaign_id` | 1 — 0..N |
| `campaign_participations` | `profiles` | `user_id` | 1 — 0..N |
| `cookie_consents` | `profiles` | `user_id` | 0..1 — 0..N |

## 8. Contraintes d’unicité et index métier remarquables

- `restaurants.slug` : identifiant public unique d’un restaurant.
- `staff_assignments(restaurant_id,user_id)` : une affectation maximale par membre et restaurant.
- `categories(restaurant_id,name)` : pas de doublon de catégorie dans un restaurant.
- `daily_menu_items(restaurant_id,product_id,menu_date)` : un produit par date de menu.
- `order_items(order_id,product_id)` : une seule ligne par produit dans une commande.
- `deliveries.order_id` : au plus une livraison par commande.
- `payments.idempotency_key` et `payments(provider,provider_transaction_id)` : prévention de certains doublons de paiements.
- `referral_codes(restaurant_id,user_id)` et `(restaurant_id,code)` : unicité des codes à l’échelle d’un restaurant.
- `referrals(restaurant_id,referred_id)` : un seul parrain par filleul et restaurant ; `qualifying_order_id` unique lorsqu’il est renseigné.
- `loyalty_accounts(restaurant_id,user_id)` : un seul compte de points par client et restaurant.
- `loyalty_transactions.idempotency_key` : mouvement rejoué interdit ; index partiels uniques `uq_loyalty_order_earn`, `uq_loyalty_order_redeem`, `uq_referral_bonus_once`.

## 9. Règles métier associées à la fidélité

Les paramètres sont **locaux à chaque restaurant**. Pour le restaurant pilote ZeDuc@Space, le script de paramétrage prévoit : **1 point pour 1 000 F de produits effectivement payés**, **15 points pour 1 000 F de réduction**, **15 points au parrain** après la première commande réussie, payée et servie/livrée de son filleul dans le restaurant.

Les frais de livraison sont exclus de la base de calcul, ainsi que les remises. Le crédit des points doit avoir lieu seulement lorsque **commande servie/livrée ET paiement confirmé** ; il n’est **pas automatisé** dans le DDL V2. La première commande qualifiante d’un filleul, la mise à jour atomique du solde et les reprises après erreurs doivent être contrôlées par le backend/RPC.

## 10. Confidentialité, accès et limites techniques

- `auth.users` centralise l’authentification ; `public.profiles` évite de dupliquer le mot de passe.
- Le schéma V2 active la **Row Level Security (RLS)** sur les 21 tables publiques et introduit des politiques de lecture. **Les accès du personnel par restaurant et les écritures métier ne sont pas intégralement couverts**.
- Les droits d’écriture sur les commandes, paiements, soldes et mouvements de points doivent être centralisés dans des transactions sûres.
- L’historique `order_status_events` existe, mais aucun trigger V2 ne force l’enregistrement des changements de `orders.status`.
- `orders.subtotal` n’est pas automatiquement recalculé depuis la somme des lignes ; les cohérences `payments`/`orders`, les quantités et la progression des statuts doivent être validées.
- La table `campaign_participations` mémorise `points_awarded`, mais aucune relation métier automatique avec `loyalty_transactions` ne garantit un mouvement correspondant.
- Le panier est actuellement modélisé avant validation dans le frontend ; il n’existe pas de table `carts` dans le schéma V2.
- Le consentement au classement est matérialisé par `leaderboard_opt_in` ; il faut confirmer la méthode d’affichage, les périodes et les règles de conservation.

## 11. Questions à faire valider par l’équipe API

1. **Devise confirmée : CDF (franc congolais)**. Le modèle cible doit utiliser `DEFAULT 'CDF'` pour `restaurants.currency_code`, `orders.currency_code` et `payments.currency_code`. **Attention :** le SQL source V2/V3 porte encore `XAF` ; modifier les sources et déployer les changements via un ticket d'implémentation distinct. Ne pas réécrire automatiquement les paiements / commandes historiques.
2. Valider les transitions autorisées entre statuts de commande, leur historisation obligatoire et le sens de `completed` selon `on_site` / `delivery`.
3. Valider les remboursements partiels/annulations et leurs conséquences sur les mouvements de fidélité.
4. Valider les règles de conservation d’historique, les accès des membres du personnel par restaurant et le cycle des données personnelles.
5. Confirmer si les participations aux campagnes doivent être uniques et si leurs points sont intégrés dans le journal de fidélité.

---

**Origine des champs et contraintes :** transcription documentaire du schéma SQL V2. Ce dictionnaire **ne remplace pas** une revue croisée du SQL, des écrans Figma et des API ; aucune migration n’a été exécutée lors de la préparation du présent livrable.
