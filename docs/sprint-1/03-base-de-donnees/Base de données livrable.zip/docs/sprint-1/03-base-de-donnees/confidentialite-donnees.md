# Confidentialité et minimisation des données — spécification de conception

**Issue #25 · Tâche 7** · 26 octobre 2026. Document de contrôle des accès et des données personnelles, **à valider avec l'équipe API et le responsable métier**.

## 1. Principes de sécurité

**Objet :** établir les catégories de données traitées, leur usage, leur exposition possible, les profils d'accès et les mesures à prévoir dans PostgreSQL/Supabase et dans l'API.

Principes : nécessité, finalité déterminée, moindre privilège, cloisonnement par restaurant, traçabilité des changements sensibles, stockage de secrets hors du navigateur, conservation limitée et possibilité de traitement des droits des personnes. Le cahier des charges demande une protection des données ; l'**applicabilité territoriale et juridique du RGPD et/ou d'autres lois locales doit être examinée** et n'est pas démontrée par ce seul document.

**Ce qui est constaté dans le SQL V2 :** RLS activée sur 21 tables `public` ; politiques de lecture initiales pour catalogue public, propriétaire de ses données et parrainages impliquant le compte ; **les droits complets du personnel et les écritures métier ne sont pas encore spécifiés en SQL**. L'exécution des migrations et l'efficacité des politiques en environnement réel n'ont pas été testées dans cette livraison.

## 2. Inventaire minimal des données et finalités

| Données / table | Finalité légitime | Accessibilité cible | Mesure de réduction |
|---|---|---|---|
| `auth.users` : identité/connexion | Authentification, récupération d'accès | Service Auth + processus serveur habilité | Ne jamais répliquer mot de passe/jetons dans `public`. |
| `profiles.full_name`, `phone` | Affichage/coordination client | Client ; agents autorisés si besoin commande | Téléphone facultatif selon parcours ; masquer dans logs. |
| `orders` : client, montant, note | Achat, service, suivi | Client concerné ; personnel local habilité | Note courte, pas de données sensibles non nécessaires. |
| `order_items`, statuts, paiements | Livraison, preuve d'achat, SAV, comptabilité | Client ; équipes locales selon fonction | Références fournisseur seulement, **jamais PAN/CVV**. |
| `deliveries.delivery_address`, `contact_phone` | Livraison d'une commande | Client + opérateur de livraison habilité | Adresse seulement si `service_mode=delivery` ; accès temporaire restreint. |
| `loyalty_accounts`, `loyalty_transactions` | Fidélité et contrôle des primes | Propriétaire du compte ; opérateur habilité restreint | Pas de transfert arbitraire, journal immutable. |
| `referrals`, `referral_codes` | Gestion du parrainage | Parrain/filleul impliqué, serveur | Limiter les informations réciproques exposées, éviter affichage global des filleuls. |
| `complaints`, `complaint_responses` | Gestion des incidents de commande | Client, agents du restaurant selon mandat | Limiter l'accès aux détails, pas de diffusion publique. |
| `campaign_participations` | Jeux/événements, suivi des gains | Client ; organisateur du restaurant | Non publiques par défaut. |
| `profiles.leaderboard_opt_in` | Consentement au classement nominatif | Client et service de classement | Refuser l'affichage nominatif tant que `false`. |
| `cookie_consents` | Historique du consentement aux traceurs | Personne concernée / serveur habilité | Limiter durée et identifiants de session ; versionner politique. |
| `staff_assignments` | Définir droits des salariés | Personnel impliqué et encadrement local | Rôles locaux, désactivation immédiate à la sortie. |

**Données à proscrire** dans les tables opérationnelles : mot de passe en clair, codes OTP, CVV/PAN, clé secrète de paiement, jeton `service_role`, copies de pièces d'identité non nécessaires, localisation précise en continu, renseignements médicaux dans les notes libre-service. Pour les champs libres, définir des recommandations de saisie et un mécanisme de suppression/redaction en cas d'abus.

## 3. Matrice cible des autorisations (conception, pas politique RLS exécutée)

**Légende :** P = consultation publique limitée ; O = propre données ; L = uniquement restaurant d'affectation ; G = rôle gérant ; A = administrateur local ; S = service backend dédié ; — = aucun accès direct.

| Ressource | Visiteur | Client authentifié | Employé | Gérant | Admin local | Backend sécurisé |
|---|---|---|---|---|---|---|
| Restaurants et menu **publiés** | P | P | L | L | L | S |
| Profil et consentements | — | O | —* | —* | —* | S |
| Commandes / lignes | — | O | L (opérations) | L | L | S |
| Livraisons et adresse | — | O | L (si mission) | L | L | S |
| Tentatives de paiement | — | O (champs non secrets) | L (statut nécessaire) | L | L | S |
| Solde et historique de points | — | O | L (strict minimum SAV) | L | L | S |
| Parrainages | — | O (limité) | L (support) | L | L | S |
| Réclamations / réponses | — | O | L (proposition) | L (validation) | L (validation) | S |
| Gestion du personnel | — | — | — | G | A | S |
| Paramètres du restaurant | P** | P** | L (lecture) | L (selon mandat) | A (écriture) | S |
| Consentements cookie / logs d'audit | — | O | — | — | — | S |

\* Une politique d'accès aux coordonnées nécessaires à une livraison **peut** être accordée au personnel responsable via un endpoint spécifique, sans exposer tout le profil.  
\*\* La V2 autorise la lecture publique des lignes `restaurant_settings` rattachées aux restaurants actifs : évaluer s'il faut publier la totalité de ces champs ou seulement une projection. **Ce tableau est une proposition de politique applicative**, pas une transcription des droits SQL actuels.

**Règle impérative :** chaque contrôle du personnel commence par identifier le `restaurant_id` de la ressource, puis vérifier l'affectation active (`staff_assignments.is_active`) et le rôle requis pour ce **même restaurant**. Ne pas supposer qu'un employé peut administrer tous les restaurants.

## 4. État des protections dans V2 et remédiations

| Contrôle | Situation documentée | Décision d'architecture recommandée |
|---|---|---|
| Supabase Auth | Lien `profiles.id → auth.users.id` ; trigger de création de profil | Ne pas attribuer les rôles en se fondant sur `raw_user_meta_data` modifiable par l'utilisateur. |
| RLS `public` | Activée sur toutes les 21 tables publiques | Vérifier grants et tester politiques pour les rôles `anon`, `authenticated` ; la RLS seule ne remplace pas des grants minimaux. |
| Lecture client | `auth.uid()` comparé au propriétaire / réclamation / commande | Tester accès croisés et absence de fuite via jointures / vues / RPC. |
| Lecture personnel | **Non couverte de façon complète** par le script V2 | Écrire la matrice de rôles par restaurant et les politiques/endpoints associés. |
| Mutations métier | Aucune politique client générale d'INSERT/UPDATE/DELETE | Restreindre commandes, paiement, points et récompenses à transactions serveur/ RPC contrôlées. |
| `service_role` / secrets | Secret donnant des privilèges élevés | **Jamais côté navigateur, Git ou Figma** ; stockage côté serveur et rotation. |
| Fonction `public.handle_new_auth_user()` | `SECURITY DEFINER` dans le schéma `public` de la V2 | Examiner exposition/exécution ; préférer les fonctions privilégiées dans un schéma `private` non exposé ou des droits EXECUTE strictement contrôlés, selon l'architecture retenue. |
| PII en logs | Aucune politique V2 de masquage | Masquer téléphone, adresse, notes, fournisseur ; journaliser identifiants techniques seulement. |
| Stockage médias | URLs de produit et de campagne | Séparer fichiers publics (affiches) et pièces jointes privées (futures), URLs signées si nécessaires. |
| Suppression et conservation | `auth.users → profiles` cascade, autres FK restrictives | Ne pas supprimer un utilisateur sans stratégie sur commandes/comptabilité ; prévoir anonymisation/archivage légal. |

Supabase rappelle que **grants PostgreSQL** et **politiques RLS** sont deux niveaux distincts, et que les fonctions `SECURITY DEFINER` doivent être conçues avec prudence (voir liens en fin de document).

## 5. Exigences de confidentialité par parcours

### A. Inscription / authentification

- Inscription/connexion via Supabase Auth ; validation d'accès côté serveur.
- `profiles` contient seulement des informations utiles au parcours client. Aucun mot de passe dans `profiles`.
- Vérifier la politique de récupération de compte et limiter les tentatives d'authentification.
- Autoriser le changement de numéro/téléphone selon un flux de vérification.

### B. Commande et livraison

- Ne révéler au personnel que les champs utiles à la préparation/livraison ; après clôture, réduire l'exposition de l'adresse.
- Pas de fuite d'adresses d'autres clients dans les classements, recherches ou statistiques.
- Logs de paiements : identifiant de transaction fournisseur, état et montant seulement ; pas de données carte sensibles.

### C. Réclamations

- Client voit ses propres réclamations et réponses approuvées.
- Employé autorisé prépare les réponses pour son restaurant ; le gérant/admin local les approuve.
- **Décision métier validée :** l'approbation du gérant est obligatoire avant présentation au client. Le modèle V2 offre `review_status`, mais **sa politique RLS existante est insuffisante** : elle autorise la lecture de réponses `proposed` ou `rejected` par le propriétaire de la réclamation. La correction doit être appliquée **au niveau serveur/RLS**, puis vérifiée par des tests d'accès (ne jamais dépendre uniquement d'un filtre frontend).

### D. Classement des dix meilleurs clients

- N'exposer le nom d'un client que s'il a accepté le classement (`leaderboard_opt_in=true`).
- Les statistiques jour/semaine/mois peuvent être calculées depuis les commandes éligibles mais vérifier que la période et le critère sont bien définis (nombre de commandes, état d'achèvement, etc.).
- Si un classement non nominatif est proposé aux non consentants, ne pas inclure de pseudonymes facilement réidentifiables sans validation.

### E. Consentement cookies

- Aucun traceur marketing / analytique optionnel avant consentement explicite selon le cadre légal applicable ; pouvoir retirer / modifier ses choix.
- `policy_version` et `recorded_at` rendent la préférence traçable ; la V2 ne conserve pas un `withdrawn_at` explicite, choisir l'usage d'événements successifs.
- Éviter de stocker des identifiants de session en clair durablement si une variante pseudonymisée suffit.

## 6. Durée de conservation, suppression, sauvegarde

Aucune durée chiffrée ne doit être inventée. **Les durées suivantes nécessitent arbitrage juridique et métier** : profils inactifs ; adresses et téléphones après livraison ; historiques de commandes et justificatifs financiers ; parrainages et mouvements de fidélité ; réclamations ; consentements et traces de sécurité.

Recommandations : matrice de conservation versionnée avec *finalité*, *justification*, *durée*, *sort en fin de durée* ; archivage séparé des données comptables et minimisation des données de livraison ; procédure de réponse aux demandes d'accès et d'effacement lorsque la loi applicable le permet ; sauvegardes chiffrées, accès restreint, restauration testée. Ne jamais supprimer un mouvement de points isolément pour corriger un solde : employer une compensation tracée.

## 7. Matrice de tests sécurité recommandés

| ID | Scénario | Résultat attendu |
|---|---|---|
| S-01 | Utilisateur anonyme lit `orders` | Refus. |
| S-02 | Client A lit `orders` ou `deliveries` de B | Refus. |
| S-03 | Client A lit `loyalty_transactions` de B | Refus. |
| S-04 | Employé restaurant A lit commandes du restaurant B | Refus. |
| S-05 | Employé désactivé tente modification | Refus immédiat. |
| S-06 | Employé propose une réponse réclamation | Autorisation locale, statut `proposed`. |
| S-07 | Employé valide sa propre réponse sans rôle manager | Refus. |
| S-08 | Réponse `proposed` ou `rejected` sur la réclamation d'un client | Accès refusé au client (règle validée), avant correction et test RLS. |
| S-09 | Visiteur cherche contact/liste des filleuls d'un autre utilisateur | Refus. |
| S-10 | Frontend tente mutation directe `loyalty_accounts` | Refus. |
| S-11 | Publication classement alors que `leaderboard_opt_in=false` | Pas de ligne nominative. |
| S-12 | Lecture vue ou RPC auxiliaire | Même cloisonnement que la ressource sous-jacente. |
| S-13 | Clé secrète présente dans bundle frontend | Échec audit de sécurité / blocage release. |
| S-14 | Accès au paramètre d'un restaurant inactif | Refus de lecture publique selon politique. |

## 8. Décisions à obtenir et critères de revue

- [ ] Responsables de traitement, pays de déploiement et régime juridique applicables confirmés.
- [ ] Autorisations précises des rôles `employee/manager/admin` validées par le métier.
- [x] Obligation d'approbation préalable par le gérant validée.
- [ ] Politique RLS / API à **corriger et tester** pour masquer toute réponse non approuvée au client.
- [ ] Durées de conservation et droit à l'effacement/arbitrage comptable documentés.
- [ ] Portée des données publiques et des statistiques de classement définie.
- [ ] Tests RLS/grants exécutés sur environnement de test **lors de l'implémentation**.

## Références techniques

- Supabase : https://supabase.com/docs/guides/database/postgres/row-level-security
- Supabase : https://supabase.com/docs/guides/database/functions
- Supabase : https://supabase.com/docs/guides/database/secure-data

**Cette politique décrit une conception cible ; aucune conformité réglementaire complète ni protection RLS de production n'est attestée.**
