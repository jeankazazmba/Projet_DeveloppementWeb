# Questions ouvertes et décisions à valider — Issue GitHub #25

**Tâche 8** · Version du 26/10/2026  
**Statut :** document de suivi **actualisé après six décisions métier** du 26/10/2026 ; revue API et publication non confirmées. Les éléments déjà validés ne sont pas redemandés comme s'ils étaient inconnus.

## 1. Décisions déjà acquises — NE PAS rouvrir sans changement du métier

- **AC-01 :** programme de fidélité paramétré **par restaurant**, sans taux universel.
- **AC-02 :** le gain d'une commande est crédité après **service/livraison ET paiement confirmé**.
- **AC-03 :** la base éligible des gains exclut les frais de livraison et les remises.
- **AC-04 :** parrainage au plus **un par filleul et par restaurant** ; bonus au parrain une seule fois après première commande réussie payée et servie/livrée dans ce restaurant.
- **AC-05 :** le pilote ZeDuc@Space utilise les exemples configurés `1 000 F = 1 point`, `15 points = 1 000 F de réduction`, `15 points de bonus parrain`.
- **AC-06 :** la V1 du panier est propre à un restaurant ; pas de panier multi-restaurants.
- **AC-07 :** rôles de personnel locaux au restaurant, sans super administrateur global prévu en V2.
- **AC-08 :** authentification confiée à Supabase Auth ; MCD/MLD centrés sur la conception, pas sur une migration à livrer dans l'issue.
- **AC-09 (26/10) :** devise du restaurant pilote et de ses règlements : **CDF** (franc congolais) ; `XAF` dans SQL V2/V3 est un écart à corriger.
- **AC-10 (26/10) :** fidélité en points **entiers** ; 1 500 CDF éligibles = **1 point** au barème 1 000 CDF/point, avec tranches complètes.
- **AC-11 (26/10) :** une commande annulée restitue intégralement les **points de remise** qu'elle avait débités, avec mouvement compensatoire idempotent.
- **AC-12 (26/10) :** le remboursement d'une commande retire **automatiquement** les points `earn` initialement crédités grâce à celle-ci, par une compensation négative unique et traçable. Le cas d'un solde devenu insuffisant reste ouvert (Q-19).
- **AC-13 (26/10) :** une commande est soldée par **un paiement intégral unique** ; plusieurs tentatives échouées sont possibles, mais pas de paiements fractionnés.
- **AC-14 (26/10) :** toute réponse d'employé à une réclamation doit être **approuvée par le gérant** avant d'être visible au client.

## 2. Questions bloquantes pour l'implémentation ou la validation finale

> **Instruction :** renseigner « Décision » et « Décidé par » avec un lien Jira/GitHub ou compte-rendu. Ne pas modifier les règles validées sans historiser le changement.

| ID | Priorité | Question et pourquoi elle compte | Proposition de départ (NON VALIDÉE) | Décideur suggéré | État |
|---|---|---|---|---|---|
| **Q-01** | P1 | **Devise du pilote :** `XAF` utilisé dans V2/V3 correspond-il à la monnaie des prix en « F » ? | **DÉCIDÉ : CDF (franc congolais).** Corriger les trois DEFAULT des tables `restaurants`, `orders`, `payments` ; vérifier les scripts de déploiement. | Métier → API/BDD | **Décidé ; adaptation SQL à faire** |
| **Q-02** | P1 | **Paiements :** une commande peut-elle être payée en plusieurs versements ? | **DÉCIDÉ : un paiement unique et intégral**, tentatives échouées conservées ; index unique partiel des succès et preuve externe à mettre en œuvre. Remboursements monétaires à préciser. | Métier → API/paiement | **Décidé en partie** |
| **Q-03** | P1 | **Arrondi des gains :** 1 500 CDF à 1 000 CDF/point ? | **DÉCIDÉ : 1 point**, sans fraction ; calcul par tranches complètes, aucun report du reliquat. | Métier | **Décidé** |
| **Q-04** | P1 | **Annulation :** que deviennent les points utilisés pour une réduction ? | **DÉCIDÉ : restituer intégralement les points de remise via compensation unique et retirer automatiquement les points gagnés d'une commande remboursée** ; conditions d'annulation et remboursement monétaire à préciser. Si points déjà dépensés : voir Q-19. | Métier → API | **Décidé en partie** |
| **Q-05** | P1 | **Remise de fidélité :** points débités à la réservation, au paiement, ou après service ? Comment éviter deux commandes concurrentes ? | Débit atomique à la création, compensation après annulation ; à confirmer. | Métier + API | À décider |
| **Q-06** | P1 | **Expiration :** aucun mois d'expiration au pilote V3 ; la V1 prévoit-elle une expiration et quelles règles de consommation des lots ? | Aucune expiration activée tant que durée/méthode de lots ne sont pas définies. | Métier + API | À décider |
| **Q-07** | P1 | **États des commandes :** quelles transitions, seuil d'annulation, et preuve de « servi » / « livré » ? | Matrice proposée dans `historique-commandes.md` ; `completed` = service fait. | Métier + API | À décider |
| **Q-08** | P1 | **Autorisations détaillées :** qui modifie disponibilité/prix, admin employés, répond/approuve, consulte adresses, rembourse, ajuste points ? | Matrice `confidentialite-donnees.md`, limité au restaurant et au besoin. | Responsable métier + sécurité | À décider |
| **Q-09** | P1 | **Durées et droit applicable :** pays, finalités, conservation, suppression et effacement des données clients ? | Matrice de conservation et validation juridique avant production. | Responsable métier + conformité | À décider |
| **Q-10** | P1 | **Historique garanti :** utiliser trigger ou RPC exclusive pour journaliser toute transition, initialisation et opérations manuelles ? | RPC transactionnelle + accès écrit direct interdit ; trigger complémentaire si voies multiples. | Équipe API/BDD | À décider |
| **Q-11** | P1 | **Réclamations :** une réponse non approuvée peut-elle être visible du client ? | **DÉCIDÉ : non.** Approbation obligatoire du gérant ; corriger le RLS V2 qui divulgue les réponses non approuvées aux clients. | Métier → API/sécurité | **Décidé ; correction sécurité à faire** |
| **Q-12** | P2 | **Jeux et promotions :** les `campaign_participations.points_awarded` sont-ils des points fidélité réellement échangeables ? Un joueur peut-il rejouer ? | Ajouter une origine de transaction dédiée et définir seuils d'unicité si points activés. | Métier + API | À décider |
| **Q-13** | P2 | **Commentaires client après livraison :** besoin confirmé par cahier mais aucun champ dédié V2 hormis `customer_note` avant commande. Où stocker ? | Concevoir `order_reviews` si retours post-service dans la V1. | Métier + UI/API | À décider |
| **Q-14** | P2 | **Promotions appliquées au panier :** affiches seules ou remises automatiques ? | V1 : affiches seulement ; ajouter champ/snapshot de remises si promotion monétaire. | Métier + API | À décider |
| **Q-15** | P2 | **Barèmes historiques :** comment recalculer gain d'une commande lorsque le restaurant modifie ses taux ? | Figer les paramètres appliqués dans un snapshot d'opération. | Métier + API | À décider |
| **Q-19** | P1 | **Points gagnés déjà dépensés :** comment retirer automatiquement les points d'une commande remboursée lorsque le solde ne suffit pas ? | Proposition non validée : enregistrer une dette de points et la compenser sur les gains futurs, tout en gardant le solde affiché >= 0. **V2 ne dispose pas du modèle de dette**. | Métier + API/BDD | À décider |
| **Q-16** | P2 | **Classement :** classer nombre de commandes `completed`, période jour/semaine/mois, anonymisation, ex-aequo ? | Ne compter que commandes réellement terminées, afficher nominativement sur opt-in. | Métier + Figma/API | À décider |
| **Q-17** | P2 | **Réponse du service technique :** que faire des événements de statut dont `changed_by` est NULL ? | Journaliser l'identité technique via mécanisme séparé ou évolution de modèle. | API/BDD | À décider |
| **Q-18** | P2 | **Paramètres publics :** faut-il exposer tous les champs de `restaurant_settings` aux utilisateurs anonymes ? | Vue/API limitée aux barèmes et horaires nécessaires à l'interface. | Métier + sécurité | À décider |

## 3. Registre des décisions — réponses métier du 26/10/2026

| ID | Décision / état | Source | Impact de conception |
|---|---|---|---|
| Q-01 | **VALIDÉ : CDF** | Réponse explicite de l'utilisateur, 26/10/2026 | Corriger défauts `XAF` dans les SQL V2/V3 et paramètres ; ne pas retoucher silencieusement les historiques. |
| Q-02 | **VALIDÉ : paiement unique intégral ; remboursements à préciser** | Même échange | Vérification du total, du fournisseur et de la devise ; futur index unique partiel sur paiement réussi. |
| Q-03 | **VALIDÉ : 1 500 CDF = 1 point** | Même échange | Points entiers, `floor(montant_eligible / palier) × points_par_palier`. |
| Q-04 | **VALIDÉ : points de remise restitués en cas d'annulation ; retrait automatique des gains en cas de remboursement** | Même échange + confirmation ultérieure le 26/10/2026 | Compenser `redeem` par un crédit et `earn` remboursé par un débit idempotent, en transaction. |
| Q-19 | **OUVERT : retrait si points déjà dépensés** | Point technique soulevé après décision | Modéliser un recouvrement ou obtenir une règle métier alternative, car le solde ne peut devenir négatif en V2. |
| Q-11 | **VALIDÉ : approbation du gérant obligatoire** | Même échange | Masquer les réponses `proposed/rejected` via RLS/API ; tests d'accès indispensables. |
| Q-05 à Q-10, Q-12 à Q-18 | **Questions restantes selon détail de la section 2** | — | Révision/acceptation par les parties responsables. |

**Traçabilité :** cette documentation synthétise la décision exprimée dans la conversation de conception ; pour l'audit d'équipe, joindre le lien à l'échange ou reproduire ces six décisions dans le ticket Jira/GitHub #25. L'accord de l'équipe API et le déploiement des adaptations techniques n'en découlent pas automatiquement.

## 4. Ordre conseillé pour la réunion de validation

1. **Priorité paiement + intégrité financière :** appliquer les décisions Q-01/Q-02/Q-03/Q-04, puis arbitrer les volets restants Q-02/Q-04/Q-05/Q-06.
2. **Processus et rôles :** appliquer Q-11, puis arbitrer Q-07, Q-08 et Q-10.
3. **Confidentialité :** Q-09, Q-18.
4. **Extension fonctionnelle :** Q-12 à Q-17.

## 5. Revue de l'issue #25 : qui doit approuver ?

| Livrable | Validation requise | Preuve attendue |
|---|---|---|
| MCD / MLD | Responsable BDD + équipe API | Commentaire de revue / approbation. |
| Dictionnaire | Équipe API | Accord sur types, clés, contraintes et conventions. |
| Règles métier | Responsable métier + API | Décisions sur cas limites et politiques d'exception. |
| Historique / journal points | API + BDD | Stratégie de transaction et prévention des doublons acceptée. |
| Confidentialité | Responsable métier + personne chargée de la sécurité | Matrice d'accès et plan de tests approuvés. |
| Questions ouvertes | Responsable du projet | Questions affectées, décisions tracées ou explicitement reportées. |
| Dépôt | Responsable GitHub/Jira | Fichiers présents dans `docs/sprint-1/03-base-de-donnees`, commentaire dans #25. |

**Le dépôt documentaire et sa validation peuvent être considérés terminés même si certaines questions d'implémentation subsistent**, à condition que l'équipe accepte explicitement le périmètre reporté et que les responsabilités soient consignées. Pas de « tout validé » automatique.
