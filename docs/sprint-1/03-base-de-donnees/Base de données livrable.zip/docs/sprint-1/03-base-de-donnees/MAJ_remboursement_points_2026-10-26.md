# Complément de décision — Remboursement et points gagnés (26/10/2026)

**Décision validée :** lorsqu’une commande déjà créditée en points est remboursée, les points acquis grâce à cette commande doivent être **retirés automatiquement**. Il ne s'agit pas de points de remise, dont la restitution après annulation était déjà validée.

## Exigences pour l'API et la BDD
- Identifier l’écriture de gain `earn` correspondante ; créer un mouvement compensatoire négatif unique, lié à l’origine.
- Appliquer la compensation avec une clé d’idempotence stable et une transaction atomique avec la mise à jour du solde.
- Ne pas effacer l’écriture initiale et prévenir les retraits répétés après notifications ou remboursements réitérés.
- Conserver les contrôles d’autorisation et une preuve d’un remboursement confirmé ; aucune action sur simple requête client non validée.

## Arbitrage restant (Q-19)
Si les points ont déjà été dépensés, le schéma V2 interdit un solde négatif. **À décider :** création d'une dette de points compensée sur les gains futurs (recommandation), ou autre politique avec modification explicite du modèle.

**Statut :** règle métier validée et documentation mise à jour ; aucun changement de schéma ou RPC SQL n'a été exécuté.
