# Journal des mouvements de points — spécification de conception

**Issue #25 · Tâche 6** · 26 octobre 2026. Modèle de journal et prévention des doubles écritures, **sans prétendre que les transactions RPC sont implémentées**.

## 1. Ce que la V2 contient réellement

| Table | Utilité | Principales garanties du schéma |
|---|---|---|
| `restaurant_settings` | Barèmes locaux de fidélité et parrainage | Une configuration par restaurant ; montants/points positifs. |
| `loyalty_accounts` | Solde par couple (restaurant, utilisateur) | `UNIQUE(restaurant_id,user_id)` ; `balance_points >= 0`. |
| `loyalty_transactions` | Journal de chaque variation | Delta non nul, idempotency_key unique, FK composites de même restaurant. |
| `referrals` | Lien parrain/filleul, commande qualifiante | `UNIQUE(restaurant_id,referred_id)` et `UNIQUE(qualifying_order_id)` ; statut et récompense cohérents. |
| `referral_codes` | Code du parrain par restaurant | Code unique localement ; FK composite de vérification dans `referrals`. |
| `orders`, `payments` | Base du gain et preuve de paiement | Montants et statuts stockés ; validation métier de l'éligibilité **non automatisée**. |

### Index anti-doublons existants dans V2

- `loyalty_transactions.idempotency_key` : **UNIQUE**, une clé rejouée ne crée pas de deuxième mouvement.
- `uq_loyalty_order_earn(loyalty_account_id,order_id) WHERE transaction_type='earn'` : pas deux gains du même compte pour une commande.
- `uq_loyalty_order_redeem(loyalty_account_id,order_id) WHERE transaction_type='redeem'` : pas deux débits de remise du même compte pour une commande.
- `uq_referral_bonus_once(referral_id) WHERE transaction_type='referral_bonus'` : pas deux primes pour un même parrainage.
- Fonction `validate_loyalty_transaction_owner()` : le gain et la remise d'une commande correspondent au compte de fidélité **du client de la commande** ; la prime de parrainage correspond au compte **du parrain**. Un événement ne peut être transposé dans un autre restaurant via les FK composites.

**Limite :** les index empêchent certaines doubles **lignes**, mais **ne calculent pas** le gain, **ne mettent pas automatiquement à jour** `balance_points`, **ne vérifient pas** le service/livraison + paiement, et **ne contrôlent pas** à eux seuls toute compensation après remboursement. Le backend/RPC reste requis.

## 2. Barèmes et base éligible

**VALIDÉ :** paramètres de fidélité choisis individuellement par chaque restaurant. Pour le pilote ZeDuc@Space :

- `loyalty_earn_amount = 1 000` ; `loyalty_earn_points = 1` ;
- `loyalty_redeem_points = 15` ; `loyalty_redeem_value = 1 000` ;
- `referral_reward_points = 15` ;
- `loyalty_expiration_months = NULL` dans le script pilote V3 (aucune durée configurée à ce stade).

**VALIDÉ :** points de commande = produits effectivement payés **après remises**, frais de livraison exclus. `orders.total_amount` inclut la livraison, donc **ce champ ne doit pas être pris tel quel comme base de fidélité**.

Formule pour le schéma V2 (une seule remise produit modélisée) :

```text
montant_eligible = max(0, orders.subtotal - orders.loyalty_discount)
```

Si de nouveaux mécanismes de réduction automatique sont intégrés, les autres remises sur produits devront aussi être retirées. La V2 actuelle ne possède pas de colonne dédiée à une promotion monétaire appliquée au panier.

**Règle de calcul validée : tranches complètes et points entiers.**

```text
points_commande = floor(montant_eligible / loyalty_earn_amount)
                 × loyalty_earn_points
```

Une tranche incomplète ne produit aucun point et le reliquat n'est pas reporté : **1 500 CDF de produits éligibles donnent 1 point**. **Exemple :** sous-total de produits 12 000 CDF, remise 1 000 CDF, livraison 1 500 CDF ⇒ base éligible 11 000 CDF ⇒ **11 points**, une fois les conditions de réussite satisfaites. Total facturé : 12 500 CDF ; ne pas calculer les points sur 12 500 CDF.

## 3. Moment d'attribution et définition de commande qualifiante

Deux conditions **cumulatives** (VALIDÉ) :

1. La commande est réellement **servie** (`on_site`) ou **livrée** (`delivery`) ; correspondance avec `orders.status='completed'` et preuve métier à confirmer dans l'API.
2. Le paiement est **confirmé** par une source fiable, pour le montant net dû, sans conflit de devise et selon la règle de remboursements retenue.

Le paiement reçu avant la livraison **ou** la livraison avant le paiement ne doit pas modifier le résultat. Un orchestrateur idempotent est appelé au passage de chacune des deux conditions : il constate si les deux sont remplies avant de créditer.

**VALIDÉ :** paiement **intégral unique** par commande, d'un montant égal à `orders.total_amount` et dans la devise `CDF` ; les paiements fractionnés ne sont pas autorisés. On peut conserver plusieurs tentatives échouées, mais **un seul règlement `succeeded`** est admissible. **À IMPLÉMENTER :** vérification serveur (prestataire / espèces), index unique partiel par commande, traitement des remboursements financiers et des événements concurrents.

## 4. Transactions atomiques et concurrence (cible API)

### 4.1 Gain après commande

```text
créditer_commande(order_id) en transaction sérialisable ou avec verrous :
  - valider identité et restaurant du demandeur technique
  - verrouiller orders[order_id] et le compte de fidélité du client
  - vérifier completed + service/livraison et paiement réellement confirmé
  - figer le montant éligible et calculer des points non négatifs
  - établir clé idempotence stable : "earn:<restaurant_uuid>:<order_uuid>"
  - si mouvement earn déjà existant : ne rien créditer (retour idempotent)
  - sinon insérer le mouvement ET incrémenter balance_points atomiquement
  - COMMIT ; si conflit unique, relire l'opération existante et répondre sans doubler
```

**Invariant J-01 :** chaque `earn` positif correspond à une seule commande qualifiée et au **client de cette commande**.

**Invariant J-02 :** `balance_points >= 0` à tout instant et, à l'état stable, son montant est égal à la somme des deltas du journal, compte tenu des règles de reprise et d'éventuelle initialisation. Le solde ne doit jamais être mis à jour seul.

### 4.2 Utilisation des points lors d'une commande

**À décider (Q-05) :** moment exact de débit. **Option proposée V1 :** au passage de commande, effectuer un débit `redeem` **immédiat et atomique**, appliquer `loyalty_discount` dans la même transaction ; si la commande échoue/est annulée avant consommation, créditer un mouvement compensatoire (`refund`) unique, sans supprimer l'écriture initiale.

La réservation sans débit demanderait une modélisation explicite de points « réservés » et leur libération ; ne pas présumer cette structure dans V2.

Pour débiter : verrouiller le compte ; vérifier solde disponible, restaurant, parité points/remise et plafond de remise ; `balance_points -= points_utilises` avec condition `balance_points >= points_utilises` ; insérer exactement un `redeem` pour la commande ; enregistrer remise de la commande dans la **même transaction** ; sinon rollback. Débit jamais négatif au final.

### 4.3 Bonus de parrainage

```text
attribuer_bonus(referral_id, qualifying_order_id) dans une seule transaction :
  - verrouiller le parrainage et le compte de fidélité du PARRAIN
  - vérifier code et restaurant, referrer != referred
  - prouver que la commande appartient au FILLEUL et au même restaurant
  - vérifier qu'il s'agit de sa première commande remplissant la règle
  - vérifier paiement réel + service/livraison de cette commande
  - vérifier referrals.status = pending et aucun bonus déjà enregistré
  - créditer le nombre de points configuré PAR CE RESTAURANT
  - insérer transaction referral_bonus (clé stable "referral:<id>")
  - enregistrer status=rewarded, qualifying_order_id, rewarded_points, rewarded_at
  - COMMIT (sinon tout annuler)
```

**VALIDÉ :** parrainage maximal une fois par filleul et par restaurant ; bonus pilote **15 points**. Le seul champ `qualifying_order_id` n'atteste pas que la commande est historiquement la première réussie : requête métier et verrous nécessaires.

### 4.4 Annulations, remboursements, expiration et ajustements

- **Annulation après débit `redeem` [VALIDÉ] :** restitution **obligatoire et intégrale** des points utilisés, par compensation `refund` **positive**, avec une clé stable de type `refund:redeem:<order_id>`. Vérifier qu'un débit initial `redeem` existe ; journal et solde sont mis à jour dans une transaction idempotente. Cette décision porte sur les *points* ; les conditions d'annulation et de remboursement monétaire demeurent ouvertes.
- **Remboursement d'une commande créditée [VALIDÉ métier] :** **retirer automatiquement** l'intégralité des points déjà gagnés grâce à cette commande. Ajouter une compensation **négative** liée au mouvement `earn` initial, avec une clé stable (par exemple `reversal:earn:<order_id>`) et une écriture **unique** dans le journal ; synchroniser le solde dans la même transaction. Ne pas supprimer le gain d'origine. **Cas restant à arbitrer :** si le client a déjà dépensé tout ou partie des points, la V2 refuse `balance_points < 0`; décider un mécanisme de dette de points/recouvrement sur les prochains gains, ou adapter le modèle, sans créer de solde négatif par simple contournement.
- **Expiration :** V2 prévoit `expire` négatif et `expires_at`, mais aucune comptabilité des lots consommés (FIFO, LIFO, etc.) n'est spécifiée ; ne pas automatiser tant que la méthode n'a pas été validée.
- **Ajustement manuel :** limité à un acteur habilité du même établissement ; justification et trace d'audit supplémentaire à envisager (V2 n'a pas de champ `reason`/`created_by` dans `loyalty_transactions`).
- **Mini-jeux :** `campaign_participations.points_awarded` ne met pas automatiquement à jour le journal et `loyalty_transactions` n'a pas de référence `campaign_participation_id` ; identifier une extension si les points de jeu deviennent échangeables.

## 5. Points de vigilance et anomalies de modèle

| ID | Élément constaté dans V2 | Risque et décision à prendre |
|---|---|---|
| J-A | Solde mutable + journal séparé | Désynchronisation si solde ajusté sans mouvement : mutation uniquement via transaction dédiée. |
| J-B | `refund` et `adjustment` autorisent ± | Nécessité de rattacher une compensation à l'opération d'origine et d'empêcher doubles remboursements. |
| J-C | Index bonus unique par `referral_id` | Évite la 2e attribution mais ne vérifie pas l'éligibilité de la 1re commande. |
| J-D | Montants et barèmes actuels peuvent changer | Nécessité d'enregistrer le barème appliqué ou de définir la règle des taux historiques. |
| J-E | `points_awarded` des mini-jeux hors journal | Écart entre « points annoncés » et solde effectivement disponible. |
| J-F | Base éligible non historisée distinctement | Si sous-total/discount changent après service, audit des gains impossible sans politique d'immuabilité/snapshot. |
| J-G | Aucune référence explicite de l'écriture compensée | Évaluer `reverses_transaction_id` dans une prochaine migration ou clés d'idempotence métier déterministes. |
| J-H | Retrait automatique après remboursement validé ; solde non négatif imposé | En cas de points déjà dépensés, définir dette/recouvrement ou adaptation du modèle avant implémentation. |

## 6. Scénarios d'acceptation (à programmer ultérieurement)

| Test | Entrée / événement | Résultat attendu |
|---|---|---|
| J-01 | Livraison achevée, paiement encore pending | 0 crédit. |
| J-02 | Paiement succeeded, commande en préparation | 0 crédit. |
| J-03 | Livraison achevée + paiement confirmé | 1 mouvement `earn`, 1 augmentation du solde. |
| J-04 | Même webhook reçu 3 fois | Toujours 1 mouvement `earn`. |
| J-05 | 2 workers récompensent la même commande | Un seul crédit malgré la concurrence. |
| J-06 | 2 commandes utilisent simultanément 15 points alors que solde=15 | Un seul débit autorisé, jamais -15. |
| J-07 | Produit autre restaurant dans une commande | Rejet FK composite. |
| J-08 | 12 000 CDF de produits, 1 000 CDF de remise et 1 500 CDF de livraison | Base=11 000 CDF ; 11 points avec la règle validée. |
| J-09 | Parrainage rejoué après bonus | Zéro nouvelle prime. |
| J-10 | Commande du filleul non payée, puis payée | Prime au moment des deux conditions, une seule fois. |
| J-11 | Annulation après débit de 15 points pour remise | Restitution de 15 points, une seule compensation `refund`, journal et solde cohérents. |
| J-15 | 1 500 CDF de produits éligibles et barème 1 000 CDF/point | 1 point, aucune fraction ni reliquat reporté. |
| J-16 | Deux notifications de paiement intégral pour la même commande | Un seul `payments.status='succeeded'` effectif et un seul gain de fidélité. |
| J-12 | Remboursement d'une commande déjà créditée | Annulation automatique **une seule fois** du gain `earn` initial par compensation négative ; cas de solde insuffisant à préciser. |
| J-13 | Participation à un jeu créditant des points | Mouvement journal présent si la récompense est activée. |
| J-14 | Lecture par un client d'un compte d'un autre restaurant/client | Refus. |

## 7. Décisions et travaux après conception

- [x] Formule par tranches complètes et points entiers validée (Q-03).
- [x] Restitution des points en cas d'annulation validée (Q-04, aspect fidélité).
- [ ] Moment exact du débit initial des points encore à décider (Q-05).
- [x] Retrait automatique des points gagnés lors d'un remboursement **validé métier** ; reste l'implémentation et la gestion d'un solde insuffisant (Q-19).
- [ ] Conditions d'annulation, remboursement **monétaire** et recouvrement des points déjà dépensés encore à décider (Q-04/Q-19, autres aspects).
- [x] Paiement unique et intégral, sans paiement fractionné, validé (Q-02).
- [ ] Gestion du remboursement financier à préciser (Q-02, suite).
- [ ] Expiration et priorité de consommation des lots décidées (Q-06).
- [ ] Transactions backend/RPC, tests de concurrence et contraintes d'audit **à implémenter après l'issue de conception**.
