# Livraison GitHub — Issue #25 — Mon Miam Miam

Ce paquet contient les documents à déposer dans le dossier existant :
`docs/sprint-1/03-base-de-donnees/`

## Indispensables selon le README de l'issue #25
- `MCD.png` ou `MCD.pdf` : modèle conceptuel (les deux formats sont fournis).
- `MLD.png` ou `MLD.pdf` : modèle logique (les deux formats sont fournis).
- `dictionnaire-donnees.md` : tables, attributs, types, PK, FK, contraintes et index.
- `regles-metier.md` : cardinalités, règles de commandes/fidélité/parrainage/confidentialité.
- `questions-ouvertes.md` : décisions restant à trancher et décisions déjà prises.

## Annexes utiles également incluses
- `historique-commandes.md`, `journal-points.md`, `confidentialite-donnees.md`
- `decisions-validees-2026-10-26.md`, `MAJ_remboursement_points_2026-10-26.md`

Le `README.md` déjà présent sur GitHub n'est PAS remplacé par le paquet.

## Statut / réserves importantes
- Livrables de conception prêts pour revue de l'équipe API et vérification Figma.
- Aucune modification du dépôt GitHub ou de Jira n'a été faite automatiquement.
- Aucune migration SQL n'est incluse ou exécutée.
- Devise VALIDÉE : CDF. Le SQL V2/V3 utilisé comme source porte encore XAF : correction lors de l'implémentation.
- Paiement : un seul paiement intégral réussi par commande (tentatives infructueuses historisables).
- En cas d'annulation, restituer les points dépensés ; en cas de remboursement, annuler les points gagnés.
- La règle de récupération si le solde de points est insuffisant (points déjà consommés) est
  ENCORE OUVERTE, car la proposition de dette de points n'a pas été confirmée par le métier.
- Les réponses aux réclamations ne deviennent visibles au client qu'après accord du gérant.

## Étapes GitHub
1. Ajouter ou remplacer les fichiers documentaires sous `docs/sprint-1/03-base-de-donnees/`.
2. Vérifier le rendu des PNG/PDF et la navigation des liens Markdown.
3. Faire relire par l'équipe API, comparer avec Figma et enregistrer leurs commentaires.
4. Signaler le dépôt et la revue dans l'issue #25 et Jira PMEE.

Ne pas annoncer l'issue « validée » avant la revue officielle.
